var networks = {"Hogarth_Bimodal_OpenRefine - Hogarth_Bimodal_OpenRefine (3).tsv": {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.1",
  "target_cytoscapejs_version" : "~2.1",
  "data" : {
    "shared_name" : "Hogarth_Bimodal_OpenRefine - Hogarth_Bimodal_OpenRefine (3).tsv",
    "name" : "Hogarth_Bimodal_OpenRefine - Hogarth_Bimodal_OpenRefine (3).tsv",
    "SUID" : 155,
    "__Annotations" : [ ],
    "selected" : true
  },
  "elements" : {
    "nodes" : [ {
      "data" : {
        "id" : "5070",
        "shared_name" : "John Minton",
        "name" : "John Minton",
        "SUID" : 5070,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1523.6192299345048,
        "y" : -2009.8456005861433
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "5065",
        "shared_name" : "Three",
        "name" : "Three",
        "SUID" : 5065,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1512.5730873563798,
        "y" : -1881.1891064455183
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "5054",
        "shared_name" : "Norah Montgomerie",
        "name" : "Norah Montgomerie",
        "SUID" : 5054,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -771.0181251981767,
        "y" : 221.51969482401296
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "5049",
        "shared_name" : "Scottish Nursery Rhymes",
        "name" : "Scottish Nursery Rhymes",
        "SUID" : 5049,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -675.4010445097001,
        "y" : 240.81974365213796
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "5047",
        "shared_name" : "William Montgomerie",
        "name" : "William Montgomerie",
        "SUID" : 5047,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -742.2462746122392,
        "y" : 368.73490478495046
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "5039",
        "shared_name" : "Mist in the Tagus",
        "name" : "Mist in the Tagus",
        "SUID" : 5039,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -476.6851173856767,
        "y" : 245.16959716776296
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "5037",
        "shared_name" : "Tom Hopkinson",
        "name" : "Tom Hopkinson",
        "SUID" : 5037,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -385.93081440716105,
        "y" : 342.00187255838796
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "5029",
        "shared_name" : "Back",
        "name" : "Back",
        "SUID" : 5029,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -244.86913838177043,
        "y" : -707.5357556154402
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "5024",
        "shared_name" : "E. Osers",
        "name" : "E. Osers",
        "SUID" : 5024,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 71.47644839496297,
        "y" : 947.00761749247
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "5019",
        "shared_name" : "Michael Ayrton",
        "name" : "Michael Ayrton",
        "SUID" : 5019,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 199.85388980121297,
        "y" : 845.40166046122
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "5014",
        "shared_name" : "The Problems of Lieutenant Knap",
        "name" : "The Problems of Lieutenant Knap",
        "SUID" : 5014,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 89.98423037738485,
        "y" : 838.5177340696184
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "5012",
        "shared_name" : "Jiri Mucha",
        "name" : "Jiri Mucha",
        "SUID" : 5012,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 20.98809085101766,
        "y" : 751.465007324013
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "5004",
        "shared_name" : "Loving",
        "name" : "Loving",
        "SUID" : 5004,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -91.34719624309855,
        "y" : -173.99995849629954
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4996",
        "shared_name" : "Cavendish Morton",
        "name" : "Cavendish Morton",
        "SUID" : 4996,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1324.1258217313798,
        "y" : -1631.9660229494245
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4991",
        "shared_name" : "Nunwell Symphony",
        "name" : "Nunwell Symphony",
        "SUID" : 4991,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1348.782132766536,
        "y" : -1503.5158581545027
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4989",
        "shared_name" : "Cecil Aspinall-Oglander",
        "name" : "Cecil Aspinall-Oglander",
        "SUID" : 4989,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1399.7506996610673,
        "y" : -1625.0946850587995
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4984",
        "shared_name" : "Howard Coster",
        "name" : "Howard Coster",
        "SUID" : 4984,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -2348.993314407161,
        "y" : 1277.7765917966692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4979",
        "shared_name" : "E. M. Forster A Study",
        "name" : "E. M. Forster A Study",
        "SUID" : 4979,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -2259.83578266888,
        "y" : 1339.809520263466
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4977",
        "shared_name" : "Lionel Trilling",
        "name" : "Lionel Trilling",
        "SUID" : 4977,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -2176.88363423138,
        "y" : 1408.6348376462786
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4969",
        "shared_name" : "Fireman Flower and other stories",
        "name" : "Fireman Flower and other stories",
        "SUID" : 4969,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1494.308255813411,
        "y" : -1539.102619629112
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4967",
        "shared_name" : "William Sansom",
        "name" : "William Sansom",
        "SUID" : 4967,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1504.8692299345048,
        "y" : -1726.283527832237
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4962",
        "shared_name" : "Keith Vaughn",
        "name" : "Keith Vaughn",
        "SUID" : 4962,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1481.2421547391923,
        "y" : -1323.7704663087995
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4957",
        "shared_name" : "The Sphere of Glass and other poems",
        "name" : "The Sphere of Glass and other poems",
        "SUID" : 4957,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1501.191556594661,
        "y" : -1097.4108776857527
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4946",
        "shared_name" : "Selected Poems_5",
        "name" : "Selected Poems_5",
        "SUID" : 4946,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1500.3804604032548,
        "y" : -68.53346679708079
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4944",
        "shared_name" : "Friedrich Holderlin",
        "name" : "Friedrich Holderlin",
        "SUID" : 4944,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1599.4017006376298,
        "y" : 24.03885986307546
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4933",
        "shared_name" : "The Three Rings",
        "name" : "The Three Rings",
        "SUID" : 4933,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -619.9204994657548,
        "y" : 267.50773193338796
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4931",
        "shared_name" : "Barbara Baker",
        "name" : "Barbara Baker",
        "SUID" : 4931,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -646.2897240140946,
        "y" : 409.65629150370046
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4923",
        "shared_name" : "A Haunted House and Other Short Stories",
        "name" : "A Haunted House and Other Short Stories",
        "SUID" : 4923,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -212.26553120403605,
        "y" : -1139.9535870363386
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4918",
        "shared_name" : "O. Wild",
        "name" : "O. Wild",
        "SUID" : 4918,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -2076.88363423138,
        "y" : 1277.7765917966692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4913",
        "shared_name" : "Against the Tide",
        "name" : "Against the Tide",
        "SUID" : 4913,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1987.7261024930986,
        "y" : 1339.809520263466
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4911",
        "shared_name" : "Arnim Westerholt",
        "name" : "Arnim Westerholt",
        "SUID" : 4911,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1904.7739540555986,
        "y" : 1408.6348376462786
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4906",
        "shared_name" : "William Chappell",
        "name" : "William Chappell",
        "SUID" : 4906,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1804.7739540555986,
        "y" : 1277.7765917966692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4901",
        "shared_name" : "For My Brother A True Story by Jose Martinez Berlanga As Told to Lincoln Kirstein",
        "name" : "For My Brother A True Story by Jose Martinez Berlanga As Told to Lincoln Kirstein",
        "SUID" : 4901,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1715.6164223173173,
        "y" : 1339.809520263466
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4899",
        "shared_name" : "Lincoln Kirstein",
        "name" : "Lincoln Kirstein",
        "SUID" : 4899,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1632.6642738798173,
        "y" : 1408.6348376462786
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4894",
        "shared_name" : "Leonard Rosoman",
        "name" : "Leonard Rosoman",
        "SUID" : 4894,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 143.8784507295577,
        "y" : -213.3015332033308
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4889",
        "shared_name" : "Caught",
        "name" : "Caught",
        "SUID" : 4889,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 9.337801315495199,
        "y" : -288.98457763692454
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4881",
        "shared_name" : "J. L. Gili",
        "name" : "J. L. Gili",
        "SUID" : 4881,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1647.4209877470048,
        "y" : -322.54231689473704
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4876",
        "shared_name" : "Selected Poems of Lorca",
        "name" : "Selected Poems of Lorca",
        "SUID" : 4876,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1555.1424232938798,
        "y" : -433.67879150411204
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4874",
        "shared_name" : "Federico Garcia Lorca",
        "name" : "Federico Garcia Lorca",
        "SUID" : 4874,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1688.9318520048173,
        "y" : -392.5553173830183
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4866",
        "shared_name" : "The Death of the Moth and Other Essays",
        "name" : "The Death of the Moth and Other Essays",
        "SUID" : 4866,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -89.68081440716105,
        "y" : -1082.1356243898542
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4858",
        "shared_name" : "Selected Verse Poems",
        "name" : "Selected Verse Poems",
        "SUID" : 4858,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 607.393160202214,
        "y" : -290.1969189455183
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4856",
        "shared_name" : "Arthur Rimbaud",
        "name" : "Arthur Rimbaud",
        "SUID" : 4856,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 715.5361045381514,
        "y" : -211.70589111348704
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4851",
        "shared_name" : "Graham Sutherland",
        "name" : "Graham Sutherland",
        "SUID" : 4851,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 299.853889801213,
        "y" : 779.4210925290911
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4846",
        "shared_name" : "Channel Packet",
        "name" : "Channel Packet",
        "SUID" : 4846,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 407.2686580202071,
        "y" : 802.2495532224505
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4838",
        "shared_name" : "Norman Cameron",
        "name" : "Norman Cameron",
        "SUID" : 4838,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 478.82626567096395,
        "y" : -390.9806103517683
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4833",
        "shared_name" : "Work in Hand",
        "name" : "Work in Hand",
        "SUID" : 4833,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 309.33029399127645,
        "y" : -519.5179943849714
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4831",
        "shared_name" : "Alan Hodge",
        "name" : "Alan Hodge",
        "SUID" : 4831,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 410.68405375690145,
        "y" : -427.62556884786204
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4826",
        "shared_name" : "John Piper",
        "name" : "John Piper",
        "SUID" : 4826,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 10.957064010807699,
        "y" : -0.22633789083079137
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4821",
        "shared_name" : "Admiral's Widow Being the Life and Letters of the Hon. Mrs. Edward Boscawen from 1761 to 1805",
        "name" : "Admiral's Widow Being the Life and Letters of the Hon. Mrs. Edward Boscawen from 1761 to 1805",
        "SUID" : 4821,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 94.55807719440145,
        "y" : 134.54178955057546
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4819",
        "shared_name" : "Brig.-General Cecil Aspinall-Oglander",
        "name" : "Brig.-General Cecil Aspinall-Oglander",
        "SUID" : 4819,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 158.5725425264327,
        "y" : 246.57999755838796
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4811",
        "shared_name" : "Between the Acts",
        "name" : "Between the Acts",
        "SUID" : 4811,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -278.80386128216105,
        "y" : -1104.5480541994245
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4797",
        "shared_name" : "Selected Poems_4",
        "name" : "Selected Poems_4",
        "SUID" : 4797,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1248.5158363798173,
        "y" : -300.4488720705183
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4795",
        "shared_name" : "Herman Melville",
        "name" : "Herman Melville",
        "SUID" : 4795,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1230.2637001493486,
        "y" : -189.4692578127058
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4787",
        "shared_name" : "Roger Fry A Biography",
        "name" : "Roger Fry A Biography",
        "SUID" : 4787,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -176.32949604778605,
        "y" : -1002.8829607774885
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4782",
        "shared_name" : "Robert Buhler",
        "name" : "Robert Buhler",
        "SUID" : 4782,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1536.9081703641923,
        "y" : -304.7735791017683
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4777",
        "shared_name" : "The Backward Son",
        "name" : "The Backward Son",
        "SUID" : 4777,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1456.1336342313798,
        "y" : -412.59749267598704
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4769",
        "shared_name" : "England's Pleasant Land A Pageant Play",
        "name" : "England's Pleasant Land A Pageant Play",
        "SUID" : 4769,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -517.8345924833329,
        "y" : -1031.6256718446882
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4761",
        "shared_name" : "Twilight in Delhi",
        "name" : "Twilight in Delhi",
        "SUID" : 4761,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -522.414456985286,
        "y" : -1461.7295117189558
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4759",
        "shared_name" : "Ahmed Ali",
        "name" : "Ahmed Ali",
        "SUID" : 4759,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -503.8633400419267,
        "y" : -1590.7729077150495
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4751",
        "shared_name" : "Reviewing",
        "name" : "Reviewing",
        "SUID" : 4751,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -15.379911086848551,
        "y" : -1196.0880627443464
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4743",
        "shared_name" : "After the Deluge A Study of Communal Psychology Vol. II 1830 & 1832",
        "name" : "After the Deluge A Study of Communal Psychology Vol. II 1830 & 1832",
        "SUID" : 4743,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -904.6910072782548,
        "y" : -1218.9192242433699
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4732",
        "shared_name" : "Duino Elegies",
        "name" : "Duino Elegies",
        "SUID" : 4732,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1340.5254799345048,
        "y" : -282.95869873067454
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4724",
        "shared_name" : "Coeducation in its Historical and Theoretical Setting",
        "name" : "Coeducation in its Historical and Theoretical Setting",
        "SUID" : 4724,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1805.9924599149736,
        "y" : -1259.3381542970808
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4719",
        "shared_name" : "Robert Waller",
        "name" : "Robert Waller",
        "SUID" : 4719,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1813.144193313411,
        "y" : -617.6206555177839
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4714",
        "shared_name" : "Ruthven Todd",
        "name" : "Ruthven Todd",
        "SUID" : 4714,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1832.805326125911,
        "y" : -741.1582989504011
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4709",
        "shared_name" : "H. B. Mallalieu",
        "name" : "H. B. Mallalieu",
        "SUID" : 4709,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1747.7554604032548,
        "y" : -594.0448193361433
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4704",
        "shared_name" : "Peter Hewett",
        "name" : "Peter Hewett",
        "SUID" : 4704,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1849.3271767118486,
        "y" : -673.1692395021589
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4699",
        "shared_name" : "Poets of Tomorrow",
        "name" : "Poets of Tomorrow",
        "SUID" : 4699,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1705.9794594266923,
        "y" : -718.7126965334089
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4694",
        "shared_name" : "Hans Wild",
        "name" : "Hans Wild",
        "SUID" : 4694,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1331.267972610286,
        "y" : -1328.8425183107527
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4689",
        "shared_name" : "Humphrey Spender",
        "name" : "Humphrey Spender",
        "SUID" : 4689,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1415.318265579036,
        "y" : -1183.0089611818464
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4684",
        "shared_name" : "Goodbye to Berlin",
        "name" : "Goodbye to Berlin",
        "SUID" : 4684,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1310.440091750911,
        "y" : -1133.4044537355574
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4676",
        "shared_name" : "The Man Below",
        "name" : "The Man Below",
        "SUID" : 4676,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 422.85959086627645,
        "y" : -572.2910656740339
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4674",
        "shared_name" : "Henry Thomas Hopkinson",
        "name" : "Henry Thomas Hopkinson",
        "SUID" : 4674,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 535.625826217839,
        "y" : -499.06200073262767
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4666",
        "shared_name" : "Party Going",
        "name" : "Party Going",
        "SUID" : 4666,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -527.0236793973954,
        "y" : -466.95479248067454
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4658",
        "shared_name" : "A History of Socialism",
        "name" : "A History of Socialism",
        "SUID" : 4658,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1648.520169875911,
        "y" : -1110.7674984743269
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4656",
        "shared_name" : "Sally Graves",
        "name" : "Sally Graves",
        "SUID" : 4656,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1570.6706215360673,
        "y" : -1177.9311871339949
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4648",
        "shared_name" : "Moses and Monotheism",
        "name" : "Moses and Monotheism",
        "SUID" : 4648,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 1061.8963035127608,
        "y" : -1574.1187977602156
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4640",
        "shared_name" : "Civilization, War and Death Selections from Three Works",
        "name" : "Civilization, War and Death Selections from Three Works",
        "SUID" : 4640,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 1123.7547172090499,
        "y" : -1381.6941113283308
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4632",
        "shared_name" : "Amber Innocent",
        "name" : "Amber Innocent",
        "SUID" : 4632,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 73.77365336627645,
        "y" : -1018.3461041261824
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4624",
        "shared_name" : "Education Today and Tomorrow",
        "name" : "Education Today and Tomorrow",
        "SUID" : 4624,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1486.4235512235673,
        "y" : -626.7465100099714
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4622",
        "shared_name" : "T. C. Worsley",
        "name" : "T. C. Worsley",
        "SUID" : 4622,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1605.930081985286,
        "y" : -567.5540661623152
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4614",
        "shared_name" : "Three Guineas",
        "name" : "Three Guineas",
        "SUID" : 4614,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -245.2225014188798,
        "y" : -1144.8993115236433
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4606",
        "shared_name" : "Journey to the Border",
        "name" : "Journey to the Border",
        "SUID" : 4606,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -641.6638161161454,
        "y" : -945.3014340212019
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4595",
        "shared_name" : "Later Poems",
        "name" : "Later Poems",
        "SUID" : 4595,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1343.3981605985673,
        "y" : -23.50648925801829
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4590",
        "shared_name" : "Elizabeth Irving Watson",
        "name" : "Elizabeth Irving Watson",
        "SUID" : 4590,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1532.6642738798173,
        "y" : 1277.7765917966692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4585",
        "shared_name" : "Mile End",
        "name" : "Mile End",
        "SUID" : 4585,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1443.506742141536,
        "y" : 1339.809520263466
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4583",
        "shared_name" : "Kathleen Nott",
        "name" : "Kathleen Nott",
        "SUID" : 4583,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1360.554593704036,
        "y" : 1408.6348376462786
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4578",
        "shared_name" : "Joan Hall",
        "name" : "Joan Hall",
        "SUID" : 4578,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1038.871638915828,
        "y" : 1177.7765917966692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4573",
        "shared_name" : "Clinical Aspects of Psycho-Analysis",
        "name" : "Clinical Aspects of Psycho-Analysis",
        "SUID" : 4573,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1006.3073269346269,
        "y" : 1072.2451586912005
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4568",
        "shared_name" : "Robert Medley",
        "name" : "Robert Medley",
        "SUID" : 4568,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1499.1258217313798,
        "y" : -965.3470139314802
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4563",
        "shared_name" : "Lions and Shadows An Education in the Twenties",
        "name" : "Lions and Shadows An Education in the Twenties",
        "SUID" : 4563,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1373.1744057157548,
        "y" : -964.5277542879255
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4558",
        "shared_name" : "Helena Thornhill",
        "name" : "Helena Thornhill",
        "SUID" : 4558,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -972.6200844266923,
        "y" : -1222.2203869630964
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4544",
        "shared_name" : "David Garnett",
        "name" : "David Garnett",
        "SUID" : 4544,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -983.2673775175126,
        "y" : -1341.7187390138777
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4533",
        "shared_name" : "Julian Bell Essays, Poems and Letters",
        "name" : "Julian Bell Essays, Poems and Letters",
        "SUID" : 4533,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -850.0844093778642,
        "y" : -1279.997150879112
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4523",
        "shared_name" : "The Banders of London",
        "name" : "The Banders of London",
        "SUID" : 4523,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1616.9204994657548,
        "y" : -1339.023975830284
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4521",
        "shared_name" : "Percy Arnold",
        "name" : "Percy Arnold",
        "SUID" : 4521,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1582.1531654813798,
        "y" : -1461.9752392580183
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4513",
        "shared_name" : "The Years",
        "name" : "The Years",
        "SUID" : 4513,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -146.7223793485673,
        "y" : -1025.63691375753
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4503",
        "shared_name" : "Virginia Parsons",
        "name" : "Virginia Parsons",
        "SUID" : 4503,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 856.6456569215743,
        "y" : 751.465007324013
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4498",
        "shared_name" : "Can I Help You? Your Manners--Menus--Amusements--Friends--Charades--Make-ups--Travel--Calling--Children--Love Affairs",
        "name" : "Can I Help You? Your Manners--Menus--Amusements--Friends--Charades--Make-ups--Travel--Calling--Children--Love Affairs",
        "SUID" : 4498,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 917.9641383668868,
        "y" : 835.1228709409563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4493",
        "shared_name" : "Naomi Mitchison",
        "name" : "Naomi Mitchison",
        "SUID" : 4493,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1260.554593704036,
        "y" : 1277.7765917966692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4488",
        "shared_name" : "Socrates",
        "name" : "Socrates",
        "SUID" : 4488,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1171.3970619657548,
        "y" : 1339.809520263466
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4486",
        "shared_name" : "R. H. S. Crossman",
        "name" : "R. H. S. Crossman",
        "SUID" : 4486,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1088.4449135282548,
        "y" : 1408.6348376462786
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4478",
        "shared_name" : "Love, Hate and Reparation Two Lectures",
        "name" : "Love, Hate and Reparation Two Lectures",
        "SUID" : 4478,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 1589.7609885713546,
        "y" : -1478.116993408409
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4470",
        "shared_name" : "Sally Bowles",
        "name" : "Sally Bowles",
        "SUID" : 4470,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1456.815824172786,
        "y" : -1055.8596157838972
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4462",
        "shared_name" : "Diet and High Blood Pressure",
        "name" : "Diet and High Blood Pressure",
        "SUID" : 4462,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1900.8513466337236,
        "y" : -1306.496632080284
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4454",
        "shared_name" : "A General Selection from the Works of Sigmund Freud",
        "name" : "A General Selection from the Works of Sigmund Freud",
        "SUID" : 4454,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 1179.643419601628,
        "y" : -1369.052555542198
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4447",
        "shared_name" : "Cecil Baines",
        "name" : "Cecil Baines",
        "SUID" : 4447,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 1529.0176261445968,
        "y" : -1262.7841076662214
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4442",
        "shared_name" : "The Ego and the Mechanisms of Defence",
        "name" : "The Ego and the Mechanisms of Defence",
        "SUID" : 4442,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 1428.1230720064132,
        "y" : -1325.779346924034
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4440",
        "shared_name" : "Anna Freud",
        "name" : "Anna Freud",
        "SUID" : 4440,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 1321.1923135301558,
        "y" : -1408.353336792198
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4432",
        "shared_name" : "Smoky Crusade",
        "name" : "Smoky Crusade",
        "SUID" : 4432,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 78.8376792451827,
        "y" : -465.6538281252058
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4424",
        "shared_name" : "Patricia Russell",
        "name" : "Patricia Russell",
        "SUID" : 4424,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -831.6568981626542,
        "y" : 751.465007324013
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4419",
        "shared_name" : "Bertrand Russell",
        "name" : "Bertrand Russell",
        "SUID" : 4419,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -895.2059704282792,
        "y" : 836.7065005491106
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4414",
        "shared_name" : "Lady Amberley",
        "name" : "Lady Amberley",
        "SUID" : 4414,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -673.278663299373,
        "y" : 830.140788574013
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4409",
        "shared_name" : "The Amberley Papers The Letters and Diaries of Lord and Lady Amberley",
        "name" : "The Amberley Papers The Letters and Diaries of Lord and Lady Amberley",
        "SUID" : 4409,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -784.336524627498,
        "y" : 852.9980883787005
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4407",
        "shared_name" : "Lord Amberley",
        "name" : "Lord Amberley",
        "SUID" : 4407,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -774.448585174373,
        "y" : 965.9568629453508
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4399",
        "shared_name" : "Enid Marx",
        "name" : "Enid Marx",
        "SUID" : 4399,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -988.4449135282548,
        "y" : 1323.2145648191301
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4394",
        "shared_name" : "A Childhood",
        "name" : "A Childhood",
        "SUID" : 4394,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -888.4406410673173,
        "y" : 1292.485988158974
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4392",
        "shared_name" : "Francesca Allinson",
        "name" : "Francesca Allinson",
        "SUID" : 4392,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -781.4837013700517,
        "y" : 1277.7765917966692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4384",
        "shared_name" : "Lights Are Bright",
        "name" : "Lights Are Bright",
        "SUID" : 4384,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -302.0303322294267,
        "y" : -900.4893154909284
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4379",
        "shared_name" : "Ludvig Perno",
        "name" : "Ludvig Perno",
        "SUID" : 4379,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -190.12283100872355,
        "y" : -2001.5651440431745
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4374",
        "shared_name" : "On Socialism",
        "name" : "On Socialism",
        "SUID" : 4374,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -176.94228901653605,
        "y" : -1860.005939941612
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4366",
        "shared_name" : "The Marchesa and Other Stories",
        "name" : "The Marchesa and Other Stories",
        "SUID" : 4366,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -923.9315773466142,
        "y" : -514.5625500490339
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4364",
        "shared_name" : "K. Swinstead-Smith",
        "name" : "K. Swinstead-Smith",
        "SUID" : 4364,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -911.199353835872,
        "y" : -616.5128369142683
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4359",
        "shared_name" : "Mary Agnes Hamilton",
        "name" : "Mary Agnes Hamilton",
        "SUID" : 4359,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1669.8960243680986,
        "y" : -1655.5516552736433
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4354",
        "shared_name" : "Allison Neilans",
        "name" : "Allison Neilans",
        "SUID" : 4354,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1848.412015579036,
        "y" : -1629.1726269533308
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4346",
        "shared_name" : "Erna Reiss",
        "name" : "Erna Reiss",
        "SUID" : 4346,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1729.4129311063798,
        "y" : -1704.6435742189558
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4341",
        "shared_name" : "Eleanor F. Rathbone",
        "name" : "Eleanor F. Rathbone",
        "SUID" : 4341,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1814.780912063411,
        "y" : -1698.0041699220808
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4333",
        "shared_name" : "Our Freedom and Its Results by Five Women, Eleanor F. Rathbone, Erna Reiss, Ray Strachey, Allison Neilans, Mary Agnes Hamilton",
        "name" : "Our Freedom and Its Results by Five Women, Eleanor F. Rathbone, Erna Reiss, Ray Strachey, Allison Neilans, Mary Agnes Hamilton",
        "SUID" : 4333,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1742.2427650907548,
        "y" : -1542.0879101564558
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4331",
        "shared_name" : "Ray Strachey",
        "name" : "Ray Strachey",
        "SUID" : 4331,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1767.7425209501298,
        "y" : -1647.4889721681745
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4323",
        "shared_name" : "Adventures in Investing by \"Securitas\" (Financial Editor of Time and Tide)",
        "name" : "Adventures in Investing by \"Securitas\" (Financial Editor of Time and Tide)",
        "SUID" : 4323,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1715.275296829036,
        "y" : -1340.6266979982527
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4321",
        "shared_name" : "Securitas",
        "name" : "Securitas",
        "SUID" : 4321,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1777.391019485286,
        "y" : -1470.904102783409
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4310",
        "shared_name" : "Sonnets to Orpheus Written as a monument for Wera Oukama Knoop",
        "name" : "Sonnets to Orpheus Written as a monument for Wera Oukama Knoop",
        "SUID" : 4310,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1321.584867141536,
        "y" : -66.91798828145579
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4305",
        "shared_name" : "Katherine Jones",
        "name" : "Katherine Jones",
        "SUID" : 4305,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 930.3463767549483,
        "y" : -1591.2663731386335
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4300",
        "shared_name" : "The Unknown Murderer",
        "name" : "The Unknown Murderer",
        "SUID" : 4300,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 852.184419967839,
        "y" : -1674.517628174034
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4295",
        "shared_name" : "Anthony Wolfe",
        "name" : "Anthony Wolfe",
        "SUID" : 4295,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -681.4837013700517,
        "y" : 1277.7765917966692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4290",
        "shared_name" : "Envy",
        "name" : "Envy",
        "SUID" : 4290,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -592.3261696317704,
        "y" : 1339.809520263466
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4288",
        "shared_name" : "Yuri Olyesha",
        "name" : "Yuri Olyesha",
        "SUID" : 4288,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -509.3740211942704,
        "y" : 1408.6348376462786
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4280",
        "shared_name" : "Chase of the Wild Goose The story of Lady Eleanor Butler and Miss Sarah Ponsonby, known as the Ladies of Llangollen",
        "name" : "Chase of the Wild Goose The story of Lady Eleanor Butler and Miss Sarah Ponsonby, known as the Ladies of Llangollen",
        "SUID" : 4280,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -175.5877357938798,
        "y" : -852.8060955812605
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4278",
        "shared_name" : "Mary Gordon",
        "name" : "Mary Gordon",
        "SUID" : 4278,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -62.88808979778605,
        "y" : -738.4357037355574
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4273",
        "shared_name" : "J. W. Strange",
        "name" : "J. W. Strange",
        "SUID" : 4273,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -409.3740211942704,
        "y" : 1277.7765917966692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4268",
        "shared_name" : "The Roots of War A Pamphlet on War and the Social Order",
        "name" : "The Roots of War A Pamphlet on War and the Social Order",
        "SUID" : 4268,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -320.2164894559892,
        "y" : 1339.809520263466
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4266",
        "shared_name" : "Friends Anti-War Group",
        "name" : "Friends Anti-War Group",
        "SUID" : 4266,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -237.26434101848918,
        "y" : 1408.6348376462786
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4258",
        "shared_name" : "Inhibitions, Symptoms and Anxiety",
        "name" : "Inhibitions, Symptoms and Anxiety",
        "SUID" : 4258,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 1171.8043845674483,
        "y" : -1671.4959339906843
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4250",
        "shared_name" : "Windless Sky",
        "name" : "Windless Sky",
        "SUID" : 4250,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -924.2715736845048,
        "y" : -434.9572949220808
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4248",
        "shared_name" : "Fritz Faulkner",
        "name" : "Fritz Faulkner",
        "SUID" : 4248,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -988.983045242122,
        "y" : -321.61482666036204
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4240",
        "shared_name" : "Quack, Quack!",
        "name" : "Quack, Quack!",
        "SUID" : 4240,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 108.03317485065145,
        "y" : -922.2410855104597
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4232",
        "shared_name" : "Change Your Sky",
        "name" : "Change Your Sky",
        "SUID" : 4232,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -371.3883644559892,
        "y" : -889.4695706178816
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4230",
        "shared_name" : "Anna D. Whyte",
        "name" : "Anna D. Whyte",
        "SUID" : 4230,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -293.0186745145829,
        "y" : -776.7037854005964
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4225",
        "shared_name" : "Hugh Dalton",
        "name" : "Hugh Dalton",
        "SUID" : 4225,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -137.26434101848918,
        "y" : 1277.7765917966692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4220",
        "shared_name" : "A Derelict Area A Study of the South-West Durham Coalfield",
        "name" : "A Derelict Area A Study of the South-West Durham Coalfield",
        "SUID" : 4220,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -48.106809280207926,
        "y" : 1339.809520263466
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4218",
        "shared_name" : "Thomas Sharp",
        "name" : "Thomas Sharp",
        "SUID" : 4218,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 34.845339157292074,
        "y" : 1408.6348376462786
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4207",
        "shared_name" : "Requiem and Other Poems",
        "name" : "Requiem and Other Poems",
        "SUID" : 4207,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1389.8586708524736,
        "y" : -44.45216796895579
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4196",
        "shared_name" : "Aesthetics and Psychology",
        "name" : "Aesthetics and Psychology",
        "SUID" : 4196,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -815.5309998014482,
        "y" : -1389.463215332237
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4188",
        "shared_name" : "Mr. Norris changes Trains",
        "name" : "Mr. Norris changes Trains",
        "SUID" : 4188,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1011.4468361356767,
        "y" : -757.0362744142683
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4180",
        "shared_name" : "An Autobiographical Study",
        "name" : "An Autobiographical Study",
        "SUID" : 4180,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 1098.0910209199874,
        "y" : -1450.7973522951277
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4172",
        "shared_name" : "John Cournos",
        "name" : "John Cournos",
        "SUID" : 4172,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -630.5249153593095,
        "y" : -470.99837158223704
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4167",
        "shared_name" : "Grammar of Love",
        "name" : "Grammar of Love",
        "SUID" : 4167,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -553.4399696805986,
        "y" : -563.6749462892683
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4159",
        "shared_name" : "Funeral March of a Marionette Charlotte of Albany",
        "name" : "Funeral March of a Marionette Charlotte of Albany",
        "SUID" : 4159,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -108.5817543485673,
        "y" : -855.1979870607527
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4157",
        "shared_name" : "Susan Buchan",
        "name" : "Susan Buchan",
        "SUID" : 4157,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 36.9006675264327,
        "y" : -780.6551708986433
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4152",
        "shared_name" : "Ethel Smth",
        "name" : "Ethel Smth",
        "SUID" : 4152,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 134.84533915729207,
        "y" : 1277.7765917966692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4147",
        "shared_name" : "The 6,000 Beards of Athos",
        "name" : "The 6,000 Beards of Athos",
        "SUID" : 4147,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 224.00287089557332,
        "y" : 1339.809520263466
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4145",
        "shared_name" : "Ralph Brewster",
        "name" : "Ralph Brewster",
        "SUID" : 4145,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 306.9550193330733,
        "y" : 1408.6348376462786
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4137",
        "shared_name" : "Walter Sickert A Conversation",
        "name" : "Walter Sickert A Conversation",
        "SUID" : 4137,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -196.39748921184855,
        "y" : -1050.0751538087995
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4132",
        "shared_name" : "Anthony Butts",
        "name" : "Anthony Butts",
        "SUID" : 4132,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 406.9550193330733,
        "y" : 1277.7765917966692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4127",
        "shared_name" : "In a Province",
        "name" : "In a Province",
        "SUID" : 4127,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 496.1125510713546,
        "y" : 1339.809520263466
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4125",
        "shared_name" : "Laurens Van de Post",
        "name" : "Laurens Van de Post",
        "SUID" : 4125,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 579.0646995088546,
        "y" : 1408.6348376462786
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4120",
        "shared_name" : "Ben Nicolson",
        "name" : "Ben Nicolson",
        "SUID" : 4120,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -299.2192970731767,
        "y" : 89.68876220682546
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4115",
        "shared_name" : "The dark island",
        "name" : "The dark island",
        "SUID" : 4115,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -389.3808571317704,
        "y" : -28.40089843770579
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4104",
        "shared_name" : "The Riddle of the Sphinx or Human Origins",
        "name" : "The Riddle of the Sphinx or Human Origins",
        "SUID" : 4104,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 1512.6929038545577,
        "y" : -1930.6995739748152
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4102",
        "shared_name" : "Geza Roheim",
        "name" : "Geza Roheim",
        "SUID" : 4102,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 1556.8164237520186,
        "y" : -2041.5414624025495
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4097",
        "shared_name" : "J. B. Leishman",
        "name" : "J. B. Leishman",
        "SUID" : 4097,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1388.3076454618486,
        "y" : -147.82613037129954
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4092",
        "shared_name" : "Poems_10",
        "name" : "Poems_10",
        "SUID" : 4092,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1304.0041786649736,
        "y" : -134.2890820314558
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4087",
        "shared_name" : "Irma Petroff",
        "name" : "Irma Petroff",
        "SUID" : 4087,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 679.0646995088546,
        "y" : 1277.7765917966692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4082",
        "shared_name" : "The Secret of Hitler's Victory",
        "name" : "The Secret of Hitler's Victory",
        "SUID" : 4082,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 768.2222312471358,
        "y" : 1339.809520263466
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4080",
        "shared_name" : "Peter Petroff",
        "name" : "Peter Petroff",
        "SUID" : 4080,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 851.1743796846358,
        "y" : 1408.6348376462786
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4072",
        "shared_name" : "Progressive Schools Their Principles and Practice",
        "name" : "Progressive Schools Their Principles and Practice",
        "SUID" : 4072,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1822.248441360286,
        "y" : -1334.761768799034
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4067",
        "shared_name" : "Professor Julian Huxley",
        "name" : "Professor Julian Huxley",
        "SUID" : 4067,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -2020.547269485286,
        "y" : -1162.268360595909
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4059",
        "shared_name" : "An African Speaks for His People",
        "name" : "An African Speaks for His People",
        "SUID" : 4059,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1864.798490188411,
        "y" : -1162.4650158693464
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4057",
        "shared_name" : "Parmenas Githendu Mockerie",
        "name" : "Parmenas Githendu Mockerie",
        "SUID" : 4057,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1969.7732216337236,
        "y" : -1076.761814575401
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4052",
        "shared_name" : "Betty Graham",
        "name" : "Betty Graham",
        "SUID" : 4052,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 951.1743796846358,
        "y" : 1277.7765917966692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4047",
        "shared_name" : "Good Merchant",
        "name" : "Good Merchant",
        "SUID" : 4047,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 1040.331911422917,
        "y" : 1339.809520263466
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4045",
        "shared_name" : "John L. Graham",
        "name" : "John L. Graham",
        "SUID" : 4045,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 1123.284059860417,
        "y" : 1408.6348376462786
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4031",
        "shared_name" : "Reminiscences of Tolstoy, Chekhov and Andrew",
        "name" : "Reminiscences of Tolstoy, Chekhov and Andrew",
        "SUID" : 4031,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 96.56967387408895,
        "y" : -1267.9236035158308
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4023",
        "shared_name" : "Illyria, Lady",
        "name" : "Illyria, Lady",
        "SUID" : 4023,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -852.5967308500321,
        "y" : -402.42451904317454
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4021",
        "shared_name" : "Constance Butler",
        "name" : "Constance Butler",
        "SUID" : 4021,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -885.5872627714189,
        "y" : -279.29329345723704
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4013",
        "shared_name" : "Charles Lamb His Life Recorded by his Contemporaries",
        "name" : "Charles Lamb His Life Recorded by his Contemporaries",
        "SUID" : 4013,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -194.31423725872355,
        "y" : -787.7327160646589
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4005",
        "shared_name" : "Flush A Biography",
        "name" : "Flush A Biography",
        "SUID" : 4005,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -332.5145241239579,
        "y" : -1145.713459472862
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4000",
        "shared_name" : "R. E. Warner",
        "name" : "R. E. Warner",
        "SUID" : 4000,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1396.0810219266923,
        "y" : -690.7043957521589
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3995",
        "shared_name" : "Edward Upward",
        "name" : "Edward Upward",
        "SUID" : 3995,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -971.2911049345048,
        "y" : -869.5722317506941
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3978",
        "shared_name" : "Charles Madge",
        "name" : "Charles Madge",
        "SUID" : 3978,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1399.3774086454423,
        "y" : -870.5150265504988
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3964",
        "shared_name" : "Richard Goodman",
        "name" : "Richard Goodman",
        "SUID" : 3964,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1251.360257766536,
        "y" : -866.4645581056745
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3956",
        "shared_name" : "G. F. Brett",
        "name" : "G. F. Brett",
        "SUID" : 3956,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1418.3636147001298,
        "y" : -799.8864483644636
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3951",
        "shared_name" : "T. O. Beachcroft",
        "name" : "T. O. Beachcroft",
        "SUID" : 3951,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1436.702298782161,
        "y" : -742.3734173586042
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3940",
        "shared_name" : "New Country Prose and Poetry by the authors of New Signatures",
        "name" : "New Country Prose and Poetry by the authors of New Signatures",
        "SUID" : 3940,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1297.3774696805986,
        "y" : -801.7611431886824
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3932",
        "shared_name" : "The Twilight Age, A Fragment of Life",
        "name" : "The Twilight Age, A Fragment of Life",
        "SUID" : 3932,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -822.3465935209306,
        "y" : -465.0809521486433
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3930",
        "shared_name" : "A. Prophett",
        "name" : "A. Prophett",
        "SUID" : 3930,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -726.708631179622,
        "y" : -445.8979687502058
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3922",
        "shared_name" : "The Myth of Governor Eyre",
        "name" : "The Myth of Governor Eyre",
        "SUID" : 3922,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1965.907132766536,
        "y" : -1226.3786816408308
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3917",
        "shared_name" : "Jane Soames",
        "name" : "Jane Soames",
        "SUID" : 3917,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 1223.284059860417,
        "y" : 1277.7765917966692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3912",
        "shared_name" : "The Political and Social Doctrine of Fascism",
        "name" : "The Political and Social Doctrine of Fascism",
        "SUID" : 3912,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 1312.4415915986983,
        "y" : 1339.809520263466
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3910",
        "shared_name" : "Benito Mussolini",
        "name" : "Benito Mussolini",
        "SUID" : 3910,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 1395.3937400361983,
        "y" : 1408.6348376462786
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3902",
        "shared_name" : "Margaret Miller",
        "name" : "Margaret Miller",
        "SUID" : 3902,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1859.878324172786,
        "y" : -901.436832885948
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3897",
        "shared_name" : "Financial Democracy",
        "name" : "Financial Democracy",
        "SUID" : 3897,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1804.0754677274736,
        "y" : -1026.0669827272566
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3895",
        "shared_name" : "Douglas Campbell",
        "name" : "Douglas Campbell",
        "SUID" : 3895,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1921.601956985286,
        "y" : -943.1899227907331
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3887",
        "shared_name" : "The Tragedy of Man",
        "name" : "The Tragedy of Man",
        "SUID" : 3887,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 1159.106216766545,
        "y" : 820.041064758095
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3885",
        "shared_name" : "Imre Madách",
        "name" : "Imre Madách",
        "SUID" : 3885,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 1244.9501040956466,
        "y" : 751.465007324013
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3880",
        "shared_name" : "Ronald Grierson",
        "name" : "Ronald Grierson",
        "SUID" : 3880,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 1495.3937400361983,
        "y" : 1277.7765917966692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3875",
        "shared_name" : "Livingstones A Novel of Contemporary Life",
        "name" : "Livingstones A Novel of Contemporary Life",
        "SUID" : 3875,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 1584.5512717744796,
        "y" : 1339.809520263466
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3873",
        "shared_name" : "Derrick Leon",
        "name" : "Derrick Leon",
        "SUID" : 3873,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 1667.5034202119796,
        "y" : 1408.6348376462786
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3868",
        "shared_name" : "W. J. H. Sprott",
        "name" : "W. J. H. Sprott",
        "SUID" : 3868,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 1404.756960251042,
        "y" : -1771.5656170656355
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3860",
        "shared_name" : "New Introductory Lectures on Psycho-Analysis",
        "name" : "New Introductory Lectures on Psycho-Analysis",
        "SUID" : 3860,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 1299.7988208314864,
        "y" : -1712.5205807497175
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3855",
        "shared_name" : "Priscilla Ellingford",
        "name" : "Priscilla Ellingford",
        "SUID" : 3855,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 55.6636069795577,
        "y" : -192.24934814473704
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3850",
        "shared_name" : "Hamish Miles",
        "name" : "Hamish Miles",
        "SUID" : 3850,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 19.05673442096395,
        "y" : -135.75923584004954
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3845",
        "shared_name" : "Gleb Struve",
        "name" : "Gleb Struve",
        "SUID" : 3845,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -45.4349037626298,
        "y" : -109.04524658223704
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3840",
        "shared_name" : "The Well of Days",
        "name" : "The Well of Days",
        "SUID" : 3840,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -74.9756752470048,
        "y" : -264.77766845723704
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3832",
        "shared_name" : "The Common Reader Second Series",
        "name" : "The Common Reader Second Series",
        "SUID" : 3832,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -281.4552589872392,
        "y" : -1158.4519390871199
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3821",
        "shared_name" : "Jupiter and the Nun",
        "name" : "Jupiter and the Nun",
        "SUID" : 3821,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -174.2343422391923,
        "y" : -951.7124600221784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3813",
        "shared_name" : "Cheerful Weather for the Wedding",
        "name" : "Cheerful Weather for the Wedding",
        "SUID" : 3813,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -598.0169350126298,
        "y" : -1541.7705273439558
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3811",
        "shared_name" : "Julia Strachey",
        "name" : "Julia Strachey",
        "SUID" : 3811,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -604.2304970243486,
        "y" : -1668.720295410362
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3806",
        "shared_name" : "George Plank",
        "name" : "George Plank",
        "SUID" : 3806,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -408.35500874309855,
        "y" : 114.86613037088796
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3801",
        "shared_name" : "Family History",
        "name" : "Family History",
        "SUID" : 3801,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -458.8615089872392,
        "y" : -16.51363037129954
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3796",
        "shared_name" : "A. S. J. Tessimond",
        "name" : "A. S. J. Tessimond",
        "SUID" : 3796,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1234.4712196805986,
        "y" : -718.4330029298933
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3782",
        "shared_name" : "William Empson",
        "name" : "William Empson",
        "SUID" : 3782,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1144.4126869657548,
        "y" : -911.3809323122175
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3777",
        "shared_name" : "Richard Eberhart",
        "name" : "Richard Eberhart",
        "SUID" : 3777,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1096.7290626981767,
        "y" : -813.5202679445417
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3766",
        "shared_name" : "W. H. Auden",
        "name" : "W. H. Auden",
        "SUID" : 3766,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1338.8212563016923,
        "y" : -713.0344738771589
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3761",
        "shared_name" : "New Signatures Poems by Several Hands",
        "name" : "New Signatures Poems by Several Hands",
        "SUID" : 3761,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1196.6320778348954,
        "y" : -818.8020062257917
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3759",
        "shared_name" : "Michael Roberts",
        "name" : "Michael Roberts",
        "SUID" : 3759,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1309.2405678251298,
        "y" : -898.7087139894636
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3751",
        "shared_name" : "The Rt. Hon. Wedgwood Benn.",
        "name" : "The Rt. Hon. Wedgwood Benn.",
        "SUID" : 3751,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -2033.986722610286,
        "y" : -1061.269466858116
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3746",
        "shared_name" : "India in Transition",
        "name" : "India in Transition",
        "SUID" : 3746,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1878.994779250911,
        "y" : -1081.7755551149519
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3744",
        "shared_name" : "D. Graham Pole",
        "name" : "D. Graham Pole",
        "SUID" : 3744,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1992.308011672786,
        "y" : -987.4905671884687
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3736",
        "shared_name" : "The Case is Altered",
        "name" : "The Case is Altered",
        "SUID" : 3736,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -994.4233833768876,
        "y" : -592.1317639162214
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3728",
        "shared_name" : "Public Schools Their Failure and Their Reform",
        "name" : "Public Schools Their Failure and Their Reform",
        "SUID" : 3728,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1834.1574989774736,
        "y" : -1290.163380127159
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3723",
        "shared_name" : "Herbert Agar.",
        "name" : "Herbert Agar.",
        "SUID" : 3723,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1062.814244888118,
        "y" : 751.465007324013
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3718",
        "shared_name" : "The Defeat of Baudelaire A Psycho-Analytical Study of the Neuroses of Charles Baudelaire",
        "name" : "The Defeat of Baudelaire A Psycho-Analytical Study of the Neuroses of Charles Baudelaire",
        "SUID" : 3718,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1014.5535885313066,
        "y" : 850.0710864255755
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3716",
        "shared_name" : "René Laforgue",
        "name" : "René Laforgue",
        "SUID" : 3716,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -995.2059704282792,
        "y" : 959.735515136513
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3711",
        "shared_name" : "John Banting",
        "name" : "John Banting",
        "SUID" : 3711,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -827.022367141536,
        "y" : -571.1724743654402
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3706",
        "shared_name" : "The Memorial Portrait of a Family",
        "name" : "The Memorial Portrait of a Family",
        "SUID" : 3706,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1047.6779152372392,
        "y" : -721.2818493654402
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3704",
        "shared_name" : "Christopher Isherwood",
        "name" : "Christopher Isherwood",
        "SUID" : 3704,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1230.4407021024736,
        "y" : -917.4936413576277
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3696",
        "shared_name" : "Ten Letter-Writers",
        "name" : "Ten Letter-Writers",
        "SUID" : 3696,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1666.9609047391923,
        "y" : -1373.4524121095808
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3694",
        "shared_name" : "Irvine Lyn Ll.",
        "name" : "Irvine Lyn Ll.",
        "SUID" : 3694,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1656.9990517118486,
        "y" : -1500.1603283693464
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3686",
        "shared_name" : "O Providence",
        "name" : "O Providence",
        "SUID" : 3686,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1168.6183754423173,
        "y" : -342.7331738283308
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3678",
        "shared_name" : "The Mugwumps and the Labour Party",
        "name" : "The Mugwumps and the Labour Party",
        "SUID" : 3678,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1772.726712844661,
        "y" : -1176.0441326906355
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3676",
        "shared_name" : "G. T. Garratt",
        "name" : "G. T. Garratt",
        "SUID" : 3676,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1807.981107375911,
        "y" : -1085.0146450807722
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3668",
        "shared_name" : "St. Martin's Summer",
        "name" : "St. Martin's Summer",
        "SUID" : 3668,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -589.586087844661,
        "y" : 351.22843505838796
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3660",
        "shared_name" : "Psycho-analysis of the Neuroses",
        "name" : "Psycho-analysis of the Neuroses",
        "SUID" : 3660,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 1393.8785880586593,
        "y" : -1118.0298962404402
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3658",
        "shared_name" : "Dr. Helene Deutsch",
        "name" : "Dr. Helene Deutsch",
        "SUID" : 3658,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 1464.2907432100264,
        "y" : -1023.0735363771589
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3650",
        "shared_name" : "The New Boer War",
        "name" : "The New Boer War",
        "SUID" : 3650,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1886.185453079036,
        "y" : -1237.0626721193464
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3642",
        "shared_name" : "The Waves",
        "name" : "The Waves",
        "SUID" : 3642,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -133.53030171184855,
        "y" : -1097.449184875694
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3634",
        "shared_name" : "English Village Schools",
        "name" : "English Village Schools",
        "SUID" : 3634,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1577.0346962430986,
        "y" : -1282.7216992189558
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3632",
        "shared_name" : "Marjorie Wise",
        "name" : "Marjorie Wise",
        "SUID" : 3632,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1528.9220863798173,
        "y" : -1398.1367077638777
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3624",
        "shared_name" : "Unemployment Its Causes and Their Remedies",
        "name" : "Unemployment Its Causes and Their Remedies",
        "SUID" : 3624,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -829.7089363554032,
        "y" : -1831.1345410158308
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3622",
        "shared_name" : "Rupert Trouton",
        "name" : "Rupert Trouton",
        "SUID" : 3622,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -852.9787270048173,
        "y" : -1969.2992138673933
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3617",
        "shared_name" : "E. J. Langford Garstin",
        "name" : "E. J. Langford Garstin",
        "SUID" : 3617,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 1344.9501040956466,
        "y" : 779.4210925290911
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3612",
        "shared_name" : "The Search A Quarterly Review",
        "name" : "The Search A Quarterly Review",
        "SUID" : 3612,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 1452.3648723146407,
        "y" : 802.2495532224505
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3601",
        "shared_name" : "Sissinghurst",
        "name" : "Sissinghurst",
        "SUID" : 3601,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -258.63918843059855,
        "y" : -845.6956829836042
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3593",
        "shared_name" : "All Passion Spent",
        "name" : "All Passion Spent",
        "SUID" : 3593,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -559.469617507747,
        "y" : -9.243977050987041
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3588",
        "shared_name" : "Insel-Verlag",
        "name" : "Insel-Verlag",
        "SUID" : 3588,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1023.7615944364579,
        "y" : 123.39152099588796
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3583",
        "shared_name" : "Willi Laste",
        "name" : "Willi Laste",
        "SUID" : 3583,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -866.6521965482743,
        "y" : 177.68790771463796
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3578",
        "shared_name" : "Hans Schulze",
        "name" : "Hans Schulze",
        "SUID" : 3578,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1010.1526466825517,
        "y" : -25.67421386739329
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3573",
        "shared_name" : "Walter Tanz",
        "name" : "Walter Tanz",
        "SUID" : 3573,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1066.5363747098954,
        "y" : 177.96989013651296
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3568",
        "shared_name" : "Cranach Press",
        "name" : "Cranach Press",
        "SUID" : 3568,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -924.3802162626298,
        "y" : 224.37479736307546
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3563",
        "shared_name" : "G. T. Friend",
        "name" : "G. T. Friend",
        "SUID" : 3563,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -996.7770973661454,
        "y" : 187.74528076151296
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3558",
        "shared_name" : "E. Prince",
        "name" : "E. Prince",
        "SUID" : 3558,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1089.0599037626298,
        "y" : 107.15140869120046
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3553",
        "shared_name" : "Edward Johnston",
        "name" : "Edward Johnston",
        "SUID" : 3553,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1062.5774818876298,
        "y" : 36.71061279276296
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3548",
        "shared_name" : "Eric Gill",
        "name" : "Eric Gill",
        "SUID" : 3548,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -834.5953880765946,
        "y" : 99.37931396463796
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3543",
        "shared_name" : "Count Harry Kessler",
        "name" : "Count Harry Kessler",
        "SUID" : 3543,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -932.6630684354814,
        "y" : 158.80680419901296
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3532",
        "shared_name" : "Duineser Elegien Elegies from the Castle of Duino",
        "name" : "Duineser Elegien Elegies from the Castle of Duino",
        "SUID" : 3532,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -939.803128860286,
        "y" : 57.26078369120046
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3521",
        "shared_name" : "Ritual Psycho-Analytic Studies",
        "name" : "Ritual Psycho-Analytic Studies",
        "SUID" : 3521,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 1094.7827018281905,
        "y" : -1662.2257313539656
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3516",
        "shared_name" : "John Armstrong",
        "name" : "John Armstrong",
        "SUID" : 3516,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1284.700833938411,
        "y" : -374.00984619161204
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3511",
        "shared_name" : "Sado",
        "name" : "Sado",
        "SUID" : 3511,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1248.871976516536,
        "y" : -487.3287548830183
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3503",
        "shared_name" : "The Sensitive One",
        "name" : "The Sensitive One",
        "SUID" : 3503,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1778.2893349149736,
        "y" : -1406.751270752159
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3495",
        "shared_name" : "The Trap",
        "name" : "The Trap",
        "SUID" : 3495,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1717.204984329036,
        "y" : -1076.8120312502058
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3493",
        "shared_name" : "Allen Havens",
        "name" : "Allen Havens",
        "SUID" : 3493,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1755.155179641536,
        "y" : -954.0866894533308
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3485",
        "shared_name" : "Saturday Night at the Greyhound",
        "name" : "Saturday Night at the Greyhound",
        "SUID" : 3485,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -853.6058403471025,
        "y" : -141.4615673830183
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3483",
        "shared_name" : "John Hampson",
        "name" : "John Hampson",
        "SUID" : 3483,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1088.6287514188798,
        "y" : -440.5739941408308
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3475",
        "shared_name" : "Life as we have known it By Co-Operative working women",
        "name" : "Life as we have known it By Co-Operative working women",
        "SUID" : 3475,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 169.29977641315145,
        "y" : -1243.7075085451277
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3473",
        "shared_name" : "Margaret Llewelyn Davies",
        "name" : "Margaret Llewelyn Davies",
        "SUID" : 3473,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 348.92514262408895,
        "y" : -1279.751270752159
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3468",
        "shared_name" : "A. D. W.",
        "name" : "A. D. W.",
        "SUID" : 3468,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 2186.628008224675,
        "y" : -1854.7108959962995
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3460",
        "shared_name" : "Kathleen Raine",
        "name" : "Kathleen Raine",
        "SUID" : 3460,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 1943.0514853975264,
        "y" : -1959.291553955284
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3455",
        "shared_name" : "F. Picot",
        "name" : "F. Picot",
        "SUID" : 3455,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 2011.6621421358077,
        "y" : -2038.7552990724714
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3450",
        "shared_name" : "E. E. Phare",
        "name" : "E. E. Phare",
        "SUID" : 3450,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 2085.3388694307296,
        "y" : -2041.5414624025495
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3445",
        "shared_name" : "M. N.",
        "name" : "M. N.",
        "SUID" : 3445,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 2195.4850638887374,
        "y" : -1965.3346142580183
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3440",
        "shared_name" : "Helen Megaw",
        "name" : "Helen Megaw",
        "SUID" : 3440,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 1980.6041892549483,
        "y" : -1860.416843872276
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3435",
        "shared_name" : "Morwenna Lyne",
        "name" : "Morwenna Lyne",
        "SUID" : 3435,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 1925.0559714815108,
        "y" : -1888.8685650636824
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3430",
        "shared_name" : "E. S. D. H.",
        "name" : "E. S. D. H.",
        "SUID" : 3430,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 2216.4792045137374,
        "y" : -1907.1123242189558
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3425",
        "shared_name" : "Muriel Hardill",
        "name" : "Muriel Hardill",
        "SUID" : 3425,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 2145.385561325261,
        "y" : -2013.4237866212995
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3420",
        "shared_name" : "Alethea Graham",
        "name" : "Alethea Graham",
        "SUID" : 3420,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 1975.417818405339,
        "y" : -1797.743832092491
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3415",
        "shared_name" : "Jocelyne Gibson",
        "name" : "Jocelyne Gibson",
        "SUID" : 3415,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 2038.3251365205733,
        "y" : -1773.5548443605574
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3410",
        "shared_name" : "Gwendolen Freeman",
        "name" : "Gwendolen Freeman",
        "SUID" : 3410,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 2165.4111655733077,
        "y" : -1802.1605496217878
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3405",
        "shared_name" : "Margaret Diggle",
        "name" : "Margaret Diggle",
        "SUID" : 3405,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 2103.5063804170577,
        "y" : -1772.842838745323
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3400",
        "shared_name" : "An Anthology of Cambridge Women's Verse",
        "name" : "An Anthology of Cambridge Women's Verse",
        "SUID" : 3400,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 2074.074770309636,
        "y" : -1903.1897015382917
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3398",
        "shared_name" : "Margaret Thomas",
        "name" : "Margaret Thomas",
        "SUID" : 3398,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 2009.3678611299483,
        "y" : -1977.5988049318464
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3393",
        "shared_name" : "George Strauss, MP",
        "name" : "George Strauss, MP",
        "SUID" : 3393,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 1815.5279887697188,
        "y" : 947.00761749247
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3388",
        "shared_name" : "E. J. Strachey, MP",
        "name" : "E. J. Strachey, MP",
        "SUID" : 3388,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 1943.9054301759688,
        "y" : 845.40166046122
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3383",
        "shared_name" : "What We Saw in Russia",
        "name" : "What We Saw in Russia",
        "SUID" : 3383,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 1834.0357707521407,
        "y" : 838.5177340696184
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3381",
        "shared_name" : "Aneurin Bevan, MP",
        "name" : "Aneurin Bevan, MP",
        "SUID" : 3381,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 1765.0396312257735,
        "y" : 751.465007324013
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3364",
        "shared_name" : "On Being Ill",
        "name" : "On Being Ill",
        "SUID" : 3364,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -171.34817280559855,
        "y" : -1102.326740722862
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3359",
        "shared_name" : "Francis Brett Young",
        "name" : "Francis Brett Young",
        "SUID" : 3359,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -63.12283100872355,
        "y" : -461.25130126973704
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3351",
        "shared_name" : "Muriel Stuart",
        "name" : "Muriel Stuart",
        "SUID" : 3351,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -171.3611732938798,
        "y" : -298.8818554689558
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3346",
        "shared_name" : "J. C. Squire",
        "name" : "J. C. Squire",
        "SUID" : 3346,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -92.3460365751298,
        "y" : -420.67415283223704
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3341",
        "shared_name" : "Sacheverell Sitwell",
        "name" : "Sacheverell Sitwell",
        "SUID" : 3341,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -20.21560444622355,
        "y" : -490.1014904787214
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3327",
        "shared_name" : "Wilfred Owen",
        "name" : "Wilfred Owen",
        "SUID" : 3327,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -119.39822163372355,
        "y" : -315.98604248067454
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3322",
        "shared_name" : "Robert Nichols",
        "name" : "Robert Nichols",
        "SUID" : 3322,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -230.6857582548173,
        "y" : -268.63594482442454
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3311",
        "shared_name" : "James Joyce",
        "name" : "James Joyce",
        "SUID" : 3311,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -245.00890888958293,
        "y" : -322.00264404317454
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3306",
        "shared_name" : "Julian Grenfell",
        "name" : "Julian Grenfell",
        "SUID" : 3306,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -293.0803200223954,
        "y" : -467.8452343752058
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3298",
        "shared_name" : "Gerald Gould",
        "name" : "Gerald Gould",
        "SUID" : 3298,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -279.8450905302079,
        "y" : -522.5070690920027
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3293",
        "shared_name" : "John Freeman",
        "name" : "John Freeman",
        "SUID" : 3293,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -296.6825539091142,
        "y" : -303.8193554689558
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3285",
        "shared_name" : "John Drinkwater",
        "name" : "John Drinkwater",
        "SUID" : 3285,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -256.32034077434855,
        "y" : -378.5962109377058
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3277",
        "shared_name" : "Richard Church",
        "name" : "Richard Church",
        "SUID" : 3277,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -316.8458839872392,
        "y" : -357.5720410158308
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3272",
        "shared_name" : "Roy Campbell",
        "name" : "Roy Campbell",
        "SUID" : 3272,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -48.96999897747355,
        "y" : -375.21699951192454
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3267",
        "shared_name" : "Rupert Brooke",
        "name" : "Rupert Brooke",
        "SUID" : 3267,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -117.54165425091105,
        "y" : -370.4817089845808
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3259",
        "shared_name" : "Kenneth Ashley",
        "name" : "Kenneth Ashley",
        "SUID" : 3259,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -4.772306106379801,
        "y" : -411.40987060567454
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3254",
        "shared_name" : "Martin Armstrong",
        "name" : "Martin Armstrong",
        "SUID" : 3254,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -85.57241596966105,
        "y" : -528.7214855959089
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3249",
        "shared_name" : "Claude Colleer Abbott",
        "name" : "Claude Colleer Abbott",
        "SUID" : 3249,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -308.2271706083329,
        "y" : -416.28438232442454
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3244",
        "shared_name" : "A Broadcast Anthology of Modern Poetry",
        "name" : "A Broadcast Anthology of Modern Poetry",
        "SUID" : 3244,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -189.1029945829423,
        "y" : -465.26778076192454
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3239",
        "shared_name" : "Eugenio Montale",
        "name" : "Eugenio Montale",
        "SUID" : 3239,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -2305.044339797786,
        "y" : 936.590396423134
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3234",
        "shared_name" : "L. Collison-Morley",
        "name" : "L. Collison-Morley",
        "SUID" : 3234,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -2348.993314407161,
        "y" : 751.465007324013
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3229",
        "shared_name" : "The Nice Old Man and the Pretty Girl and other stories",
        "name" : "The Nice Old Man and the Pretty Girl and other stories",
        "SUID" : 3229,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -2269.9704262235673,
        "y" : 831.1578479001848
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3219",
        "shared_name" : "Occupied Territory",
        "name" : "Occupied Territory",
        "SUID" : 3219,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -559.5067574003251,
        "y" : 223.89420654276296
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3214",
        "shared_name" : "John Linton",
        "name" : "John Linton",
        "SUID" : 3214,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1364.031400344661,
        "y" : 190.91056396463796
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3209",
        "shared_name" : "The Notebook of Malte Laurids Brigge",
        "name" : "The Notebook of Malte Laurids Brigge",
        "SUID" : 3209,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1295.517728469661,
        "y" : 74.24479248026296
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3207",
        "shared_name" : "Rainer Maria Rilke",
        "name" : "Rainer Maria Rilke",
        "SUID" : 3207,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1223.785550735286,
        "y" : -84.72969482442454
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3199",
        "shared_name" : "Katherine John",
        "name" : "Katherine John",
        "SUID" : 3199,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -961.7855965116532,
        "y" : -1513.8717846681745
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3194",
        "shared_name" : "Life of Milton Together with Observations on Paradise Lost",
        "name" : "Life of Milton Together with Observations on Paradise Lost",
        "SUID" : 3194,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1055.426419875911,
        "y" : -1603.6313671877058
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3192",
        "shared_name" : "Louis Racine",
        "name" : "Louis Racine",
        "SUID" : 3192,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1137.4336220243486,
        "y" : -1705.9870190431745
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3187",
        "shared_name" : "Horace Liverlight",
        "name" : "Horace Liverlight",
        "SUID" : 3187,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -512.0278698423417,
        "y" : 1058.700099487099
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3182",
        "shared_name" : "Dear Judas and Other Poems",
        "name" : "Dear Judas and Other Poems",
        "SUID" : 3182,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -504.4982983091386,
        "y" : 947.9408984372942
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3174",
        "shared_name" : "History as Direction",
        "name" : "History as Direction",
        "SUID" : 3174,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 362.66220317096395,
        "y" : -473.2407421877058
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3172",
        "shared_name" : "John S. Hoyland",
        "name" : "John S. Hoyland",
        "SUID" : 3172,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 411.85165629596395,
        "y" : -332.0133251955183
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3164",
        "shared_name" : "Civilization and its Discontents",
        "name" : "Civilization and its Discontents",
        "SUID" : 3164,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 1356.4319594881026,
        "y" : -1570.7689862062605
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3159",
        "shared_name" : "Trekkie Ritchie (Parsons)",
        "name" : "Trekkie Ritchie (Parsons)",
        "SUID" : 3159,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -596.1776558378251,
        "y" : 131.25785400370046
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3154",
        "shared_name" : "Drifting Men",
        "name" : "Drifting Men",
        "SUID" : 3154,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -370.2910744169267,
        "y" : -87.10536621114329
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3149",
        "shared_name" : "Hugh Sykes",
        "name" : "Hugh Sykes",
        "SUID" : 3149,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -833.9759193876298,
        "y" : -755.2298931886824
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3144",
        "shared_name" : "Michael Redgrave",
        "name" : "Michael Redgrave",
        "SUID" : 3144,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -752.3053508618386,
        "y" : -658.2353710939558
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3139",
        "shared_name" : "Cambridge Poetry 1930",
        "name" : "Cambridge Poetry 1930",
        "SUID" : 3139,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -722.8631302335771,
        "y" : -764.0244641115339
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3131",
        "shared_name" : "The Art of Dying An Anthology",
        "name" : "The Art of Dying An Anthology",
        "SUID" : 3131,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 2544.5253985902755,
        "y" : -1801.1891369630964
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3123",
        "shared_name" : "Dawn on Mont Blanc Being Incidentally the tragedy of an aggravating young man",
        "name" : "Dawn on Mont Blanc Being Incidentally the tragedy of an aggravating young man",
        "SUID" : 3123,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1922.9780556180986,
        "y" : -1131.1234326173933
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3109",
        "shared_name" : "Night and Day",
        "name" : "Night and Day",
        "SUID" : 3109,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 58.6405356904952,
        "y" : -1330.1552319337995
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3104",
        "shared_name" : "Duckworth",
        "name" : "Duckworth",
        "SUID" : 3104,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 105.6791099092452,
        "y" : -1453.984913330284
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3099",
        "shared_name" : "The Voyage Out",
        "name" : "The Voyage Out",
        "SUID" : 3099,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 11.297945358463949,
        "y" : -1333.1818127443464
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3091",
        "shared_name" : "Beryl de Zoete",
        "name" : "Beryl de Zoete",
        "SUID" : 3091,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1939.2478615263017,
        "y" : 797.6941333005755
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3086",
        "shared_name" : "The Hoax",
        "name" : "The Hoax",
        "SUID" : 3086,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -2042.8971840360673,
        "y" : 818.6901393125383
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3084",
        "shared_name" : "Italo Svevo",
        "name" : "Italo Svevo",
        "SUID" : 3084,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -2155.9196449735673,
        "y" : 830.6530375669329
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3076",
        "shared_name" : "Paper Houses",
        "name" : "Paper Houses",
        "SUID" : 3076,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -908.4600502470048,
        "y" : -928.9510044862898
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3068",
        "shared_name" : "E. J. Trenchman",
        "name" : "E. J. Trenchman",
        "SUID" : 3068,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 1767.5034202119796,
        "y" : 1323.2145648191301
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3063",
        "shared_name" : "The Diary of Montaigne's Journey to Italy in 1580 and 1581",
        "name" : "The Diary of Montaigne's Journey to Italy in 1580 and 1581",
        "SUID" : 3063,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 1867.507692672917,
        "y" : 1292.485988158974
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3061",
        "shared_name" : "Michel de Montaigne",
        "name" : "Michel de Montaigne",
        "SUID" : 3061,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 1974.4646323701827,
        "y" : 1277.7765917966692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3056",
        "shared_name" : "Richard Kennedy",
        "name" : "Richard Kennedy",
        "SUID" : 3056,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1680.1938148954423,
        "y" : -1213.381428222862
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3051",
        "shared_name" : "Death of My Aunt",
        "name" : "Death of My Aunt",
        "SUID" : 3051,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1790.604886672786,
        "y" : -1365.4424023439558
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3046",
        "shared_name" : "Thos. J. Hewitt",
        "name" : "Thos. J. Hewitt",
        "SUID" : 3046,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 2074.4646323701827,
        "y" : 1277.7765917966692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3041",
        "shared_name" : "An Outline of Musical History Vol. I From the Earliest Times to Handel and Bach; Vol. II From C. P. E. Bach to Modern Music by Ralph Hill",
        "name" : "An Outline of Musical History Vol. I From the Earliest Times to Handel and Bach; Vol. II From C. P. E. Bach to Modern Music by Ralph Hill",
        "SUID" : 3041,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 2163.622164108464,
        "y" : 1339.809520263466
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3039",
        "shared_name" : "Ralph Hill",
        "name" : "Ralph Hill",
        "SUID" : 3039,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 2246.574312545964,
        "y" : 1408.6348376462786
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3034",
        "shared_name" : "Rabindranath Tagore",
        "name" : "Rabindranath Tagore",
        "SUID" : 3034,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 2094.393787719914,
        "y" : 947.00761749247
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3029",
        "shared_name" : "C. F. Andrews",
        "name" : "C. F. Andrews",
        "SUID" : 3029,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 2222.771229126164,
        "y" : 845.40166046122
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3024",
        "shared_name" : "A Woman of India. Being the Life of Saroj Nalini (Founder of the Women's Institute Movement in India)",
        "name" : "A Woman of India. Being the Life of Saroj Nalini (Founder of the Women's Institute Movement in India)",
        "SUID" : 3024,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 2112.901569702336,
        "y" : 838.5177340696184
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3022",
        "shared_name" : "G. S. Dutt",
        "name" : "G. S. Dutt",
        "SUID" : 3022,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 2043.9054301759688,
        "y" : 751.465007324013
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3014",
        "shared_name" : "John Davenport",
        "name" : "John Davenport",
        "SUID" : 3014,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -614.4150978544267,
        "y" : -830.2240490724714
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3009",
        "shared_name" : "Basil Wright",
        "name" : "Basil Wright",
        "SUID" : 3009,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -544.5513130643876,
        "y" : -802.0029034425886
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3004",
        "shared_name" : "Cambridge Poetry 1929",
        "name" : "Cambridge Poetry 1929",
        "SUID" : 3004,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -470.2955910184892,
        "y" : -904.9365353395613
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3002",
        "shared_name" : "Christopher Salmarshe",
        "name" : "Christopher Salmarshe",
        "SUID" : 3002,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -579.5503212430986,
        "y" : -912.1452450563581
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2997",
        "shared_name" : "Georg Kolbe",
        "name" : "Georg Kolbe",
        "SUID" : 2997,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 2373.2595866701095,
        "y" : 947.00761749247
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2992",
        "shared_name" : "Margaret M. Green",
        "name" : "Margaret M. Green",
        "SUID" : 2992,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 2501.6370280763595,
        "y" : 845.40166046122
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2987",
        "shared_name" : "Undying Faces",
        "name" : "Undying Faces",
        "SUID" : 2987,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 2391.7673686525313,
        "y" : 838.5177340696184
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2985",
        "shared_name" : "Ernst Benkard",
        "name" : "Ernst Benkard",
        "SUID" : 2985,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 2322.771229126164,
        "y" : 751.465007324013
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2980",
        "shared_name" : "Worthing Art Gallery",
        "name" : "Worthing Art Gallery",
        "SUID" : 2980,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 325.73275981158895,
        "y" : -1178.520359497276
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2975",
        "shared_name" : "Orlando A Biography",
        "name" : "Orlando A Biography",
        "SUID" : 2975,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 145.43283305377645,
        "y" : -1176.9972729494245
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2967",
        "shared_name" : "The Origins of the League Covenant Documentary History of Its Drafting",
        "name" : "The Origins of the League Covenant Documentary History of Its Drafting",
        "SUID" : 2967,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1644.9677559354814,
        "y" : 864.8601031492083
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2956",
        "shared_name" : "A Flying Scroll",
        "name" : "A Flying Scroll",
        "SUID" : 2956,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -239.01467671184855,
        "y" : -1266.8035778810652
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2951",
        "shared_name" : "E. McKnight Kauffer",
        "name" : "E. McKnight Kauffer",
        "SUID" : 2951,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 284.42416606158895,
        "y" : -636.058186035362
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2946",
        "shared_name" : "Lytton Strachey",
        "name" : "Lytton Strachey",
        "SUID" : 2946,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 614.0234092256514,
        "y" : -730.0598645021589
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2941",
        "shared_name" : "Words and Poetry",
        "name" : "Words and Poetry",
        "SUID" : 2941,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 496.21237406940145,
        "y" : -664.2832531740339
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2939",
        "shared_name" : "George W. H. Rylands",
        "name" : "George W. H. Rylands",
        "SUID" : 2939,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 652.5951865694014,
        "y" : -663.1295971681745
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2934",
        "shared_name" : "W. D. Robson-Scott",
        "name" : "W. D. Robson-Scott",
        "SUID" : 2934,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 1322.0979636690108,
        "y" : -1228.1474804689558
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2929",
        "shared_name" : "The Future of an Illusion",
        "name" : "The Future of an Illusion",
        "SUID" : 2929,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 1260.6497710725753,
        "y" : -1362.172413330284
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2924",
        "shared_name" : "H. N. Brailsford",
        "name" : "H. N. Brailsford",
        "SUID" : 2924,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -454.5751320341142,
        "y" : -780.9390148927839
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2919",
        "shared_name" : "The Triumphant Machine (A Study of Machine Civilization)",
        "name" : "The Triumphant Machine (A Study of Machine Civilization)",
        "SUID" : 2919,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -355.6966530302079,
        "y" : -556.9734387209089
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2917",
        "shared_name" : "R. M. Fox",
        "name" : "R. M. Fox",
        "SUID" : 2917,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -198.07327046184855,
        "y" : -350.79451416036204
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2912",
        "shared_name" : "D. Maclise",
        "name" : "D. Maclise",
        "SUID" : 2912,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 2346.574312545964,
        "y" : 1277.7765917966692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2907",
        "shared_name" : "L. E. L. A Mystery of the Thirties",
        "name" : "L. E. L. A Mystery of the Thirties",
        "SUID" : 2907,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 2435.731844284245,
        "y" : 1339.809520263466
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2905",
        "shared_name" : "D. E. Enfield",
        "name" : "D. E. Enfield",
        "SUID" : 2905,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 2518.683992721745,
        "y" : 1408.6348376462786
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2891",
        "shared_name" : "To the Lighthouse",
        "name" : "To the Lighthouse",
        "SUID" : 2891,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -333.4587074735673,
        "y" : -1060.959812622276
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2880",
        "shared_name" : "Voltaire A Biographical Fantasy",
        "name" : "Voltaire A Biographical Fantasy",
        "SUID" : 2880,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 67.82760844440145,
        "y" : -1130.364567260948
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2878",
        "shared_name" : "Laura Riding",
        "name" : "Laura Riding",
        "SUID" : 2878,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 248.0154136201827,
        "y" : -1099.491634826866
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2873",
        "shared_name" : "Jeffrey E. Jeffrey",
        "name" : "Jeffrey E. Jeffrey",
        "SUID" : 2873,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -517.7217079618486,
        "y" : -1784.7159619142683
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2868",
        "shared_name" : "Charles Young",
        "name" : "Charles Young",
        "SUID" : 2868,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -595.6457954862626,
        "y" : -1823.2359814455183
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2863",
        "shared_name" : "Henry B. Saxton",
        "name" : "Henry B. Saxton",
        "SUID" : 2863,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -434.2622047880204,
        "y" : -1788.195637207237
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2852",
        "shared_name" : "Basil Blackwell",
        "name" : "Basil Blackwell",
        "SUID" : 2852,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -542.7092415311845,
        "y" : -1844.289387207237
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2847",
        "shared_name" : "Michael Sadleir",
        "name" : "Michael Sadleir",
        "SUID" : 2847,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -651.7397591093095,
        "y" : -1729.7721142580183
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2842",
        "shared_name" : "Stanley Unwin",
        "name" : "Stanley Unwin",
        "SUID" : 2842,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -476.6512428739579,
        "y" : -1842.4271435548933
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2834",
        "shared_name" : "Books and the Public",
        "name" : "Books and the Public",
        "SUID" : 2834,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -521.7905251005204,
        "y" : -1666.1859326173933
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2832",
        "shared_name" : "The Editor of THE NATION",
        "name" : "The Editor of THE NATION",
        "SUID" : 2832,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -636.4110008695634,
        "y" : -1784.779865722862
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2821",
        "shared_name" : "The Nature of Beauty in Art and Literature",
        "name" : "The Nature of Beauty in Art and Literature",
        "SUID" : 2821,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -781.6314674833329,
        "y" : -1272.1768994142683
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2819",
        "shared_name" : "Charles Mauron",
        "name" : "Charles Mauron",
        "SUID" : 2819,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -904.5988899686845,
        "y" : -1352.1369519045027
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2814",
        "shared_name" : "[St. Win]",
        "name" : "[St. Win]",
        "SUID" : 2814,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1053.6149879911454,
        "y" : -2041.5414624025495
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2801",
        "shared_name" : "Interpretations",
        "name" : "Interpretations",
        "SUID" : 2801,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -992.8493629911454,
        "y" : -1923.4894604494245
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2799",
        "shared_name" : "Lydia Lopokova",
        "name" : "Lydia Lopokova",
        "SUID" : 2799,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -928.8611275175126,
        "y" : -1817.667316894737
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2794",
        "shared_name" : "Quentin Bell",
        "name" : "Quentin Bell",
        "SUID" : 2794,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -875.6263481596025,
        "y" : -1443.3385510255964
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2789",
        "shared_name" : "Mr. Baldin Explains and other Dream Interviews",
        "name" : "Mr. Baldin Explains and other Dream Interviews",
        "SUID" : 2789,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -810.2643562772782,
        "y" : -1561.9184155275495
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2787",
        "shared_name" : "Peter Ibbetson",
        "name" : "Peter Ibbetson",
        "SUID" : 2787,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -680.6644112089189,
        "y" : -1638.4059033205183
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2779",
        "shared_name" : "Cezanne A Study of His Development",
        "name" : "Cezanne A Study of His Development",
        "SUID" : 2779,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -770.6339928129228,
        "y" : -1192.3910260011824
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2771",
        "shared_name" : "The Ego and the Id",
        "name" : "The Ego and the Id",
        "SUID" : 2771,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 1331.9784549257247,
        "y" : -1475.5059857179792
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2766",
        "shared_name" : "W. T. Symons",
        "name" : "W. T. Symons",
        "SUID" : 2766,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 3104.730577804753,
        "y" : -1954.2580914308699
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2761",
        "shared_name" : "Egerton Swann",
        "name" : "Egerton Swann",
        "SUID" : 2761,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 2867.800630905339,
        "y" : -1945.384815674034
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2756",
        "shared_name" : "Maurice B. Recckitt",
        "name" : "Maurice B. Recckitt",
        "SUID" : 2756,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 2927.5795920869796,
        "y" : -2033.858494262901
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2751",
        "shared_name" : "Alan Porter",
        "name" : "Alan Porter",
        "SUID" : 2751,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 2981.415926315495,
        "y" : -1809.889148931709
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2746",
        "shared_name" : "Albert Newsome",
        "name" : "Albert Newsome",
        "SUID" : 2746,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 3070.974947311589,
        "y" : -1843.0282006075056
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2741",
        "shared_name" : "Philippe Mairet",
        "name" : "Philippe Mairet",
        "SUID" : 2741,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 2891.2648948213546,
        "y" : -1857.0405659486921
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2736",
        "shared_name" : "Coal A Challenge to the National Conscience",
        "name" : "Coal A Challenge to the National Conscience",
        "SUID" : 2736,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 2986.401491501042,
        "y" : -1929.0616497804792
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2734",
        "shared_name" : "V. A. Dermant",
        "name" : "V. A. Dermant",
        "SUID" : 2734,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 3030.430025436589,
        "y" : -2041.5414624025495
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2729",
        "shared_name" : "Alix Strachey",
        "name" : "Alix Strachey",
        "SUID" : 2729,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 1124.3242057344405,
        "y" : -1810.7406964113386
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2724",
        "shared_name" : "Douglas Bryan",
        "name" : "Douglas Bryan",
        "SUID" : 2724,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 1169.0060447236983,
        "y" : -1771.2672619630964
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2716",
        "shared_name" : "Selected Papers of Karl Abraham",
        "name" : "Selected Papers of Karl Abraham",
        "SUID" : 2716,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 1220.3537620088546,
        "y" : -1884.814289550987
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2714",
        "shared_name" : "Karl Abraham",
        "name" : "Karl Abraham",
        "SUID" : 2714,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 1170.5216849824874,
        "y" : -1997.7716564943464
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2709",
        "shared_name" : "Theodore Besterman",
        "name" : "Theodore Besterman",
        "SUID" : 2709,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 2618.683992721745,
        "y" : 1277.7765917966692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2704",
        "shared_name" : "Youth: The Magazine of the British Federation of Youth",
        "name" : "Youth: The Magazine of the British Federation of Youth",
        "SUID" : 2704,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 2707.8415244600264,
        "y" : 1339.809520263466
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2702",
        "shared_name" : "Youth",
        "name" : "Youth",
        "SUID" : 2702,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 2790.7936728975264,
        "y" : 1408.6348376462786
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2691",
        "shared_name" : "April Morning",
        "name" : "April Morning",
        "SUID" : 2691,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -239.1914955595048,
        "y" : -1305.052296142784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2689",
        "shared_name" : "Stanley Snaith",
        "name" : "Stanley Snaith",
        "SUID" : 2689,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -357.4249855497392,
        "y" : -1360.5615429689558
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2678",
        "shared_name" : "Chorus of the Newly Dead",
        "name" : "Chorus of the Newly Dead",
        "SUID" : 2678,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 90.5538657686202,
        "y" : -1380.6610913087995
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2664",
        "shared_name" : "Martha Wish-You-Ill",
        "name" : "Martha Wish-You-Ill",
        "SUID" : 2664,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -3.9091469266923013,
        "y" : -1155.6467175295027
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2656",
        "shared_name" : "Jane Isabel Suttie",
        "name" : "Jane Isabel Suttie",
        "SUID" : 2656,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 1162.8327201387374,
        "y" : -995.2651867677839
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2651",
        "shared_name" : "Further Contributions to the Theory and Technique of Psycho-Analysis",
        "name" : "Further Contributions to the Theory and Technique of Psycho-Analysis",
        "SUID" : 2651,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 1106.3877128145186,
        "y" : -1101.8150830080183
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2649",
        "shared_name" : "Sandor Ferenczi",
        "name" : "Sandor Ferenczi",
        "SUID" : 2649,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 1047.7304709932296,
        "y" : -995.6877331545027
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2641",
        "shared_name" : "Time and Change Poems",
        "name" : "Time and Change Poems",
        "SUID" : 2641,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 3249.0579093477218,
        "y" : -1940.2622265627058
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2639",
        "shared_name" : "Mary Stella Edwards",
        "name" : "Mary Stella Edwards",
        "SUID" : 2639,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 3204.730577804753,
        "y" : -2041.5414624025495
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2628",
        "shared_name" : "Victorian Photographs of Famous Men & Fair Women",
        "name" : "Victorian Photographs of Famous Men & Fair Women",
        "SUID" : 2628,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -419.4525124052079,
        "y" : -1246.8763775636824
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2626",
        "shared_name" : "Julia Margaret Cameron",
        "name" : "Julia Margaret Cameron",
        "SUID" : 2626,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -480.4157387235673,
        "y" : -1364.6138806154402
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2621",
        "shared_name" : "Bishop Gore",
        "name" : "Bishop Gore",
        "SUID" : 2621,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 2890.7936728975264,
        "y" : 1277.7765917966692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2616",
        "shared_name" : "The People of Ararat",
        "name" : "The People of Ararat",
        "SUID" : 2616,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 2979.9512046358077,
        "y" : 1339.809520263466
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2614",
        "shared_name" : "Joseph Burtt",
        "name" : "Joseph Burtt",
        "SUID" : 2614,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 3062.9033530733077,
        "y" : 1408.6348376462786
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2609",
        "shared_name" : "G. K. Chesterton",
        "name" : "G. K. Chesterton",
        "SUID" : 2609,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 3162.9033530733077,
        "y" : 1277.7765917966692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2604",
        "shared_name" : "Chosen Poems",
        "name" : "Chosen Poems",
        "SUID" : 2604,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 3252.060884811589,
        "y" : 1339.809520263466
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2602",
        "shared_name" : "Douglas Ainslie",
        "name" : "Douglas Ainslie",
        "SUID" : 2602,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 3335.013033249089,
        "y" : 1408.6348376462786
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2594",
        "shared_name" : "Mrs. Dalloway",
        "name" : "Mrs. Dalloway",
        "SUID" : 2594,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -116.3395668485673,
        "y" : -996.4617991258772
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2583",
        "shared_name" : "The Common Reader",
        "name" : "The Common Reader",
        "SUID" : 2583,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -318.3929115751298,
        "y" : -1108.0114941408308
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2572",
        "shared_name" : "Poems and Fables",
        "name" : "Poems and Fables",
        "SUID" : 2572,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 172.82223735065145,
        "y" : -1144.628468017784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2561",
        "shared_name" : "Russet and Taffeta",
        "name" : "Russet and Taffeta",
        "SUID" : 2561,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -17.32058491497355,
        "y" : -1378.4938549806745
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2550",
        "shared_name" : "Songs of Salvation Sin & Satire",
        "name" : "Songs of Salvation Sin & Satire",
        "SUID" : 2550,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -26.73879780559855,
        "y" : -1436.5922436525495
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2542",
        "shared_name" : "Anonymity An Enquiry",
        "name" : "Anonymity An Enquiry",
        "SUID" : 2542,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -440.3489662626298,
        "y" : -1117.834896545616
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2537",
        "shared_name" : "A. W. Devis",
        "name" : "A. W. Devis",
        "SUID" : 2537,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -386.8970924833329,
        "y" : -1661.0400585939558
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2529",
        "shared_name" : "Original Letters from India (1779-1815)",
        "name" : "Original Letters from India (1779-1815)",
        "SUID" : 2529,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -459.5288979032548,
        "y" : -1523.4372143556745
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2527",
        "shared_name" : "Mrs. Eliza Fay",
        "name" : "Mrs. Eliza Fay",
        "SUID" : 2527,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -450.4882790067704,
        "y" : -1673.2439160158308
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2516",
        "shared_name" : "Eugene McCown",
        "name" : "Eugene McCown",
        "SUID" : 2516,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -4.861966750911051,
        "y" : -1533.5221752931745
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2505",
        "shared_name" : "Parallax",
        "name" : "Parallax",
        "SUID" : 2505,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -48.77639546184855,
        "y" : -1346.3907971193464
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2503",
        "shared_name" : "Nancy Cunard",
        "name" : "Nancy Cunard",
        "SUID" : 2503,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 52.86288676471395,
        "y" : -1508.464680175987
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2495",
        "shared_name" : "Adriatica and Other Poems",
        "name" : "Adriatica and Other Poems",
        "SUID" : 2495,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 2641.243631698796,
        "y" : -1929.3402600099714
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2493",
        "shared_name" : "Ferenc Békássy",
        "name" : "Ferenc Békássy",
        "SUID" : 2493,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 2623.5719245454757,
        "y" : -2041.5414624025495
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2479",
        "shared_name" : "Grace After Meat",
        "name" : "Grace After Meat",
        "SUID" : 2479,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 31.2753013154952,
        "y" : -983.2034516145857
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2477",
        "shared_name" : "John Crowe Ransom",
        "name" : "John Crowe Ransom",
        "SUID" : 2477,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 196.74337992877645,
        "y" : -913.9284405519636
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2472",
        "shared_name" : "Professor Gilbert Murray",
        "name" : "Professor Gilbert Murray",
        "SUID" : 2472,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 3280.2683509370772,
        "y" : -1831.822102050987
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2467",
        "shared_name" : "Kenya",
        "name" : "Kenya",
        "SUID" : 2467,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 3305.6923087617843,
        "y" : -1718.4627651979597
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2459",
        "shared_name" : "Mock Beggar Hill",
        "name" : "Mock Beggar Hill",
        "SUID" : 2459,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 213.27548442096395,
        "y" : -764.2115216066511
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2454",
        "shared_name" : "Joan Riviere",
        "name" : "Joan Riviere",
        "SUID" : 2454,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 1452.9930900117843,
        "y" : -1502.936375122276
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2449",
        "shared_name" : "Collected Papers",
        "name" : "Collected Papers",
        "SUID" : 2449,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 1328.0363305589644,
        "y" : -1526.6956982423933
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2438",
        "shared_name" : "Henry James at Work",
        "name" : "Henry James at Work",
        "SUID" : 2438,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -119.9510170438798,
        "y" : -1411.649738769737
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2433",
        "shared_name" : "Prince D. S. Mirsky",
        "name" : "Prince D. S. Mirsky",
        "SUID" : 2433,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 752.184419967839,
        "y" : -630.0619091798933
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2421",
        "shared_name" : "Jane Harrison",
        "name" : "Jane Harrison",
        "SUID" : 2421,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 674.2802451631514,
        "y" : -513.4710583498152
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2416",
        "shared_name" : "The Life of the Archpriest Avvakum by Himself",
        "name" : "The Life of the Archpriest Avvakum by Himself",
        "SUID" : 2416,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 604.385591842839,
        "y" : -640.8713269045027
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2414",
        "shared_name" : "Avvakum",
        "name" : "Avvakum",
        "SUID" : 2414,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 725.6369346162764,
        "y" : -561.975910644737
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2403",
        "shared_name" : "Tolstoi's Love Letters with a study of the autobiographical elements in Tolstoi's work, by Paul Biryukov",
        "name" : "Tolstoi's Love Letters with a study of the autobiographical elements in Tolstoi's work, by Paul Biryukov",
        "SUID" : 2403,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -77.61807026653605,
        "y" : -1440.2269482423933
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2401",
        "shared_name" : "Leo Tolstoy",
        "name" : "Leo Tolstoy",
        "SUID" : 2401,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -141.1226479032548,
        "y" : -1673.8456005861433
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2396",
        "shared_name" : "Harold Wright",
        "name" : "Harold Wright",
        "SUID" : 2396,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -2348.993314407161,
        "y" : 1508.6348376462786
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2391",
        "shared_name" : "Letters",
        "name" : "Letters",
        "SUID" : 2391,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -2259.83578266888,
        "y" : 1570.6677661130755
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2389",
        "shared_name" : "Stephen Reynolds",
        "name" : "Stephen Reynolds",
        "SUID" : 2389,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -2176.88363423138,
        "y" : 1639.493083495888
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2378",
        "shared_name" : "Mutations of the Phoenix",
        "name" : "Mutations of the Phoenix",
        "SUID" : 2378,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -120.24966206341105,
        "y" : -1460.0844921877058
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2365",
        "shared_name" : "Poems_9",
        "name" : "Poems_9",
        "SUID" : 2365,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -692.726152084163,
        "y" : -1546.9702343752058
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2363",
        "shared_name" : "Gordon Hannington Luce",
        "name" : "Gordon Hannington Luce",
        "SUID" : 2363,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -742.1981064298661,
        "y" : -1689.3110546877058
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2352",
        "shared_name" : "To a Proud Phantom",
        "name" : "To a Proud Phantom",
        "SUID" : 2352,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -159.67141499309855,
        "y" : -1370.624104004112
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2350",
        "shared_name" : "Ena Limebeer",
        "name" : "Ena Limebeer",
        "SUID" : 2350,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -200.27053608684855,
        "y" : -1550.0230908205183
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2339",
        "shared_name" : "William Nicholson",
        "name" : "William Nicholson",
        "SUID" : 2339,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 141.7002280733077,
        "y" : -851.7745251466902
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2334",
        "shared_name" : "The Feather Bed",
        "name" : "The Feather Bed",
        "SUID" : 2334,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -4.969449661067301,
        "y" : -968.1166004945906
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2323",
        "shared_name" : "Talks with Tolstoi",
        "name" : "Talks with Tolstoi",
        "SUID" : 2323,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 129.47592387408895,
        "y" : -1299.6633496095808
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2321",
        "shared_name" : "A. B. Goldenveizer",
        "name" : "A. B. Goldenveizer",
        "SUID" : 2321,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 299.76681742877645,
        "y" : -1355.199787597862
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2307",
        "shared_name" : "A Sampler of Castile",
        "name" : "A Sampler of Castile",
        "SUID" : 2307,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -696.6284767606767,
        "y" : -1323.0910229494245
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2302",
        "shared_name" : "C. P. Cavafy",
        "name" : "C. P. Cavafy",
        "SUID" : 2302,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -393.5030189970048,
        "y" : -1448.4100842287214
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2291",
        "shared_name" : "Pharos and Pharillon",
        "name" : "Pharos and Pharillon",
        "SUID" : 2291,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -311.78823628216105,
        "y" : -1307.9591259767683
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2277",
        "shared_name" : "The Waste Land",
        "name" : "The Waste Land",
        "SUID" : 2277,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -74.90139546184855,
        "y" : -1042.9563259889753
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2269",
        "shared_name" : "Duncan Grant",
        "name" : "Duncan Grant",
        "SUID" : 2269,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -557.3784615018876,
        "y" : -1386.771534424034
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2258",
        "shared_name" : "The Legend of Monte Della Sibilla or Le Paradis de la Reine Sibille",
        "name" : "The Legend of Monte Della Sibilla or Le Paradis de la Reine Sibille",
        "SUID" : 2258,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -320.54519428997355,
        "y" : -1259.5823864748152
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2250",
        "shared_name" : "Jacob's Room",
        "name" : "Jacob's Room",
        "SUID" : 2250,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -234.59621968059855,
        "y" : -1094.6730236818464
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2239",
        "shared_name" : "Vasilii Spiridonov",
        "name" : "Vasilii Spiridonov",
        "SUID" : 2239,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 304.16757426471395,
        "y" : -1437.512501220909
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2234",
        "shared_name" : "The Autobiography of Countess Sophie Tolstoi",
        "name" : "The Autobiography of Countess Sophie Tolstoi",
        "SUID" : 2234,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 137.74582133502645,
        "y" : -1365.3598522951277
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2232",
        "shared_name" : "Countess Sophie Tolstoi",
        "name" : "Countess Sophie Tolstoi",
        "SUID" : 2232,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 258.1208823701827,
        "y" : -1497.8700146486433
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2219",
        "shared_name" : "Daybreak",
        "name" : "Daybreak",
        "SUID" : 2219,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -187.5647865751298,
        "y" : -1263.2421459962995
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2217",
        "shared_name" : "Fredegond Shove",
        "name" : "Fredegond Shove",
        "SUID" : 2217,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -118.7509438016923,
        "y" : -1326.7899670412214
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2206",
        "shared_name" : "Karn",
        "name" : "Karn",
        "SUID" : 2206,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -27.7947670438798,
        "y" : -1109.7005505373152
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2204",
        "shared_name" : "Ruth Manning-Sanders",
        "name" : "Ruth Manning-Sanders",
        "SUID" : 2204,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 115.5488608858077,
        "y" : -1075.0743374635847
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2199",
        "shared_name" : "James Strachey",
        "name" : "James Strachey",
        "SUID" : 2199,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 982.6030906221358,
        "y" : -1430.1622509767683
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2194",
        "shared_name" : "Group Psychology and the Analysis of the Ego",
        "name" : "Group Psychology and the Analysis of the Ego",
        "SUID" : 2194,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 1073.2461265108077,
        "y" : -1504.06757782003
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2189",
        "shared_name" : "C. J. M. Hubback",
        "name" : "C. J. M. Hubback",
        "SUID" : 2189,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 1415.9555915376632,
        "y" : -1654.1959996034773
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2184",
        "shared_name" : "Beyond the Pleasure Principle",
        "name" : "Beyond the Pleasure Principle",
        "SUID" : 2184,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 1294.3948405763595,
        "y" : -1619.4926609804304
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2182",
        "shared_name" : "Sigmund Freud",
        "name" : "Sigmund Freud",
        "SUID" : 2182,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 1208.9204429170577,
        "y" : -1525.2756771852644
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2171",
        "shared_name" : "Stavrogin's Confession and The Plan of the Life of a Great Sinner",
        "name" : "Stavrogin's Confession and The Plan of the Life of a Great Sinner",
        "SUID" : 2171,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 45.2369712373702,
        "y" : -1380.1245312502058
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2169",
        "shared_name" : "F. M. Dostoevsky",
        "name" : "F. M. Dostoevsky",
        "SUID" : 2169,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 162.77914653033895,
        "y" : -1515.8730053712995
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2164",
        "shared_name" : "unnamed person in Czechoslovakia",
        "name" : "unnamed person in Czechoslovakia",
        "SUID" : 2164,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 6.509981491276449,
        "y" : -830.5751690675886
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2159",
        "shared_name" : "D. H. Lawrence",
        "name" : "D. H. Lawrence",
        "SUID" : 2159,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -137.46841206341105,
        "y" : -686.1671032716902
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2148",
        "shared_name" : "The Gentleman from San Francisco and other stories",
        "name" : "The Gentleman from San Francisco and other stories",
        "SUID" : 2148,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -105.52602925091105,
        "y" : -918.4835705568464
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2146",
        "shared_name" : "Ivan Bunin",
        "name" : "Ivan Bunin",
        "SUID" : 2146,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -233.9104897001298,
        "y" : -576.3535656740339
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2141",
        "shared_name" : "K. Walter",
        "name" : "K. Walter",
        "SUID" : 2141,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 2652.1253856203048,
        "y" : 947.00761749247
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2136",
        "shared_name" : "L. A. Magnus",
        "name" : "L. A. Magnus",
        "SUID" : 2136,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 2780.5028270265548,
        "y" : 845.40166046122
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2131",
        "shared_name" : "The Dark",
        "name" : "The Dark",
        "SUID" : 2131,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 2670.6331676027266,
        "y" : 838.5177340696184
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2129",
        "shared_name" : "Leonid Andreev",
        "name" : "Leonid Andreev",
        "SUID" : 2129,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 2601.6370280763595,
        "y" : 751.465007324013
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2108",
        "shared_name" : "Monday or Tuesday",
        "name" : "Monday or Tuesday",
        "SUID" : 2108,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -169.3959633329423,
        "y" : -1139.2398876955183
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2097",
        "shared_name" : "Stories of the East",
        "name" : "Stories of the East",
        "SUID" : 2097,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -45.5939613798173,
        "y" : -1274.5219006349714
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2093",
        "shared_name" : "Siegfried Sassoon",
        "name" : "Siegfried Sassoon",
        "SUID" : 2093,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -278.3372475126298,
        "y" : -622.9659619142683
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2082",
        "shared_name" : "Poems_8",
        "name" : "Poems_8",
        "SUID" : 2082,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -218.24404682903605,
        "y" : -1009.591934662071
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2080",
        "shared_name" : "Frank Prewett",
        "name" : "Frank Prewett",
        "SUID" : 2080,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -318.2117592313798,
        "y" : -807.497379760948
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2069",
        "shared_name" : "The Note-Books of Anton Tchekhov Together with Reminiscences of Tchekhov",
        "name" : "The Note-Books of Anton Tchekhov Together with Reminiscences of Tchekhov",
        "SUID" : 2069,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 49.6959556123702,
        "y" : -1180.9948010255964
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2064",
        "shared_name" : "a little man in Holborn",
        "name" : "a little man in Holborn",
        "SUID" : 2064,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -494.5636879423173,
        "y" : -1234.6159558107527
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2050",
        "shared_name" : "Twelve Original Woodcuts",
        "name" : "Twelve Original Woodcuts",
        "SUID" : 2050,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -340.7043129423173,
        "y" : -1212.4831280519636
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2039",
        "shared_name" : "Poems_7",
        "name" : "Poems_7",
        "SUID" : 2039,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -196.9185463407548,
        "y" : -1332.9457287599714
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2028",
        "shared_name" : "Stories from the Old Testament Retold by Logan Pearsall Smith",
        "name" : "Stories from the Old Testament Retold by Logan Pearsall Smith",
        "SUID" : 2028,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -283.44155659466105,
        "y" : -1201.7643780519636
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2020",
        "shared_name" : "S. S. Koteliansky",
        "name" : "S. S. Koteliansky",
        "SUID" : 2020,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -2.6167885282548013,
        "y" : -1247.0038494875105
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2015",
        "shared_name" : "Reminiscences of Leo Nicolayevitch Tolstoi",
        "name" : "Reminiscences of Leo Nicolayevitch Tolstoi",
        "SUID" : 2015,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 93.11874613971395,
        "y" : -1227.268162231651
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2013",
        "shared_name" : "Maxim Gorky",
        "name" : "Maxim Gorky",
        "SUID" : 2013,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 215.8039878389327,
        "y" : -1202.522999267784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2002",
        "shared_name" : "The Inward Animal",
        "name" : "The Inward Animal",
        "SUID" : 2002,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -2076.88363423138,
        "y" : 1719.7560839841692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1997",
        "shared_name" : "The Sun My Monument",
        "name" : "The Sun My Monument",
        "SUID" : 1997,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 577.1355613252608,
        "y" : 1616.374187011513
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1995",
        "shared_name" : "Laurie Lee",
        "name" : "Laurie Lee",
        "SUID" : 1995,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 579.4571517488448,
        "y" : 1508.6348376462786
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1990",
        "shared_name" : "A Lost Season",
        "name" : "A Lost Season",
        "SUID" : 1990,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1929.438123367122,
        "y" : 1719.7560839841692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1985",
        "shared_name" : "Lost Planet and Other Poems",
        "name" : "Lost Planet and Other Poems",
        "SUID" : 1985,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -349.7415443876298,
        "y" : -688.776691894737
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1980",
        "shared_name" : "From Thirty Years With Freud",
        "name" : "From Thirty Years With Freud",
        "SUID" : 1980,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 868.6853354951827,
        "y" : -1807.0056347658308
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1978",
        "shared_name" : "Theodor Reik",
        "name" : "Theodor Reik",
        "SUID" : 1978,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 960.024996139714,
        "y" : -1725.0245861818464
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1973",
        "shared_name" : "Forty Poems",
        "name" : "Forty Poems",
        "SUID" : 1973,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1600.9953896024736,
        "y" : -893.4553799440534
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1968",
        "shared_name" : "The Calcium Bread Scandal",
        "name" : "The Calcium Bread Scandal",
        "SUID" : 1968,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -2198.8640419462236,
        "y" : -1444.4360241701277
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1966",
        "shared_name" : "Dr. I. Harris",
        "name" : "Dr. I. Harris",
        "SUID" : 1966,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -2068.989164016536,
        "y" : -1368.0737194826277
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1961",
        "shared_name" : "The Middle of a War",
        "name" : "The Middle of a War",
        "SUID" : 1961,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1881.9926125028642,
        "y" : 1508.6348376462786
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1959",
        "shared_name" : "Roy Fuller",
        "name" : "Roy Fuller",
        "SUID" : 1959,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1903.8853126981767,
        "y" : 1615.0239672849505
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1954",
        "shared_name" : "Aftermath",
        "name" : "Aftermath",
        "SUID" : 1954,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 698.304781295964,
        "y" : -1160.7577099611433
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1949",
        "shared_name" : "Poems_6",
        "name" : "Poems_6",
        "SUID" : 1949,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -2029.438123367122,
        "y" : 1508.6348376462786
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1947",
        "shared_name" : "Terence Tiller",
        "name" : "Terence Tiller",
        "SUID" : 1947,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -2051.3308235624345,
        "y" : 1615.0239672849505
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1942",
        "shared_name" : "Selected Poems_3",
        "name" : "Selected Poems_3",
        "SUID" : 1942,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -632.4860512235673,
        "y" : -231.8838085939558
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1937",
        "shared_name" : "Portrait of a Lady or The English Spirit Old and New",
        "name" : "Portrait of a Lady or The English Spirit Old and New",
        "SUID" : 1937,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1781.9926125028642,
        "y" : 1719.7560839841692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1932",
        "shared_name" : "Why the German Republic Fell and other studies of the causes and consequences of economic inequality",
        "name" : "Why the German Republic Fell and other studies of the causes and consequences of economic inequality",
        "SUID" : 1932,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 679.4571517488448,
        "y" : 1616.374187011513
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1930",
        "shared_name" : "A. W. Madsen",
        "name" : "A. W. Madsen",
        "SUID" : 1930,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 681.7787421724288,
        "y" : 1508.6348376462786
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1925",
        "shared_name" : "The Colour Bar in East Africa",
        "name" : "The Colour Bar in East Africa",
        "SUID" : 1925,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 3442.578634597966,
        "y" : -1562.3417782594831
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1920",
        "shared_name" : "Country Notes in Wartime",
        "name" : "Country Notes in Wartime",
        "SUID" : 1920,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -375.11575093059855,
        "y" : -152.98140380879954
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1915",
        "shared_name" : "Selected Poems_2",
        "name" : "Selected Poems_2",
        "SUID" : 1915,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1117.594144485286,
        "y" : -524.6668896486433
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1910",
        "shared_name" : "Pack My Bag: A Self-Portrait",
        "name" : "Pack My Bag: A Self-Portrait",
        "SUID" : 1910,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -56.7360512235673,
        "y" : -312.6861767580183
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1908",
        "shared_name" : "Henry Green",
        "name" : "Henry Green",
        "SUID" : 1908,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -197.82681050091105,
        "y" : -404.3133740236433
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1903",
        "shared_name" : "Control of Aliens in the British Commonwealth of Nations",
        "name" : "Control of Aliens in the British Commonwealth of Nations",
        "SUID" : 1903,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 781.7787421724288,
        "y" : 1616.374187011513
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1901",
        "shared_name" : "C. F. Fraser",
        "name" : "C. F. Fraser",
        "SUID" : 1901,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 784.1003325960128,
        "y" : 1508.6348376462786
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1896",
        "shared_name" : "Selected Poems_1",
        "name" : "Selected Poems_1",
        "SUID" : 1896,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1022.4618507841142,
        "y" : -1049.0407681276472
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1891",
        "shared_name" : "The Hotel: A Play in Three Acts",
        "name" : "The Hotel: A Play in Three Acts",
        "SUID" : 1891,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 9.915376999088949,
        "y" : -1422.362354736534
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1886",
        "shared_name" : "The New Realism A Discussion",
        "name" : "The New Realism A Discussion",
        "SUID" : 1886,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1484.0523354032548,
        "y" : -500.41930053731517
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1884",
        "shared_name" : "Stephen Spender",
        "name" : "Stephen Spender",
        "SUID" : 1884,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1373.3547646024736,
        "y" : -555.890217285362
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1879",
        "shared_name" : "The German Army",
        "name" : "The German Army",
        "SUID" : 1879,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 884.1003325960128,
        "y" : 1616.374187011513
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1877",
        "shared_name" : "Herbert Rosinski",
        "name" : "Herbert Rosinski",
        "SUID" : 1877,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 886.4219230195968,
        "y" : 1508.6348376462786
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1872",
        "shared_name" : "Supersition and Society",
        "name" : "Supersition and Society",
        "SUID" : 1872,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 1757.5463279268233,
        "y" : -1886.2444042970808
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1867",
        "shared_name" : "What I Believe",
        "name" : "What I Believe",
        "SUID" : 1867,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -605.2749458768876,
        "y" : -1431.8348278810652
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1862",
        "shared_name" : "Antiquarian Paradise",
        "name" : "Antiquarian Paradise",
        "SUID" : 1862,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 986.4219230195968,
        "y" : 1616.374187011513
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1860",
        "shared_name" : "John Betjeman",
        "name" : "John Betjeman",
        "SUID" : 1860,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 988.7435134431807,
        "y" : 1508.6348376462786
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1855",
        "shared_name" : "The Artist and His Public",
        "name" : "The Artist and His Public",
        "SUID" : 1855,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 1088.7435134431807,
        "y" : 1616.374187011513
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1853",
        "shared_name" : "Graham Bell",
        "name" : "Graham Bell",
        "SUID" : 1853,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 1091.0651038667647,
        "y" : 1508.6348376462786
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1848",
        "shared_name" : "Solitude A Poem",
        "name" : "Solitude A Poem",
        "SUID" : 1848,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -596.1620918729814,
        "y" : -290.3187451173933
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1843",
        "shared_name" : "Tribune of Rome A Biography of Cola di Rienzo",
        "name" : "Tribune of Rome A Biography of Cola di Rienzo",
        "SUID" : 1843,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1634.5471016386064,
        "y" : 1719.7560839841692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1838",
        "shared_name" : "The Writings of E. M. Forster",
        "name" : "The Writings of E. M. Forster",
        "SUID" : 1838,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 2927.9485209962813,
        "y" : 947.7670703122942
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1833",
        "shared_name" : "The Political and Social Doctrine of Communism",
        "name" : "The Political and Social Doctrine of Communism",
        "SUID" : 1833,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 1191.0651038667647,
        "y" : 1616.374187011513
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1831",
        "shared_name" : "R. Palme Dutt",
        "name" : "R. Palme Dutt",
        "SUID" : 1831,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 1193.3866942903487,
        "y" : 1508.6348376462786
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1826",
        "shared_name" : "Books and the People",
        "name" : "Books and the People",
        "SUID" : 1826,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 1293.3866942903487,
        "y" : 1616.374187011513
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1824",
        "shared_name" : "Margaret Cole",
        "name" : "Margaret Cole",
        "SUID" : 1824,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 1295.7082847139327,
        "y" : 1508.6348376462786
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1819",
        "shared_name" : "The Machinery of Socialist Planning",
        "name" : "The Machinery of Socialist Planning",
        "SUID" : 1819,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1487.1015907743486,
        "y" : 1719.7560839841692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1814",
        "shared_name" : "The Refugees",
        "name" : "The Refugees",
        "SUID" : 1814,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 1395.7082847139327,
        "y" : 1616.374187011513
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1812",
        "shared_name" : "Libby Benedict",
        "name" : "Libby Benedict",
        "SUID" : 1812,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 1398.0298751375167,
        "y" : 1508.6348376462786
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1807",
        "shared_name" : "Poems_5",
        "name" : "Poems_5",
        "SUID" : 1807,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 1498.0298751375167,
        "y" : 1616.374187011513
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1805",
        "shared_name" : "Kenneth Allott",
        "name" : "Kenneth Allott",
        "SUID" : 1805,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 1500.3514655611007,
        "y" : 1508.6348376462786
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1800",
        "shared_name" : "Mazzini, Garibaldi & Cavour",
        "name" : "Mazzini, Garibaldi & Cavour",
        "SUID" : 1800,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 1600.3514655611007,
        "y" : 1616.374187011513
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1798",
        "shared_name" : "Marjorie Strachey",
        "name" : "Marjorie Strachey",
        "SUID" : 1798,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 1602.6730559846847,
        "y" : 1508.6348376462786
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1793",
        "shared_name" : "Dream Analysis A Practical Handbook for Psycho-Analysts",
        "name" : "Dream Analysis A Practical Handbook for Psycho-Analysts",
        "SUID" : 1793,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 1702.6730559846847,
        "y" : 1616.374187011513
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1791",
        "shared_name" : "Ella Freeman Sharpe",
        "name" : "Ella Freeman Sharpe",
        "SUID" : 1791,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 1704.9946464082686,
        "y" : 1508.6348376462786
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1786",
        "shared_name" : "Pepita",
        "name" : "Pepita",
        "SUID" : 1786,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -503.1740089872392,
        "y" : -66.17317626973704
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1781",
        "shared_name" : "Joan of Arc",
        "name" : "Joan of Arc",
        "SUID" : 1781,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -594.6839119413407,
        "y" : -156.0597119142683
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1776",
        "shared_name" : "Darwin",
        "name" : "Darwin",
        "SUID" : 1776,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -2061.7273231962236,
        "y" : -1488.878956299034
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1771",
        "shared_name" : "The Military Training of Youth An enquiry into the aims and effects of the O.T.C.",
        "name" : "The Military Training of Youth An enquiry into the aims and effects of the O.T.C.",
        "SUID" : 1771,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -2082.3806435087236,
        "y" : -1430.9748730470808
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1769",
        "shared_name" : "L. B. Pekin",
        "name" : "L. B. Pekin",
        "SUID" : 1769,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1946.3237587430986,
        "y" : -1377.7277722170027
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1764",
        "shared_name" : "The Price of Liberty A German on Contemporary Britain",
        "name" : "The Price of Liberty A German on Contemporary Britain",
        "SUID" : 1764,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 1804.9946464082686,
        "y" : 1616.374187011513
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1762",
        "shared_name" : "Adolf Lowe",
        "name" : "Adolf Lowe",
        "SUID" : 1762,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 1807.3162368318526,
        "y" : 1508.6348376462786
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1757",
        "shared_name" : "Poems_4",
        "name" : "Poems_4",
        "SUID" : 1757,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 1907.3162368318526,
        "y" : 1616.374187011513
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1755",
        "shared_name" : "Christopher Lee",
        "name" : "Christopher Lee",
        "SUID" : 1755,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 1909.6378272554366,
        "y" : 1508.6348376462786
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1750",
        "shared_name" : "Ladies and Gentlemen in Victorian Fiction",
        "name" : "Ladies and Gentlemen in Victorian Fiction",
        "SUID" : 1750,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1339.6560799100907,
        "y" : 1719.7560839841692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1745",
        "shared_name" : "The League of Abyssinia",
        "name" : "The League of Abyssinia",
        "SUID" : 1745,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -88.44265522747355,
        "y" : -1381.1820568849714
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1740",
        "shared_name" : "The Authorship of Wuthering Heights",
        "name" : "The Authorship of Wuthering Heights",
        "SUID" : 1740,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 2009.6378272554366,
        "y" : 1616.374187011513
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1738",
        "shared_name" : "Irene Cooper Willis",
        "name" : "Irene Cooper Willis",
        "SUID" : 1738,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 2011.9594176790206,
        "y" : 1508.6348376462786
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1733",
        "shared_name" : "The Idea of a World Encyclopaedia A Lecture Delivered at the Royal Institution, November 20th, 1936",
        "name" : "The Idea of a World Encyclopaedia A Lecture Delivered at the Royal Institution, November 20th, 1936",
        "SUID" : 1733,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -228.4588695982011,
        "y" : 751.465007324013
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1728",
        "shared_name" : "The \"Dreadnought\" Hoax",
        "name" : "The \"Dreadnought\" Hoax",
        "SUID" : 1728,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 2111.9594176790206,
        "y" : 1616.374187011513
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1726",
        "shared_name" : "Adrian Stephen",
        "name" : "Adrian Stephen",
        "SUID" : 1726,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 2114.2810081026046,
        "y" : 1508.6348376462786
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1721",
        "shared_name" : "Economic Policies and Peace",
        "name" : "Economic Policies and Peace",
        "SUID" : 1721,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 2214.2810081026046,
        "y" : 1616.374187011513
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1719",
        "shared_name" : "Sir Arthur Salter",
        "name" : "Sir Arthur Salter",
        "SUID" : 1719,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 2216.6025985261886,
        "y" : 1508.6348376462786
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1714",
        "shared_name" : "The Co-operative Movement To-Day and To-Morrow",
        "name" : "The Co-operative Movement To-Day and To-Morrow",
        "SUID" : 1714,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 2316.6025985261886,
        "y" : 1616.374187011513
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1712",
        "shared_name" : "A. Douglas Millard",
        "name" : "A. Douglas Millard",
        "SUID" : 1712,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 2318.9241889497725,
        "y" : 1508.6348376462786
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1707",
        "shared_name" : "The League of Nations The complete story told for young people",
        "name" : "The League of Nations The complete story told for young people",
        "SUID" : 1707,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1294.8419987180741,
        "y" : 956.0443186948626
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1702",
        "shared_name" : "Land-Value Rating Theory and Practice",
        "name" : "Land-Value Rating Theory and Practice",
        "SUID" : 1702,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 2418.9241889497725,
        "y" : 1616.374187011513
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1700",
        "shared_name" : "F. C. R. Douglas",
        "name" : "F. C. R. Douglas",
        "SUID" : 1700,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 2421.2457793733565,
        "y" : 1508.6348376462786
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1695",
        "shared_name" : "Noah and the Waters",
        "name" : "Noah and the Waters",
        "SUID" : 1695,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1112.725736282161,
        "y" : -1170.2857556154402
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1690",
        "shared_name" : "Work for the Winter and other poems",
        "name" : "Work for the Winter and other poems",
        "SUID" : 1690,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -883.1448647001298,
        "y" : -1043.4119000246199
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1688",
        "shared_name" : "Julian Bell",
        "name" : "Julian Bell",
        "SUID" : 1688,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -775.2629066923173,
        "y" : -1017.2024063875349
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1683",
        "shared_name" : "The Future of Colonies",
        "name" : "The Future of Colonies",
        "SUID" : 1683,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -2190.1445595243486,
        "y" : -1318.958576660362
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1681",
        "shared_name" : "Leonard Barnes",
        "name" : "Leonard Barnes",
        "SUID" : 1681,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -2058.262113235286,
        "y" : -1276.0501904298933
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1676",
        "shared_name" : "Land and Freedom",
        "name" : "Land and Freedom",
        "SUID" : 1676,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 2521.2457793733565,
        "y" : 1616.374187011513
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1674",
        "shared_name" : "Frederick Verinder",
        "name" : "Frederick Verinder",
        "SUID" : 1674,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 2523.5673697969405,
        "y" : 1508.6348376462786
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1669",
        "shared_name" : "Beelzebub and Other Poems",
        "name" : "Beelzebub and Other Poems",
        "SUID" : 1669,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 645.9006064912764,
        "y" : -1201.8715863039167
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1664",
        "shared_name" : "What to do with the B.B.C.",
        "name" : "What to do with the B.B.C.",
        "SUID" : 1664,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1192.210569045833,
        "y" : 1719.7560839841692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1659",
        "shared_name" : "Allegra",
        "name" : "Allegra",
        "SUID" : 1659,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1587.1015907743486,
        "y" : 1508.6348376462786
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1657",
        "shared_name" : "Iris Origo",
        "name" : "Iris Origo",
        "SUID" : 1657,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1608.994290969661,
        "y" : 1615.0239672849505
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1652",
        "shared_name" : "Poverty and Plenty: The True National Dividend",
        "name" : "Poverty and Plenty: The True National Dividend",
        "SUID" : 1652,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 2623.5673697969405,
        "y" : 1616.374187011513
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1650",
        "shared_name" : "W. R. Lester",
        "name" : "W. R. Lester",
        "SUID" : 1650,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 2625.8889602205245,
        "y" : 1508.6348376462786
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1645",
        "shared_name" : "Law and Justice in Soviet Russia",
        "name" : "Law and Justice in Soviet Russia",
        "SUID" : 1645,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1044.7650581815751,
        "y" : 1719.7560839841692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1640",
        "shared_name" : "Politics and Morals",
        "name" : "Politics and Morals",
        "SUID" : 1640,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 2725.8889602205245,
        "y" : 1616.374187011513
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1638",
        "shared_name" : "G. P. Gooch",
        "name" : "G. P. Gooch",
        "SUID" : 1638,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 2728.2105506441085,
        "y" : 1508.6348376462786
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1633",
        "shared_name" : "The Brontes Their Lives Recorded by their Contemporaries",
        "name" : "The Brontes Their Lives Recorded by their Contemporaries",
        "SUID" : 1633,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1292.210569045833,
        "y" : 1508.6348376462786
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1631",
        "shared_name" : "E. M. Delafield",
        "name" : "E. M. Delafield",
        "SUID" : 1631,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1314.1032692411454,
        "y" : 1615.0239672849505
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1626",
        "shared_name" : "Revolution in Writing",
        "name" : "Revolution in Writing",
        "SUID" : 1626,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1168.6148048856767,
        "y" : -1193.2618450929792
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1621",
        "shared_name" : "A Time to Dance and Other Poems",
        "name" : "A Time to Dance and Other Poems",
        "SUID" : 1621,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1057.2977882841142,
        "y" : -1130.3115277101667
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1616",
        "shared_name" : "Collected Poems 1929-1933",
        "name" : "Collected Poems 1929-1933",
        "SUID" : 1616,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1243.4633156278642,
        "y" : -1024.540005188194
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1611",
        "shared_name" : "Challenge to Schools A pamphlet on Public School Education",
        "name" : "Challenge to Schools A pamphlet on Public School Education",
        "SUID" : 1611,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 2828.2105506441085,
        "y" : 1616.374187011513
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1609",
        "shared_name" : "Arthur Calder-Marshall",
        "name" : "Arthur Calder-Marshall",
        "SUID" : 1609,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 2830.5321410676925,
        "y" : 1508.6348376462786
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1604",
        "shared_name" : "The Successful Teacher An Occupational Analysis based on an enquiry conducted among women teachers in secondary schools",
        "name" : "The Successful Teacher An Occupational Analysis based on an enquiry conducted among women teachers in secondary schools",
        "SUID" : 1604,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 2930.5321410676925,
        "y" : 1616.374187011513
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1602",
        "shared_name" : "Mary Birkinshaw",
        "name" : "Mary Birkinshaw",
        "SUID" : 1602,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 2932.8537314912764,
        "y" : 1508.6348376462786
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1597",
        "shared_name" : "Mr. Roosevelt's Experiments",
        "name" : "Mr. Roosevelt's Experiments",
        "SUID" : 1597,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 3032.8537314912764,
        "y" : 1616.374187011513
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1595",
        "shared_name" : "S. H. Bailey",
        "name" : "S. H. Bailey",
        "SUID" : 1595,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 3035.1753219148604,
        "y" : 1508.6348376462786
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1590",
        "shared_name" : "From Moscow to Samarkand",
        "name" : "From Moscow to Samarkand",
        "SUID" : 1590,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 3135.1753219148604,
        "y" : 1616.374187011513
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1588",
        "shared_name" : "Y. Z.",
        "name" : "Y. Z.",
        "SUID" : 1588,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 3137.4969123384444,
        "y" : 1508.6348376462786
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1583",
        "shared_name" : "The Worker and Wage Incentives: The Bedaux and Other Systems",
        "name" : "The Worker and Wage Incentives: The Bedaux and Other Systems",
        "SUID" : 1583,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 3237.4969123384444,
        "y" : 1616.374187011513
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1581",
        "shared_name" : "W. F. Watson",
        "name" : "W. F. Watson",
        "SUID" : 1581,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 3239.8185027620284,
        "y" : 1508.6348376462786
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1576",
        "shared_name" : "The Medium of Poetry",
        "name" : "The Medium of Poetry",
        "SUID" : 1576,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 3339.8185027620284,
        "y" : 1616.374187011513
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1574",
        "shared_name" : "James Sutherland",
        "name" : "James Sutherland",
        "SUID" : 1574,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 3342.1400931856124,
        "y" : 1508.6348376462786
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1569",
        "shared_name" : "The Question of the House of Lords",
        "name" : "The Question of the House of Lords",
        "SUID" : 1569,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -2348.993314407161,
        "y" : 1927.4954333494036
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1567",
        "shared_name" : "A. L. Rowse",
        "name" : "A. L. Rowse",
        "SUID" : 1567,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -2346.671723983577,
        "y" : 1819.7560839841692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1562",
        "shared_name" : "The Roots of Violence",
        "name" : "The Roots of Violence",
        "SUID" : 1562,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -2246.671723983577,
        "y" : 1927.4954333494036
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1560",
        "shared_name" : "S. K. Ratcliffe",
        "name" : "S. K. Ratcliffe",
        "SUID" : 1560,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -2244.350133559993,
        "y" : 1819.7560839841692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1555",
        "shared_name" : "How to Make a Revolution",
        "name" : "How to Make a Revolution",
        "SUID" : 1555,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1144.7650581815751,
        "y" : 1508.6348376462786
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1553",
        "shared_name" : "Raymond Postgate",
        "name" : "Raymond Postgate",
        "SUID" : 1553,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1166.6577583768876,
        "y" : 1615.0239672849505
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1548",
        "shared_name" : "The Noise of History",
        "name" : "The Noise of History",
        "SUID" : 1548,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1613.6094032743486,
        "y" : -818.5373425295027
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1543",
        "shared_name" : "Crime at Christmas",
        "name" : "Crime at Christmas",
        "SUID" : 1543,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -2016.209378860286,
        "y" : -1621.605793457237
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1538",
        "shared_name" : "Race and Economics in South Africa",
        "name" : "Race and Economics in South Africa",
        "SUID" : 1538,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -2144.350133559993,
        "y" : 1927.4954333494036
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1536",
        "shared_name" : "W. G. Ballinger",
        "name" : "W. G. Ballinger",
        "SUID" : 1536,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -2142.028543136409,
        "y" : 1819.7560839841692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1531",
        "shared_name" : "A Letter to a Grandfather",
        "name" : "A Letter to a Grandfather",
        "SUID" : 1531,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -2042.028543136409,
        "y" : 1927.4954333494036
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1529",
        "shared_name" : "Rebecca West",
        "name" : "Rebecca West",
        "SUID" : 1529,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -2039.7069527128251,
        "y" : 1819.7560839841692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1524",
        "shared_name" : "How the World is Governed A Study in World Civics",
        "name" : "How the World is Governed A Study in World Civics",
        "SUID" : 1524,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1939.7069527128251,
        "y" : 1927.4954333494036
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1522",
        "shared_name" : "Hebe Spaull",
        "name" : "Hebe Spaull",
        "SUID" : 1522,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1937.3853622892411,
        "y" : 1819.7560839841692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1517",
        "shared_name" : "Collected Poems Volume One",
        "name" : "Collected Poems Volume One",
        "SUID" : 1517,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -419.2051674345048,
        "y" : -186.8830761720808
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1512",
        "shared_name" : "Caste and Democracy",
        "name" : "Caste and Democracy",
        "SUID" : 1512,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1837.3853622892411,
        "y" : 1927.4954333494036
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1510",
        "shared_name" : "K. M. Panikkar",
        "name" : "K. M. Panikkar",
        "SUID" : 1510,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1835.0637718656571,
        "y" : 1819.7560839841692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1505",
        "shared_name" : "The Case for West-Indian Self Government",
        "name" : "The Case for West-Indian Self Government",
        "SUID" : 1505,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1735.0637718656571,
        "y" : 1927.4954333494036
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1503",
        "shared_name" : "C. L. R. James",
        "name" : "C. L. R. James",
        "SUID" : 1503,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1732.7421814420732,
        "y" : 1819.7560839841692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1498",
        "shared_name" : "The Spanish Constitution",
        "name" : "The Spanish Constitution",
        "SUID" : 1498,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1632.7421814420732,
        "y" : 1927.4954333494036
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1496",
        "shared_name" : "H. R. G. Greaves",
        "name" : "H. R. G. Greaves",
        "SUID" : 1496,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1630.4205910184892,
        "y" : 1819.7560839841692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1491",
        "shared_name" : "The Magnetic Mountain",
        "name" : "The Magnetic Mountain",
        "SUID" : 1491,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1063.570951125911,
        "y" : -961.0905785371931
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1486",
        "shared_name" : "Paul Valéry",
        "name" : "Paul Valéry",
        "SUID" : 1486,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -10.878080032161051,
        "y" : -1760.7998242189558
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1484",
        "shared_name" : "Theodora Bosanquet",
        "name" : "Theodora Bosanquet",
        "SUID" : 1484,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -70.71658100872355,
        "y" : -1617.3060498048933
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1479",
        "shared_name" : "A Letter to a Young Poet",
        "name" : "A Letter to a Young Poet",
        "SUID" : 1479,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -137.67471089153605,
        "y" : -1285.8016247560652
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1474",
        "shared_name" : "A Letter to a Modern Novelist",
        "name" : "A Letter to a Modern Novelist",
        "SUID" : 1474,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1530.4205910184892,
        "y" : 1927.4954333494036
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1472",
        "shared_name" : "Hugh Walpole",
        "name" : "Hugh Walpole",
        "SUID" : 1472,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1528.0990005949052,
        "y" : 1819.7560839841692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1467",
        "shared_name" : "Rimeless Numbers",
        "name" : "Rimeless Numbers",
        "SUID" : 1467,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 669.645601608464,
        "y" : -986.636874656883
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1462",
        "shared_name" : "A Letter to W. B. Yeats",
        "name" : "A Letter to W. B. Yeats",
        "SUID" : 1462,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1428.0990005949052,
        "y" : 1927.4954333494036
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1460",
        "shared_name" : "L. A. G. Strong",
        "name" : "L. A. G. Strong",
        "SUID" : 1460,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1425.7774101713212,
        "y" : 1819.7560839841692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1455",
        "shared_name" : "Modern Art and Revolution",
        "name" : "Modern Art and Revolution",
        "SUID" : 1455,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1325.7774101713212,
        "y" : 1927.4954333494036
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1453",
        "shared_name" : "Sir Michael Sadler",
        "name" : "Sir Michael Sadler",
        "SUID" : 1453,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1323.4558197477372,
        "y" : 1819.7560839841692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1448",
        "shared_name" : "A Letter to Mrs. Virginia Woolf",
        "name" : "A Letter to Mrs. Virginia Woolf",
        "SUID" : 1448,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1223.4558197477372,
        "y" : 1927.4954333494036
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1446",
        "shared_name" : "Peter Quennell",
        "name" : "Peter Quennell",
        "SUID" : 1446,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1221.1342293241532,
        "y" : 1819.7560839841692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1441",
        "shared_name" : "Disarmament A Discussion",
        "name" : "Disarmament A Discussion",
        "SUID" : 1441,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1121.1342293241532,
        "y" : 1927.4954333494036
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1439",
        "shared_name" : "Arthur Ponsonby",
        "name" : "Arthur Ponsonby",
        "SUID" : 1439,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1118.8126389005693,
        "y" : 1819.7560839841692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1434",
        "shared_name" : "The Fivefold Screen",
        "name" : "The Fivefold Screen",
        "SUID" : 1434,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1070.8886085966142,
        "y" : -583.5285229494245
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1429",
        "shared_name" : "The French Pictures A Letter to Harriet",
        "name" : "The French Pictures A Letter to Harriet",
        "SUID" : 1429,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 619.9434169313399,
        "y" : 751.465007324013
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1427",
        "shared_name" : "Raymond Mortimer",
        "name" : "Raymond Mortimer",
        "SUID" : 1427,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 518.1595576784102,
        "y" : 792.6191210935442
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1422",
        "shared_name" : "Russian Notes",
        "name" : "Russian Notes",
        "SUID" : 1422,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1018.8126389005693,
        "y" : 1927.4954333494036
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1420",
        "shared_name" : "C. M. Lloyd",
        "name" : "C. M. Lloyd",
        "SUID" : 1420,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1016.4910484769853,
        "y" : 1819.7560839841692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1415",
        "shared_name" : "The Crisis and the Constitution: 1931 and After",
        "name" : "The Crisis and the Constitution: 1931 and After",
        "SUID" : 1415,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -997.3195473173173,
        "y" : 1508.6348376462786
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1413",
        "shared_name" : "Harold J. Laski",
        "name" : "Harold J. Laski",
        "SUID" : 1413,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1019.2122475126298,
        "y" : 1615.0239672849505
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1408",
        "shared_name" : "The Psycho-Analysis of Children",
        "name" : "The Psycho-Analysis of Children",
        "SUID" : 1408,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 1825.0559714815108,
        "y" : -1416.6409039308699
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1406",
        "shared_name" : "Melanie Klein",
        "name" : "Melanie Klein",
        "SUID" : 1406,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 1713.1294578096358,
        "y" : -1449.1364331056745
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1401",
        "shared_name" : "From Capitalism to Socialism",
        "name" : "From Capitalism to Socialism",
        "SUID" : 1401,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -897.3195473173173,
        "y" : 1719.7560839841692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1396",
        "shared_name" : "A Letter to an Archbishop",
        "name" : "A Letter to an Archbishop",
        "SUID" : 1396,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -916.4910484769853,
        "y" : 1927.4954333494036
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1394",
        "shared_name" : "J. C. Hardwick",
        "name" : "J. C. Hardwick",
        "SUID" : 1394,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -914.1694580534013,
        "y" : 1819.7560839841692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1389",
        "shared_name" : "A Letter to Adolf Hitler",
        "name" : "A Letter to Adolf Hitler",
        "SUID" : 1389,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -814.1694580534013,
        "y" : 1927.4954333494036
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1387",
        "shared_name" : "Louis Golding",
        "name" : "Louis Golding",
        "SUID" : 1387,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -811.8478676298173,
        "y" : 1819.7560839841692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1382",
        "shared_name" : "Clemence and Clare",
        "name" : "Clemence and Clare",
        "SUID" : 1382,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 458.14633403033895,
        "y" : -1138.326740722862
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1377",
        "shared_name" : "On Marxism To-Day",
        "name" : "On Marxism To-Day",
        "SUID" : 1377,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -749.8740364530595,
        "y" : 1719.7560839841692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1372",
        "shared_name" : "Societ Education Some Aspects of Cultural Revolution",
        "name" : "Societ Education Some Aspects of Cultural Revolution",
        "SUID" : 1372,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -711.8478676298173,
        "y" : 1927.4954333494036
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1370",
        "shared_name" : "R. D. Charques",
        "name" : "R. D. Charques",
        "SUID" : 1370,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -709.5262772062333,
        "y" : 1819.7560839841692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1365",
        "shared_name" : "If We Want Peace",
        "name" : "If We Want Peace",
        "SUID" : 1365,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -609.5262772062333,
        "y" : 1927.4954333494036
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1363",
        "shared_name" : "Henry Noel Brailsford",
        "name" : "Henry Noel Brailsford",
        "SUID" : 1363,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -607.2046867826493,
        "y" : 1819.7560839841692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1358",
        "shared_name" : "A Letter from a Black Sheep",
        "name" : "A Letter from a Black Sheep",
        "SUID" : 1358,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 2316.4792045137374,
        "y" : -1805.4197125246199
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1356",
        "shared_name" : "Francis Birrell",
        "name" : "Francis Birrell",
        "SUID" : 1356,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 2427.774523117253,
        "y" : -1795.5478100587995
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1351",
        "shared_name" : "After the Deluge A Study in Communal Psychology Vol. I",
        "name" : "After the Deluge A Study in Communal Psychology Vol. I",
        "SUID" : 1351,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -192.7729164579423,
        "y" : -1459.2958569337995
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1346",
        "shared_name" : "The Village in the Jungle",
        "name" : "The Village in the Jungle",
        "SUID" : 1346,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -254.5093666532548,
        "y" : -1353.4892468263777
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1341",
        "shared_name" : "Walking Shadows An Essay on Lotte Reiniger's Silhouette Films",
        "name" : "Walking Shadows An Essay on Lotte Reiniger's Silhouette Films",
        "SUID" : 1341,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 3205.335850097844,
        "y" : 947.7670703122942
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1336",
        "shared_name" : "Three Plays Sulla, Fand, The Pearl Tree",
        "name" : "Three Plays Sulla, Fand, The Pearl Tree",
        "SUID" : 1336,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 600.9130576631514,
        "y" : -972.2519764711531
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1331",
        "shared_name" : "Poetry in France and England",
        "name" : "Poetry in France and England",
        "SUID" : 1331,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -507.20468678264933,
        "y" : 1927.4954333494036
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1329",
        "shared_name" : "Jean Stewart",
        "name" : "Jean Stewart",
        "SUID" : 1329,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -504.88309635906535,
        "y" : 1819.7560839841692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1324",
        "shared_name" : "Poems_3",
        "name" : "Poems_3",
        "SUID" : 1324,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 210.0648520967452,
        "y" : -1691.1765332033308
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1322",
        "shared_name" : "George Rylands",
        "name" : "George Rylands",
        "SUID" : 1322,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 111.0847495576827,
        "y" : -1574.242268066612
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1317",
        "shared_name" : "Some Religious Elements in English Literature",
        "name" : "Some Religious Elements in English Literature",
        "SUID" : 1317,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 3057.8901561281173,
        "y" : 848.1617541501848
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1312",
        "shared_name" : "A Last Chance in Kenya",
        "name" : "A Last Chance in Kenya",
        "SUID" : 1312,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 3267.0928901216475,
        "y" : -1521.6346630861433
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1310",
        "shared_name" : "Norman Leys",
        "name" : "Norman Leys",
        "SUID" : 1310,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 3339.428808548161,
        "y" : -1607.7216229250105
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1305",
        "shared_name" : "A Letter to a Sister",
        "name" : "A Letter to a Sister",
        "SUID" : 1305,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -404.88309635906535,
        "y" : 1927.4954333494036
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1303",
        "shared_name" : "Rosamond Lehmann",
        "name" : "Rosamond Lehmann",
        "SUID" : 1303,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -402.56150593548136,
        "y" : 1819.7560839841692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1298",
        "shared_name" : "A Garden Revisited and Other Poems",
        "name" : "A Garden Revisited and Other Poems",
        "SUID" : 1298,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1572.9160438993486,
        "y" : -754.5106091310652
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1296",
        "shared_name" : "John Lehmann",
        "name" : "John Lehmann",
        "SUID" : 1296,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1481.5252357938798,
        "y" : -850.0138287355574
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1291",
        "shared_name" : "On the Nightmare",
        "name" : "On the Nightmare",
        "SUID" : 1291,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 1409.3135016939132,
        "y" : -1987.5140576173933
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1286",
        "shared_name" : "The Horrors of the Countryside",
        "name" : "The Horrors of the Countryside",
        "SUID" : 1286,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -302.56150593548136,
        "y" : 1927.4954333494036
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1284",
        "shared_name" : "C. E. M. Joad",
        "name" : "C. E. M. Joad",
        "SUID" : 1284,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -300.2399155118974,
        "y" : 1819.7560839841692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1279",
        "shared_name" : "Ulster To-Day and To-Morrow Her Part in a Gaelic Civilization A Study in Political Re-Evolution",
        "name" : "Ulster To-Day and To-Morrow Her Part in a Gaelic Civilization A Study in Political Re-Evolution",
        "SUID" : 1279,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -200.23991551189738,
        "y" : 1927.4954333494036
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1277",
        "shared_name" : "Denis Ireland",
        "name" : "Denis Ireland",
        "SUID" : 1277,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -197.9183250883134,
        "y" : 1819.7560839841692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1272",
        "shared_name" : "Protection and Free Trade",
        "name" : "Protection and Free Trade",
        "SUID" : 1272,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -97.9183250883134,
        "y" : 1927.4954333494036
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1270",
        "shared_name" : "L. M. Fraser",
        "name" : "L. M. Fraser",
        "SUID" : 1270,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -95.59673466472941,
        "y" : 1819.7560839841692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1265",
        "shared_name" : "A Letter to Madan Blanchard",
        "name" : "A Letter to Madan Blanchard",
        "SUID" : 1265,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -632.3286262968095,
        "y" : -1362.1451916505964
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1260",
        "shared_name" : "A Collection of Poems (Written between the ages of 14 and 17)",
        "name" : "A Collection of Poems (Written between the ages of 14 and 17)",
        "SUID" : 1260,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 466.30233988971395,
        "y" : -1064.3375363161238
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1258",
        "shared_name" : "Joan Adeney Easdale",
        "name" : "Joan Adeney Easdale",
        "SUID" : 1258,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 326.40133891315145,
        "y" : -1049.0412525942
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1253",
        "shared_name" : "Fifty Poems",
        "name" : "Fifty Poems",
        "SUID" : 1253,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 4.403265335270589,
        "y" : 1927.4954333494036
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1251",
        "shared_name" : "Lord Derwent",
        "name" : "Lord Derwent",
        "SUID" : 1251,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 6.724855758854574,
        "y" : 1819.7560839841692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1246",
        "shared_name" : "From Feathers to Iron",
        "name" : "From Feathers to Iron",
        "SUID" : 1246,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1235.624387405208,
        "y" : -1091.7684521486433
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1241",
        "shared_name" : "A Letter to an M. P. on Disarmament",
        "name" : "A Letter to an M. P. on Disarmament",
        "SUID" : 1241,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 106.72485575885457,
        "y" : 1927.4954333494036
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1239",
        "shared_name" : "Viscount Cecil",
        "name" : "Viscount Cecil",
        "SUID" : 1239,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 109.04644618243856,
        "y" : 1819.7560839841692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1234",
        "shared_name" : "The Race Problem in Africa",
        "name" : "The Race Problem in Africa",
        "SUID" : 1234,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 209.04644618243856,
        "y" : 1927.4954333494036
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1232",
        "shared_name" : "Charles Roden Buxton, MP",
        "name" : "Charles Roden Buxton, MP",
        "SUID" : 1232,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 211.36803660602254,
        "y" : 1819.7560839841692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1227",
        "shared_name" : "Stravinsky's Sacrifice to Apollo",
        "name" : "Stravinsky's Sacrifice to Apollo",
        "SUID" : 1227,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 3335.2774852296798,
        "y" : 848.1617541501848
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1222",
        "shared_name" : "The Open Conspiracy Blue Prints for a World Revolution A Second Version of this faith of a modern man made more explicit and plain",
        "name" : "The Open Conspiracy Blue Prints for a World Revolution A Second Version of this faith of a modern man made more explicit and plain",
        "SUID" : 1222,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -145.85404171734172,
        "y" : 960.8152880857317
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1217",
        "shared_name" : "Deserted House A Poem-Sequence",
        "name" : "Deserted House A Poem-Sequence",
        "SUID" : 1217,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -363.4534279325517,
        "y" : -625.3058056642683
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1212",
        "shared_name" : "The Course of English Classicism from the Tudor to the Victorian Age",
        "name" : "The Course of English Classicism from the Tudor to the Victorian Age",
        "SUID" : 1212,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 311.36803660602254,
        "y" : 1927.4954333494036
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1210",
        "shared_name" : "Sherard Vines",
        "name" : "Sherard Vines",
        "SUID" : 1210,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 313.6896270296065,
        "y" : 1819.7560839841692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1205",
        "shared_name" : "Letters to Frederick Tennyson",
        "name" : "Letters to Frederick Tennyson",
        "SUID" : 1205,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 1665.0396312257735,
        "y" : 751.465007324013
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1203",
        "shared_name" : "Hugh J. Schonfield",
        "name" : "Hugh J. Schonfield",
        "SUID" : 1203,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 1563.2557719728438,
        "y" : 792.6191210935442
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1198",
        "shared_name" : "Beneath the Whitewash A critical analysis of the report of the Commission on the Palestine Disturbances of August, 1929",
        "name" : "Beneath the Whitewash A critical analysis of the report of the Commission on the Palestine Disturbances of August, 1929",
        "SUID" : 1198,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -602.4285255888017,
        "y" : 1719.7560839841692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1193",
        "shared_name" : "Unholy Memories of the Holy Land",
        "name" : "Unholy Memories of the Holy Land",
        "SUID" : 1193,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -554.9830147245439,
        "y" : 1508.6348376462786
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1191",
        "shared_name" : "Horace B. Samuel",
        "name" : "Horace B. Samuel",
        "SUID" : 1191,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -576.8757149198564,
        "y" : 1615.0239672849505
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1186",
        "shared_name" : "The Edwardians",
        "name" : "The Edwardians",
        "SUID" : 1186,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -455.6036354520829,
        "y" : -107.13399169942454
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1181",
        "shared_name" : "Cavender's House",
        "name" : "Cavender's House",
        "SUID" : 1181,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 413.6896270296065,
        "y" : 1927.4954333494036
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1179",
        "shared_name" : "Edwin Arlington Robinson",
        "name" : "Edwin Arlington Robinson",
        "SUID" : 1179,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 416.0112174531905,
        "y" : 1819.7560839841692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1174",
        "shared_name" : "The Armed Muse Poems",
        "name" : "The Armed Muse Poems",
        "SUID" : 1174,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 113.1631186983077,
        "y" : -1836.2201733400495
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1169",
        "shared_name" : "The Meaning of Sacrifice",
        "name" : "The Meaning of Sacrifice",
        "SUID" : 1169,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 1750.263307907292,
        "y" : -2009.614063720909
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1167",
        "shared_name" : "Roger Money-Kyrle",
        "name" : "Roger Money-Kyrle",
        "SUID" : 1167,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 1652.5515464326827,
        "y" : -1941.0769238283308
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1162",
        "shared_name" : "St. James's Park and other poems",
        "name" : "St. James's Park and other poems",
        "SUID" : 1162,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -454.98301472454386,
        "y" : 1719.7560839841692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1157",
        "shared_name" : "German Lyric Poetry",
        "name" : "German Lyric Poetry",
        "SUID" : 1157,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 516.0112174531905,
        "y" : 1927.4954333494036
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1155",
        "shared_name" : "Norman Macleod",
        "name" : "Norman Macleod",
        "SUID" : 1155,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 518.3328078767745,
        "y" : 1819.7560839841692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1150",
        "shared_name" : "Britain & America",
        "name" : "Britain & America",
        "SUID" : 1150,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 618.3328078767745,
        "y" : 1927.4954333494036
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1148",
        "shared_name" : "John W. Graham",
        "name" : "John W. Graham",
        "SUID" : 1148,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 620.6543983003585,
        "y" : 1819.7560839841692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1143",
        "shared_name" : "The Psychology of Clothes",
        "name" : "The Psychology of Clothes",
        "SUID" : 1143,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 720.6543983003585,
        "y" : 1927.4954333494036
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1141",
        "shared_name" : "J. C. Flugel",
        "name" : "J. C. Flugel",
        "SUID" : 1141,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 722.9759887239425,
        "y" : 1819.7560839841692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1136",
        "shared_name" : "Russia To-Day and To-Morrow",
        "name" : "Russia To-Day and To-Morrow",
        "SUID" : 1136,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -702.4285255888017,
        "y" : 1508.6348376462786
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1134",
        "shared_name" : "Maurice Dobb",
        "name" : "Maurice Dobb",
        "SUID" : 1134,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -724.3212257841142,
        "y" : 1615.0239672849505
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1129",
        "shared_name" : "As You Were",
        "name" : "As You Were",
        "SUID" : 1129,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -2208.814603469661,
        "y" : -936.991333465782
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1124",
        "shared_name" : "A Room of One's Own",
        "name" : "A Room of One's Own",
        "SUID" : 1124,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -215.7310463407548,
        "y" : -1182.5058026125105
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1119",
        "shared_name" : "Notes on English Verse Satire",
        "name" : "Notes on English Verse Satire",
        "SUID" : 1119,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 822.9759887239425,
        "y" : 1927.4954333494036
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1117",
        "shared_name" : "Humbert Wolfe",
        "name" : "Humbert Wolfe",
        "SUID" : 1117,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 825.2975791475264,
        "y" : 1819.7560839841692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1112",
        "shared_name" : "The Common Sense of World Peace",
        "name" : "The Common Sense of World Peace",
        "SUID" : 1112,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -290.257682464412,
        "y" : 904.2612109372942
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1107",
        "shared_name" : "Danger Zones of Europe A Study of National Minorities",
        "name" : "Danger Zones of Europe A Study of National Minorities",
        "SUID" : 1107,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 925.2975791475264,
        "y" : 1927.4954333494036
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1105",
        "shared_name" : "John S. Stephens",
        "name" : "John S. Stephens",
        "SUID" : 1105,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 927.6191695711104,
        "y" : 1819.7560839841692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1100",
        "shared_name" : "Lies and Hate in Education",
        "name" : "Lies and Hate in Education",
        "SUID" : 1100,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 1027.6191695711104,
        "y" : 1927.4954333494036
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1098",
        "shared_name" : "Mark Starr",
        "name" : "Mark Starr",
        "SUID" : 1098,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 1029.9407599946944,
        "y" : 1819.7560839841692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1093",
        "shared_name" : "King's Daughter",
        "name" : "King's Daughter",
        "SUID" : 1093,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -585.2993904569657,
        "y" : -78.32155273458079
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1088",
        "shared_name" : "The Family Tree",
        "name" : "The Family Tree",
        "SUID" : 1088,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1222.4182411649736,
        "y" : -552.960285644737
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1083",
        "shared_name" : "White Capital & Coloured Labor",
        "name" : "White Capital & Coloured Labor",
        "SUID" : 1083,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -2322.6877724149736,
        "y" : -1292.140675049034
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1078",
        "shared_name" : "Nature Has No Time",
        "name" : "Nature Has No Time",
        "SUID" : 1078,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 1129.9407599946944,
        "y" : 1927.4954333494036
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1076",
        "shared_name" : "Sylvia Norman",
        "name" : "Sylvia Norman",
        "SUID" : 1076,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 1132.2623504182784,
        "y" : 1819.7560839841692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1071",
        "shared_name" : "The Passing of Gato and Other Poems",
        "name" : "The Passing of Gato and Other Poems",
        "SUID" : 1071,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -160.0866371610673,
        "y" : -76.84523437520579
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1069",
        "shared_name" : "Huw Menai",
        "name" : "Huw Menai",
        "SUID" : 1069,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -171.83730854778605,
        "y" : -227.7959179689558
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1064",
        "shared_name" : "Time and Memory",
        "name" : "Time and Memory",
        "SUID" : 1064,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 2656.654550888249,
        "y" : -1695.685352783409
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1059",
        "shared_name" : "The Northern Saga",
        "name" : "The Northern Saga",
        "SUID" : 1059,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -307.53750386028605,
        "y" : 1719.7560839841692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1054",
        "shared_name" : "The Whirling of Taste",
        "name" : "The Whirling of Taste",
        "SUID" : 1054,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -260.09199299602824,
        "y" : 1508.6348376462786
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1052",
        "shared_name" : "E. E. Kellett",
        "name" : "E. E. Kellett",
        "SUID" : 1052,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -281.98469319134074,
        "y" : 1615.0239672849505
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1047",
        "shared_name" : "Cawdor",
        "name" : "Cawdor",
        "SUID" : 1047,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -390.257682464412,
        "y" : 812.8820910642473
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1042",
        "shared_name" : "The Reign of Law A Short and Simple Introduction to the Work of the Permanent Court of International Justice",
        "name" : "The Reign of Law A Short and Simple Introduction to the Work of the Permanent Court of International Justice",
        "SUID" : 1042,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1368.419797561458,
        "y" : 860.862426299843
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1037",
        "shared_name" : "The China Cupboard and Other Poems",
        "name" : "The China Cupboard and Other Poems",
        "SUID" : 1037,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 1232.2623504182784,
        "y" : 1927.4954333494036
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1035",
        "shared_name" : "Ida Graves",
        "name" : "Ida Graves",
        "SUID" : 1035,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 1234.5839408418624,
        "y" : 1819.7560839841692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1030",
        "shared_name" : "Transitional Poem",
        "name" : "Transitional Poem",
        "SUID" : 1030,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1210.998899123958,
        "y" : -1149.566471557823
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1028",
        "shared_name" : "C. Day Lewis",
        "name" : "C. Day Lewis",
        "SUID" : 1028,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1129.1200844266923,
        "y" : -1043.9171070863874
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1023",
        "shared_name" : "Politics and Literature",
        "name" : "Politics and Literature",
        "SUID" : 1023,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1439.6560799100907,
        "y" : 1508.6348376462786
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1021",
        "shared_name" : "G. D. H. Cole",
        "name" : "G. D. H. Cole",
        "SUID" : 1021,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1461.5487801054032,
        "y" : 1615.0239672849505
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1016",
        "shared_name" : "Nature in English Literature",
        "name" : "Nature in English Literature",
        "SUID" : 1016,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 12.178194381901449,
        "y" : -571.6603283693464
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1014",
        "shared_name" : "Edmund Blunden",
        "name" : "Edmund Blunden",
        "SUID" : 1014,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -118.48171772747355,
        "y" : -615.6419567873152
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1009",
        "shared_name" : "The Foreigner in the Family",
        "name" : "The Foreigner in the Family",
        "SUID" : 1009,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -2250.3183876493486,
        "y" : -1016.4623551180036
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1007",
        "shared_name" : "Wilfrid Benson",
        "name" : "Wilfrid Benson",
        "SUID" : 1007,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -2117.3406044462236,
        "y" : -1039.6978688051374
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1002",
        "shared_name" : "Imperialism and Civilization",
        "name" : "Imperialism and Civilization",
        "SUID" : 1002,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -171.0628334501298,
        "y" : -1417.7296643068464
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "997",
        "shared_name" : "Near East Eductional Survey Report of a survey made during the months of April, May and June 1927",
        "name" : "Near East Eductional Survey Report of a survey made during the months of April, May and June 1927",
        "SUID" : 997,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1839.2478615263017,
        "y" : 972.4262747953264
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "995",
        "shared_name" : "Florence Wilson",
        "name" : "Florence Wilson",
        "SUID" : 995,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1747.111936233333,
        "y" : 909.9754405210344
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "990",
        "shared_name" : "Parnassus to Let An Essay about Rhythm in the Films",
        "name" : "Parnassus to Let An Essay about Rhythm in the Films",
        "SUID" : 990,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 3157.8901561281173,
        "y" : 751.465007324013
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "988",
        "shared_name" : "Eric Walter White",
        "name" : "Eric Walter White",
        "SUID" : 988,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 3225.526783325383,
        "y" : 839.5780291745989
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "983",
        "shared_name" : "Matrix",
        "name" : "Matrix",
        "SUID" : 983,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -157.05508198528605,
        "y" : -553.1125378420027
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "981",
        "shared_name" : "Dorothy Wellesley",
        "name" : "Dorothy Wellesley",
        "SUID" : 981,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -216.3850990751298,
        "y" : -648.7491345216902
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "976",
        "shared_name" : "Cock Robin's Decease",
        "name" : "Cock Robin's Decease",
        "SUID" : 976,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -160.09199299602824,
        "y" : 1719.7560839841692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "971",
        "shared_name" : "The Enjoyment of Music",
        "name" : "The Enjoyment of Music",
        "SUID" : 971,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 1334.5839408418624,
        "y" : 1927.4954333494036
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "969",
        "shared_name" : "Basil De Selincourt",
        "name" : "Basil De Selincourt",
        "SUID" : 969,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 1336.9055312654464,
        "y" : 1819.7560839841692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "964",
        "shared_name" : "Twelve Days An account of a journey across the Bakhtiari Mountains in South-western Persia",
        "name" : "Twelve Days An account of a journey across the Bakhtiari Mountains in South-western Persia",
        "SUID" : 964,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -534.7966133573564,
        "y" : -116.44063232442454
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "959",
        "shared_name" : "Ibsen and the Actress",
        "name" : "Ibsen and the Actress",
        "SUID" : 959,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1734.5471016386064,
        "y" : 1508.6348376462786
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "957",
        "shared_name" : "Elizabeth Robins",
        "name" : "Elizabeth Robins",
        "SUID" : 957,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1756.4398018339189,
        "y" : 1615.0239672849505
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "952",
        "shared_name" : "The Peacemakers",
        "name" : "The Peacemakers",
        "SUID" : 952,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -469.7452064970048,
        "y" : 431.16239501932546
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "950",
        "shared_name" : "Alice Ritchie",
        "name" : "Alice Ritchie",
        "SUID" : 950,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -521.1132179716142,
        "y" : 306.13810302713796
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "945",
        "shared_name" : "Index Psychoanalysis 1893-1926 Being an Authors' Index of Papers on Psycho-Analysis",
        "name" : "Index Psychoanalysis 1893-1926 Being an Authors' Index of Papers on Psycho-Analysis",
        "SUID" : 945,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 1008.1146262666671,
        "y" : -1183.4716076662214
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "943",
        "shared_name" : "John Rickman",
        "name" : "John Rickman",
        "SUID" : 943,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 1109.591158249089,
        "y" : -1247.222492675987
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "938",
        "shared_name" : "Leisured Women",
        "name" : "Leisured Women",
        "SUID" : 938,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 1436.9055312654464,
        "y" : 1927.4954333494036
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "936",
        "shared_name" : "Viscountess Rhondda",
        "name" : "Viscountess Rhondda",
        "SUID" : 936,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 1439.2271216890304,
        "y" : 1819.7560839841692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "931",
        "shared_name" : "Phases of English Poetry",
        "name" : "Phases of English Poetry",
        "SUID" : 931,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -27.59939350872355,
        "y" : -1872.9666943361433
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "926",
        "shared_name" : "War and Human Values",
        "name" : "War and Human Values",
        "SUID" : 926,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 1539.2271216890304,
        "y" : 1927.4954333494036
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "924",
        "shared_name" : "Francis E. Pollard",
        "name" : "Francis E. Pollard",
        "SUID" : 924,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 1541.5487121126143,
        "y" : 1819.7560839841692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "919",
        "shared_name" : "The Structure of the Novel",
        "name" : "The Structure of the Novel",
        "SUID" : 919,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 399.08224711627645,
        "y" : -1709.5844921877058
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "914",
        "shared_name" : "Roan Stallion Tamar and Other POems",
        "name" : "Roan Stallion Tamar and Other POems",
        "SUID" : 914,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -573.278663299373,
        "y" : 751.465007324013
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "912",
        "shared_name" : "Robinson Jeffers",
        "name" : "Robinson Jeffers",
        "SUID" : 912,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -498.74704708843547,
        "y" : 835.0739855954973
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "907",
        "shared_name" : "Delius",
        "name" : "Delius",
        "SUID" : 907,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -12.646482131770426,
        "y" : 1719.7560839841692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "902",
        "shared_name" : "Arms or Arbitration?",
        "name" : "Arms or Arbitration?",
        "SUID" : 902,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 1641.5487121126143,
        "y" : 1927.4954333494036
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "900",
        "shared_name" : "H. Wilson Harris",
        "name" : "H. Wilson Harris",
        "SUID" : 900,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 1643.8703025361983,
        "y" : 1819.7560839841692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "895",
        "shared_name" : "Lyrical Poetry from Blake to Hardy",
        "name" : "Lyrical Poetry from Blake to Hardy",
        "SUID" : 895,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 1743.8703025361983,
        "y" : 1927.4954333494036
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "893",
        "shared_name" : "H. J. C. Grierson",
        "name" : "H. J. C. Grierson",
        "SUID" : 893,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 1746.1918929597823,
        "y" : 1819.7560839841692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "888",
        "shared_name" : "It Was Not Jones",
        "name" : "It Was Not Jones",
        "SUID" : 888,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 1846.1918929597823,
        "y" : 1927.4954333494036
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "886",
        "shared_name" : "R. Fitzsure",
        "name" : "R. Fitzsure",
        "SUID" : 886,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 1848.5134833833663,
        "y" : 1819.7560839841692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "881",
        "shared_name" : "Different Days",
        "name" : "Different Days",
        "SUID" : 881,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -473.4001442411454,
        "y" : -503.5294689943464
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "879",
        "shared_name" : "Frances Cornford",
        "name" : "Frances Cornford",
        "SUID" : 879,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -360.5996071317704,
        "y" : -471.27925537129954
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "874",
        "shared_name" : "What is Wrong with the League of Nations? A constructive Criticism of the League of Nations in working, with certain practical suggestions",
        "name" : "What is Wrong with the League of Nations? A constructive Criticism of the League of Nations in working, with certain practical suggestions",
        "SUID" : 874,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 1948.5134833833663,
        "y" : 1927.4954333494036
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "872",
        "shared_name" : "Edgar H. Brookes",
        "name" : "Edgar H. Brookes",
        "SUID" : 872,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 1950.8350738069503,
        "y" : 1819.7560839841692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "867",
        "shared_name" : "Lancashire Under the Hammer",
        "name" : "Lancashire Under the Hammer",
        "SUID" : 867,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 2050.8350738069503,
        "y" : 1927.4954333494036
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "865",
        "shared_name" : "B. Bowker",
        "name" : "B. Bowker",
        "SUID" : 865,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 2053.1566642305343,
        "y" : 1819.7560839841692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "860",
        "shared_name" : "Proust",
        "name" : "Proust",
        "SUID" : 860,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -316.08620991497355,
        "y" : -1598.3546948244245
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "858",
        "shared_name" : "Clive Bell",
        "name" : "Clive Bell",
        "SUID" : 858,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -310.2872292020829,
        "y" : -1447.2422070314558
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "853",
        "shared_name" : "Essays on Literature, History, Politics, etc.",
        "name" : "Essays on Literature, History, Politics, etc.",
        "SUID" : 853,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -215.3678871610673,
        "y" : -1397.8416943361433
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "848",
        "shared_name" : "Hunting the Highbrow",
        "name" : "Hunting the Highbrow",
        "SUID" : 848,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 94.27658305377645,
        "y" : -1176.2834057619245
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "843",
        "shared_name" : "Democracy Under Revision",
        "name" : "Democracy Under Revision",
        "SUID" : 843,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -79.01190914898234,
        "y" : 820.8381762693255
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "841",
        "shared_name" : "H. G. Wells",
        "name" : "H. G. Wells",
        "SUID" : 841,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -186.93553890972453,
        "y" : 856.6506457517473
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "836",
        "shared_name" : "Cheiron",
        "name" : "Cheiron",
        "SUID" : 836,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 739.2228721162764,
        "y" : -1106.0895809938581
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "831",
        "shared_name" : "Meleager",
        "name" : "Meleager",
        "SUID" : 831,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 722.867037155339,
        "y" : -1028.8491215517195
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "826",
        "shared_name" : "The Prospects of Literature",
        "name" : "The Prospects of Literature",
        "SUID" : 826,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -596.0714088895829,
        "y" : -1150.222950439659
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "824",
        "shared_name" : "Logan Pearsall Smith",
        "name" : "Logan Pearsall Smith",
        "SUID" : 824,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -469.27602925091105,
        "y" : -1171.908268432823
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "819",
        "shared_name" : "Early Socialist Days",
        "name" : "Early Socialist Days",
        "SUID" : 819,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 2153.1566642305343,
        "y" : 1927.4954333494036
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "817",
        "shared_name" : "Wm. Stephen Sanders",
        "name" : "Wm. Stephen Sanders",
        "SUID" : 817,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 2155.4782546541182,
        "y" : 1819.7560839841692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "812",
        "shared_name" : "The Apology of Arthur Rimbaud",
        "name" : "The Apology of Arthur Rimbaud",
        "SUID" : 812,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1043.2373024442704,
        "y" : 390.38407470682546
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "810",
        "shared_name" : "Edward Sackville-West",
        "name" : "Edward Sackville-West",
        "SUID" : 810,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1003.7574898222001,
        "y" : 257.94535400370046
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "805",
        "shared_name" : "A Lecture on Lectures",
        "name" : "A Lecture on Lectures",
        "SUID" : 805,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 2255.4782546541182,
        "y" : 1927.4954333494036
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "803",
        "shared_name" : "Sir Arthur Quiller-Couch",
        "name" : "Sir Arthur Quiller-Couch",
        "SUID" : 803,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 2257.7998450777022,
        "y" : 1819.7560839841692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "798",
        "shared_name" : "Notes for Poems",
        "name" : "Notes for Poems",
        "SUID" : 798,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1285.8540932157548,
        "y" : -563.0091748048933
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "793",
        "shared_name" : "I Speak of Africa",
        "name" : "I Speak of Africa",
        "SUID" : 793,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1275.7472816923173,
        "y" : -632.014240722862
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "788",
        "shared_name" : "Withering of the Fig Leaf",
        "name" : "Withering of the Fig Leaf",
        "SUID" : 788,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 2357.7998450777022,
        "y" : 1927.4954333494036
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "786",
        "shared_name" : "Geoffrey Phibbs",
        "name" : "Geoffrey Phibbs",
        "SUID" : 786,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 2360.121435501286,
        "y" : 1819.7560839841692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "781",
        "shared_name" : "The Judgement of Francois Villon A Pageant-Episode Play in Five Acts",
        "name" : "The Judgement of Francois Villon A Pageant-Episode Play in Five Acts",
        "SUID" : 781,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 185.51108012408895,
        "y" : -1808.158283691612
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "779",
        "shared_name" : "Herbert E. Palmer",
        "name" : "Herbert E. Palmer",
        "SUID" : 779,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 88.4396079561202,
        "y" : -1681.5610546877058
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "774",
        "shared_name" : "The Empire Builder",
        "name" : "The Empire Builder",
        "SUID" : 774,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -2320.6614052274736,
        "y" : -1147.9301647951277
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "769",
        "shared_name" : "The Anatomy of African Misery",
        "name" : "The Anatomy of African Misery",
        "SUID" : 769,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -2348.993314407161,
        "y" : -1218.9229931642683
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "767",
        "shared_name" : "Lord Olivier",
        "name" : "Lord Olivier",
        "SUID" : 767,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -2203.254300735286,
        "y" : -1217.9403729250105
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "762",
        "shared_name" : "Disarmament and the Coolidge Conference",
        "name" : "Disarmament and the Coolidge Conference",
        "SUID" : 762,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1488.727674148372,
        "y" : 942.4173598478167
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "757",
        "shared_name" : "The Development of English Biography",
        "name" : "The Development of English Biography",
        "SUID" : 757,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 134.7990287324874,
        "y" : 1719.7560839841692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "752",
        "shared_name" : "Studies in Shakespeare",
        "name" : "Studies in Shakespeare",
        "SUID" : 752,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 2460.121435501286,
        "y" : 1927.4954333494036
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "750",
        "shared_name" : "Allardyce Nicoll",
        "name" : "Allardyce Nicoll",
        "SUID" : 750,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 2462.44302592487,
        "y" : 1819.7560839841692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "745",
        "shared_name" : "Adventure and Other Papers",
        "name" : "Adventure and Other Papers",
        "SUID" : 745,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 2562.44302592487,
        "y" : 1927.4954333494036
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "743",
        "shared_name" : "Fridtjof Nansen",
        "name" : "Fridtjof Nansen",
        "SUID" : 743,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 2564.764616348454,
        "y" : 1819.7560839841692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "738",
        "shared_name" : "The Marionette",
        "name" : "The Marionette",
        "SUID" : 738,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 463.76547465533895,
        "y" : -1685.541828613487
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "733",
        "shared_name" : "The SIsters and Other Tales in Verse",
        "name" : "The SIsters and Other Tales in Verse",
        "SUID" : 733,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -407.53750386028605,
        "y" : 1508.6348376462786
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "731",
        "shared_name" : "F. O. Mann",
        "name" : "F. O. Mann",
        "SUID" : 731,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -429.43020405559855,
        "y" : 1615.0239672849505
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "726",
        "shared_name" : "Tragedy in relation to Aristotle's POETICS",
        "name" : "Tragedy in relation to Aristotle's POETICS",
        "SUID" : 726,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 2767.800630905339,
        "y" : -1869.637501220909
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "721",
        "shared_name" : "Mr. Balcony",
        "name" : "Mr. Balcony",
        "SUID" : 721,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -2012.5349403837236,
        "y" : -1558.460529785362
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "716",
        "shared_name" : "Posterity",
        "name" : "Posterity",
        "SUID" : 716,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 282.2445395967452,
        "y" : 1719.7560839841692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "711",
        "shared_name" : "The China of To-Day",
        "name" : "The China of To-Day",
        "SUID" : 711,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 329.690050461003,
        "y" : 1508.6348376462786
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "709",
        "shared_name" : "Stephen King-Hall",
        "name" : "Stephen King-Hall",
        "SUID" : 709,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 307.7973502656905,
        "y" : 1615.0239672849505
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "704",
        "shared_name" : "The Man with Six Senses",
        "name" : "The Man with Six Senses",
        "SUID" : 704,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 429.690050461003,
        "y" : 1719.7560839841692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "699",
        "shared_name" : "The League of Nations and the World's Workers An Introduction to the WOrk of the International Labour Organisation",
        "name" : "The League of Nations and the World's Workers An Introduction to the WOrk of the International Labour Organisation",
        "SUID" : 699,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1162.814244888118,
        "y" : 778.3246874997942
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "694",
        "shared_name" : "Fugitive Pieces",
        "name" : "Fugitive Pieces",
        "SUID" : 694,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 2664.764616348454,
        "y" : 1927.4954333494036
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "692",
        "shared_name" : "Mary Hutchinson",
        "name" : "Mary Hutchinson",
        "SUID" : 692,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 2667.086206772038,
        "y" : 1819.7560839841692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "687",
        "shared_name" : "Contemporary Music",
        "name" : "Contemporary Music",
        "SUID" : 687,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 34.799028732487386,
        "y" : 1508.6348376462786
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "685",
        "shared_name" : "Robert H. Hull",
        "name" : "Robert H. Hull",
        "SUID" : 685,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 12.906328537174886,
        "y" : 1615.0239672849505
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "680",
        "shared_name" : "Welshman's Way",
        "name" : "Welshman's Way",
        "SUID" : 680,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 2767.086206772038,
        "y" : 1927.4954333494036
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "678",
        "shared_name" : "Charles Davies",
        "name" : "Charles Davies",
        "SUID" : 678,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 2769.407797195622,
        "y" : 1819.7560839841692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "673",
        "shared_name" : "The State of Religious Belief An Inquiry Based on \"The Nation and Athenaeum\" Questionnaire",
        "name" : "The State of Religious Belief An Inquiry Based on \"The Nation and Athenaeum\" Questionnaire",
        "SUID" : 673,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 2869.407797195622,
        "y" : 1927.4954333494036
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "671",
        "shared_name" : "R. B. Braithwaite",
        "name" : "R. B. Braithwaite",
        "SUID" : 671,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 2871.729387619206,
        "y" : 1819.7560839841692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "666",
        "shared_name" : "Justice Among Nations",
        "name" : "Justice Among Nations",
        "SUID" : 666,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 2971.729387619206,
        "y" : 1927.4954333494036
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "664",
        "shared_name" : "Horace G. Alexander",
        "name" : "Horace G. Alexander",
        "SUID" : 664,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 2974.05097804279,
        "y" : 1819.7560839841692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "659",
        "shared_name" : "The Revival of Aesthetics",
        "name" : "The Revival of Aesthetics",
        "SUID" : 659,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 3074.05097804279,
        "y" : 1927.4954333494036
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "657",
        "shared_name" : "Hubert Waley",
        "name" : "Hubert Waley",
        "SUID" : 657,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 3076.372568466374,
        "y" : 1819.7560839841692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "652",
        "shared_name" : "The Deluge and Other Poems",
        "name" : "The Deluge and Other Poems",
        "SUID" : 652,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 677.5944541475264,
        "y" : -1078.475880127159
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "650",
        "shared_name" : "R. C. Trevelyan",
        "name" : "R. C. Trevelyan",
        "SUID" : 650,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 564.280611374089,
        "y" : -1096.433430175987
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "645",
        "shared_name" : "Castles in the Air The Story of My Singing Days",
        "name" : "Castles in the Air The Story of My Singing Days",
        "SUID" : 645,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 719.9434169313399,
        "y" : 916.3535380552141
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "643",
        "shared_name" : "Viola Tree",
        "name" : "Viola Tree",
        "SUID" : 643,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 809.4597438356368,
        "y" : 850.3360705564348
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "638",
        "shared_name" : "Composition as Explanation",
        "name" : "Composition as Explanation",
        "SUID" : 638,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 3176.372568466374,
        "y" : 1927.4954333494036
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "636",
        "shared_name" : "Gertrude Stein",
        "name" : "Gertrude Stein",
        "SUID" : 636,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 3178.694158889958,
        "y" : 1819.7560839841692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "631",
        "shared_name" : "The Structure of Wuthering Heights by C. P. S.",
        "name" : "The Structure of Wuthering Heights by C. P. S.",
        "SUID" : 631,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 1017.9641383668868,
        "y" : 986.850894470009
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "629",
        "shared_name" : "C. P. Sanger",
        "name" : "C. P. Sanger",
        "SUID" : 629,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 1083.353172638127,
        "y" : 898.57548858622
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "624",
        "shared_name" : "Passenger to Tehran",
        "name" : "Passenger to Tehran",
        "SUID" : 624,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -661.2879997709306,
        "y" : -176.3871044923933
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "619",
        "shared_name" : "Disarmament",
        "name" : "Disarmament",
        "SUID" : 619,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1468.419797561458,
        "y" : 751.465007324013
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "617",
        "shared_name" : "P. J. Noel Baker",
        "name" : "P. J. Noel Baker",
        "SUID" : 617,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1534.8253914335282,
        "y" : 841.5417056272356
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "612",
        "shared_name" : "Transition  Essays on Contemporary Literature",
        "name" : "Transition  Essays on Contemporary Literature",
        "SUID" : 612,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 501.76425395221395,
        "y" : -1561.2381787111433
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "607",
        "shared_name" : "The British Public and the General Strike",
        "name" : "The British Public and the General Strike",
        "SUID" : 607,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 3278.694158889958,
        "y" : 1927.4954333494036
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "605",
        "shared_name" : "Kinglsey Martin",
        "name" : "Kinglsey Martin",
        "SUID" : 605,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 3281.015749313542,
        "y" : 1819.7560839841692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "600",
        "shared_name" : "Catchwords and Claptrap",
        "name" : "Catchwords and Claptrap",
        "SUID" : 600,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 2880.5028270265548,
        "y" : 751.465007324013
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "598",
        "shared_name" : "Rose Macaulay",
        "name" : "Rose Macaulay",
        "SUID" : 598,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 2948.1394542238204,
        "y" : 839.5780291745989
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "593",
        "shared_name" : "The Education of a Young Man in Twelve Lessons",
        "name" : "The Education of a Young Man in Twelve Lessons",
        "SUID" : 593,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 3381.015749313542,
        "y" : 1927.4954333494036
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "591",
        "shared_name" : "Marius Lyle",
        "name" : "Marius Lyle",
        "SUID" : 591,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 3383.337339737126,
        "y" : 1819.7560839841692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "586",
        "shared_name" : "The River Flows",
        "name" : "The River Flows",
        "SUID" : 586,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 2765.843874313542,
        "y" : -1748.5312237550886
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "584",
        "shared_name" : "F. L. Lucas",
        "name" : "F. L. Lucas",
        "SUID" : 584,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 2666.6025947114913,
        "y" : -1812.2441601564558
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "579",
        "shared_name" : "The Poet's Eye",
        "name" : "The Poet's Eye",
        "SUID" : 579,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -2348.993314407161,
        "y" : 2135.2347827146377
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "577",
        "shared_name" : "Vernon Lee",
        "name" : "Vernon Lee",
        "SUID" : 577,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -2346.671723983577,
        "y" : 2027.4954333494036
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "572",
        "shared_name" : "The End of Laissez-Faire",
        "name" : "The End of Laissez-Faire",
        "SUID" : 572,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -909.2592903593095,
        "y" : -1732.9137158205183
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "567",
        "shared_name" : "The Question Mark",
        "name" : "The Question Mark",
        "SUID" : 567,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 477.1355613252608,
        "y" : 1508.6348376462786
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "565",
        "shared_name" : "M. Jaeger",
        "name" : "M. Jaeger",
        "SUID" : 565,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 455.2428611299483,
        "y" : 1615.0239672849505
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "560",
        "shared_name" : "How the League of Nations Works Told for Young People",
        "name" : "How the League of Nations Works Told for Young People",
        "SUID" : 560,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1319.7915016630204,
        "y" : 751.465007324013
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "555",
        "shared_name" : "Notes on Law and Order",
        "name" : "Notes on Law and Order",
        "SUID" : 555,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -849.8740364530595,
        "y" : 1508.6348376462786
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "553",
        "shared_name" : "J. A. Hobson",
        "name" : "J. A. Hobson",
        "SUID" : 553,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -871.766736648372,
        "y" : 1615.0239672849505
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "548",
        "shared_name" : "Impenetrability of the Proper Habit of English",
        "name" : "Impenetrability of the Proper Habit of English",
        "SUID" : 548,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 209.70395121783895,
        "y" : -641.0586437990339
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "543",
        "shared_name" : "Another Future of Poetry",
        "name" : "Another Future of Poetry",
        "SUID" : 543,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 205.2624839326827,
        "y" : -576.6554150392683
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "538",
        "shared_name" : "The Close Chaplet",
        "name" : "The Close Chaplet",
        "SUID" : 538,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -2246.671723983577,
        "y" : 2135.2347827146377
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "536",
        "shared_name" : "Laura Riding Gottschalk",
        "name" : "Laura Riding Gottschalk",
        "SUID" : 536,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -2244.350133559993,
        "y" : 2027.4954333494036
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "531",
        "shared_name" : "Art and Commerce",
        "name" : "Art and Commerce",
        "SUID" : 531,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -730.0487362363847,
        "y" : -1125.0837139894636
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "526",
        "shared_name" : "Rochester A Conversation between Sir George Etherege and Mr. Fitzjames",
        "name" : "Rochester A Conversation between Sir George Etherege and Mr. Fitzjames",
        "SUID" : 526,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -532.9733864286454,
        "y" : 650.227458495888
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "521",
        "shared_name" : "The Victory of Reason A Pamphlet on Arbitration",
        "name" : "The Victory of Reason A Pamphlet on Arbitration",
        "SUID" : 521,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -2144.350133559993,
        "y" : 2135.2347827146377
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "519",
        "shared_name" : "W. Arnold-Forster",
        "name" : "W. Arnold-Forster",
        "SUID" : 519,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -2142.028543136409,
        "y" : 2027.4954333494036
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "514",
        "shared_name" : "Empire and Commerce in Africa A Study in Economic Imperialism",
        "name" : "Empire and Commerce in Africa A Study in Economic Imperialism",
        "SUID" : 514,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -269.6816994169267,
        "y" : -1397.4410900880964
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "509",
        "shared_name" : "Fear and Politics / A Debate at the Zoo",
        "name" : "Fear and Politics / A Debate at the Zoo",
        "SUID" : 509,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -68.17373432903605,
        "y" : -1313.4699597170027
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "504",
        "shared_name" : "The Other Side of the Medal",
        "name" : "The Other Side of the Medal",
        "SUID" : 504,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -112.64648213177043,
        "y" : 1508.6348376462786
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "502",
        "shared_name" : "Edward Thompson",
        "name" : "Edward Thompson",
        "SUID" : 502,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -134.53918232708293,
        "y" : 1615.0239672849505
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "497",
        "shared_name" : "Poetry & Criticism",
        "name" : "Poetry & Criticism",
        "SUID" : 497,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -475.5603920438798,
        "y" : -328.2943310548933
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "495",
        "shared_name" : "Edith Sitwell",
        "name" : "Edith Sitwell",
        "SUID" : 495,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -371.0827614286454,
        "y" : -390.68513916036204
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "490",
        "shared_name" : "In Retreat",
        "name" : "In Retreat",
        "SUID" : 490,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -98.1866127470048,
        "y" : -1879.5976147462995
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "488",
        "shared_name" : "Herbert Read",
        "name" : "Herbert Read",
        "SUID" : 488,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -92.8927895048173,
        "y" : -1727.585529785362
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "483",
        "shared_name" : "Turbott Wolfe",
        "name" : "Turbott Wolfe",
        "SUID" : 483,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1178.0783363798173,
        "y" : -496.7650341798933
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "481",
        "shared_name" : "William Plomer",
        "name" : "William Plomer",
        "SUID" : 481,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1158.9323402860673,
        "y" : -633.872883300987
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "476",
        "shared_name" : "Women: An Inquiry",
        "name" : "Women: An Inquiry",
        "SUID" : 476,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -2042.028543136409,
        "y" : 2135.2347827146377
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "474",
        "shared_name" : "Willa Muir",
        "name" : "Willa Muir",
        "SUID" : 474,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -2039.7069527128251,
        "y" : 2027.4954333494036
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "469",
        "shared_name" : "First Poems",
        "name" : "First Poems",
        "SUID" : 469,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 500.81442485065145,
        "y" : -1631.0371289064558
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "467",
        "shared_name" : "Edwin Muir",
        "name" : "Edwin Muir",
        "SUID" : 467,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 358.09713969440145,
        "y" : -1571.4394726564558
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "462",
        "shared_name" : "The Character of John Dryden",
        "name" : "The Character of John Dryden",
        "SUID" : 462,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1939.7069527128251,
        "y" : 2135.2347827146377
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "460",
        "shared_name" : "Alan Lubbock",
        "name" : "Alan Lubbock",
        "SUID" : 460,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1937.3853622892411,
        "y" : 2027.4954333494036
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "455",
        "shared_name" : "Streamers Waving",
        "name" : "Streamers Waving",
        "SUID" : 455,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1947.787259719661,
        "y" : -1644.4090771486433
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "453",
        "shared_name" : "C. H. B. Kitchin",
        "name" : "C. H. B. Kitchin",
        "SUID" : 453,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1900.148343704036,
        "y" : -1513.0040478517683
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "448",
        "shared_name" : "A Short View of Russia",
        "name" : "A Short View of Russia",
        "SUID" : 448,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -937.1862465360673,
        "y" : -1667.9972119142683
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "443",
        "shared_name" : "The Economic Consequences of Mr. Churchill",
        "name" : "The Economic Consequences of Mr. Churchill",
        "SUID" : 443,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -835.5791679838212,
        "y" : -1760.0063061525495
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "441",
        "shared_name" : "John Maynard Keynes",
        "name" : "John Maynard Keynes",
        "SUID" : 441,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -806.5481811979325,
        "y" : -1637.2091870119245
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "436",
        "shared_name" : "The Story of The League of Nations Told for Young People",
        "name" : "The Story of The League of Nations Told for Young People",
        "SUID" : 436,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1176.681775710872,
        "y" : 936.5985446164934
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "434",
        "shared_name" : "Kathleen E. Innes",
        "name" : "Kathleen E. Innes",
        "SUID" : 434,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1254.9701897123368,
        "y" : 849.2464099119036
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "429",
        "shared_name" : "Reminiscences of a Student's Life",
        "name" : "Reminiscences of a Student's Life",
        "SUID" : 429,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1837.3853622892411,
        "y" : 2135.2347827146377
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "427",
        "shared_name" : "Jane Ellen Harrison",
        "name" : "Jane Ellen Harrison",
        "SUID" : 427,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1835.0637718656571,
        "y" : 2027.4954333494036
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "422",
        "shared_name" : "Contemporary Techniques of Poetry",
        "name" : "Contemporary Techniques of Poetry",
        "SUID" : 422,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 242.5035727998702,
        "y" : -705.9740795900495
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "417",
        "shared_name" : "Poems_2",
        "name" : "Poems_2",
        "SUID" : 417,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1735.0637718656571,
        "y" : 2135.2347827146377
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "415",
        "shared_name" : "Barrington Gates",
        "name" : "Barrington Gates",
        "SUID" : 415,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1732.7421814420732,
        "y" : 2027.4954333494036
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "410",
        "shared_name" : "The Marmosite's Miscellany",
        "name" : "The Marmosite's Miscellany",
        "SUID" : 410,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 140.20578227252645,
        "y" : -575.494221191612
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "408",
        "shared_name" : "Robert Graves",
        "name" : "Robert Graves",
        "SUID" : 408,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 93.7012046358077,
        "y" : -697.9324230959089
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "403",
        "shared_name" : "Histriophane: A Dialogue on Dramatic Diction",
        "name" : "Histriophane: A Dialogue on Dramatic Diction",
        "SUID" : 403,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -636.440694473079,
        "y" : 651.465007324013
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "401",
        "shared_name" : "Bonamy Dobree",
        "name" : "Bonamy Dobree",
        "SUID" : 401,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -586.1025825956376,
        "y" : 532.5652270505755
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "396",
        "shared_name" : "Senlin: A Biogrpahy",
        "name" : "Senlin: A Biogrpahy",
        "SUID" : 396,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1632.7421814420732,
        "y" : 2135.2347827146377
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "394",
        "shared_name" : "Conrad Aiken",
        "name" : "Conrad Aiken",
        "SUID" : 394,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1630.4205910184892,
        "y" : 2027.4954333494036
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "389",
        "shared_name" : "Mr. Bennett and Mrs. Brown",
        "name" : "Mr. Bennett and Mrs. Brown",
        "SUID" : 389,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -260.2133766630204,
        "y" : -1052.7562718202742
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "384",
        "shared_name" : "Some Early Impressions",
        "name" : "Some Early Impressions",
        "SUID" : 384,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1530.4205910184892,
        "y" : 2135.2347827146377
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "382",
        "shared_name" : "Leslie Stephen",
        "name" : "Leslie Stephen",
        "SUID" : 382,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1528.0990005949052,
        "y" : 2027.4954333494036
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "377",
        "shared_name" : "Seducers in Ecuador",
        "name" : "Seducers in Ecuador",
        "SUID" : 377,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -641.3040672758134,
        "y" : -109.73366210958079
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "375",
        "shared_name" : "Vita Sackville-West",
        "name" : "Vita Sackville-West",
        "SUID" : 375,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -505.74221577434855,
        "y" : -215.9131054689558
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "370",
        "shared_name" : "Jeanne de Hènaut",
        "name" : "Jeanne de Hènaut",
        "SUID" : 370,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 182.2445395967452,
        "y" : 1508.6348376462786
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "368",
        "shared_name" : "Harold Nicolson",
        "name" : "Harold Nicolson",
        "SUID" : 368,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 160.3518394014327,
        "y" : 1615.0239672849505
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "363",
        "shared_name" : "The Rector's Daughter",
        "name" : "The Rector's Daughter",
        "SUID" : 363,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1428.0990005949052,
        "y" : 2135.2347827146377
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "361",
        "shared_name" : "F. M. Mayor",
        "name" : "F. M. Mayor",
        "SUID" : 361,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1425.7774101713212,
        "y" : 2027.4954333494036
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "356",
        "shared_name" : "In Our Town",
        "name" : "In Our Town",
        "SUID" : 356,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1325.7774101713212,
        "y" : 2135.2347827146377
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "354",
        "shared_name" : "Coralie Hobson",
        "name" : "Coralie Hobson",
        "SUID" : 354,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1323.4558197477372,
        "y" : 2027.4954333494036
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "349",
        "shared_name" : "The Artist and Psycho-Analysis",
        "name" : "The Artist and Psycho-Analysis",
        "SUID" : 349,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -754.6107884862931,
        "y" : -1337.0322155763777
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "347",
        "shared_name" : "Roger Fry",
        "name" : "Roger Fry",
        "SUID" : 347,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -660.880017898372,
        "y" : -1223.610203247276
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "342",
        "shared_name" : "Homage to John Dryden: Three Essays on the Poetry of the Seventeenth Century",
        "name" : "Homage to John Dryden: Three Essays on the Poetry of the Seventeenth Century",
        "SUID" : 342,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 5.709078170963949,
        "y" : -679.0949902345808
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "337",
        "shared_name" : "When It was June",
        "name" : "When It was June",
        "SUID" : 337,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -1223.4558197477372,
        "y" : 2135.2347827146377
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "335",
        "shared_name" : "Alice Lowther",
        "name" : "Alice Lowther",
        "SUID" : 335,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -1221.1342293241532,
        "y" : 2027.4954333494036
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "330",
        "shared_name" : "Essays in Applied Psycho-Analysis",
        "name" : "Essays in Applied Psycho-Analysis",
        "SUID" : 330,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 1316.2782670042006,
        "y" : -1991.8741955568464
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "328",
        "shared_name" : "Ernest Jones",
        "name" : "Ernest Jones",
        "SUID" : 328,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 1359.474947311589,
        "y" : -1877.0779003908308
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "320",
        "shared_name" : "The Story of the Siren",
        "name" : "The Story of the Siren",
        "SUID" : 320,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -273.3345619657548,
        "y" : -1248.2879528810652
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "318",
        "shared_name" : "E. M. Forster",
        "name" : "E. M. Forster",
        "SUID" : 318,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -519.7583137968095,
        "y" : -1296.3791394045027
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "313",
        "shared_name" : "The Mark on the Wall",
        "name" : "The Mark on the Wall",
        "SUID" : 313,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 8.374971725651449,
        "y" : -1057.0533871462019
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "308",
        "shared_name" : "Omega Workshops",
        "name" : "Omega Workshops",
        "SUID" : 308,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -34.6917397001298,
        "y" : -914.1489834596784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "294",
        "shared_name" : "Kew Gardens",
        "name" : "Kew Gardens",
        "SUID" : 294,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -140.2257973173173,
        "y" : -1066.4671826173933
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "280",
        "shared_name" : "The Critic in Judgment or Belshazzar of Baronscourt",
        "name" : "The Critic in Judgment or Belshazzar of Baronscourt",
        "SUID" : 280,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 39.2910483858077,
        "y" : -1230.7736096193464
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "278",
        "shared_name" : "J. Middleton Murray",
        "name" : "J. Middleton Murray",
        "SUID" : 278,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 243.2931235811202,
        "y" : -1266.199757080284
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "270",
        "shared_name" : "Paris A Poem",
        "name" : "Paris A Poem",
        "SUID" : 270,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 190.64132914752645,
        "y" : -986.2154865076216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "268",
        "shared_name" : "Hope Mirrlees",
        "name" : "Hope Mirrlees",
        "SUID" : 268,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 420.22751078815145,
        "y" : -813.5604443361433
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "257",
        "shared_name" : "Poems_1",
        "name" : "Poems_1",
        "SUID" : 257,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -65.92617573528605,
        "y" : -1005.2928604890974
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "255",
        "shared_name" : "T. S. Eliot",
        "name" : "T. S. Eliot",
        "SUID" : 255,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -92.9463783720048,
        "y" : -788.0811962892683
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "250",
        "shared_name" : "Poems by C.N. Sidney Woolf",
        "name" : "Poems by C.N. Sidney Woolf",
        "SUID" : 250,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : -10.828031204036051,
        "y" : -1659.0914501955183
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "245",
        "shared_name" : "The Prompt Press",
        "name" : "The Prompt Press",
        "SUID" : 245,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -61.1756264188798,
        "y" : -1204.3721813966902
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "237",
        "shared_name" : "Barbara Hiles (Bagenal)",
        "name" : "Barbara Hiles (Bagenal)",
        "SUID" : 237,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 224.66989360065145,
        "y" : -1379.8706250002058
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "232",
        "shared_name" : "J. D. Fergusson",
        "name" : "J. D. Fergusson",
        "SUID" : 232,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 179.8982261201827,
        "y" : -1427.2166943361433
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "221",
        "shared_name" : "Prelude",
        "name" : "Prelude",
        "SUID" : 221,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 43.82858500690145,
        "y" : -1284.7794384767683
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "219",
        "shared_name" : "Katherine Mansfield",
        "name" : "Katherine Mansfield",
        "SUID" : 219,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 202.69223246783895,
        "y" : -1326.1177868654402
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "214",
        "shared_name" : "Dora Carrington",
        "name" : "Dora Carrington",
        "SUID" : 214,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : 194.15378031940145,
        "y" : -1046.8423046877058
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "197",
        "shared_name" : "Two Stories",
        "name" : "Two Stories",
        "SUID" : 197,
        "type" : "book",
        "selected" : false
      },
      "position" : {
        "x" : 31.27267680377645,
        "y" : -1105.8835034181745
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "193",
        "shared_name" : "C. N. Sidney Woolf",
        "name" : "C. N. Sidney Woolf",
        "SUID" : 193,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -79.03750386028605,
        "y" : -1508.267902832237
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "189",
        "shared_name" : "Vanessa Bell",
        "name" : "Vanessa Bell",
        "SUID" : 189,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -273.7119118192704,
        "y" : -1009.1440262605818
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "185",
        "shared_name" : "Leonard Woolf",
        "name" : "Leonard Woolf",
        "SUID" : 185,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -123.0442787626298,
        "y" : -1230.4213757326277
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "183",
        "shared_name" : "Virginia Woolf",
        "name" : "Virginia Woolf",
        "SUID" : 183,
        "type" : "person",
        "selected" : false
      },
      "position" : {
        "x" : -112.23879780559855,
        "y" : -1186.1545452882917
      },
      "selected" : false
    } ],
    "edges" : [ {
      "data" : {
        "id" : "5072",
        "source" : "5070",
        "target" : "5065",
        "shared_name" : "John Minton (designedJacketFor) Three",
        "Attribute_1_year" : 1946,
        "shared_interaction" : "designedJacketFor",
        "name" : "John Minton (designedJacketFor) Three",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 5072,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "5056",
        "source" : "5054",
        "target" : "5049",
        "shared_name" : "Norah Montgomerie (authorOf) Scottish Nursery Rhymes",
        "Attribute_1_year" : 1946,
        "shared_interaction" : "authorOf",
        "name" : "Norah Montgomerie (authorOf) Scottish Nursery Rhymes",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 5056,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "5051",
        "source" : "5047",
        "target" : "5049",
        "shared_name" : "William Montgomerie (editorOf) Scottish Nursery Rhymes",
        "Attribute_1_year" : 1946,
        "shared_interaction" : "editorOf",
        "name" : "William Montgomerie (editorOf) Scottish Nursery Rhymes",
        "interaction" : "editorOf",
        "certainty" : "definite",
        "SUID" : 5051,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "5041",
        "source" : "5037",
        "target" : "5039",
        "shared_name" : "Tom Hopkinson (authorOf) Mist in the Tagus",
        "Attribute_1_year" : 1946,
        "shared_interaction" : "authorOf",
        "name" : "Tom Hopkinson (authorOf) Mist in the Tagus",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 5041,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "5026",
        "source" : "5024",
        "target" : "5014",
        "shared_name" : "E. Osers (translatedFor) The Problems of Lieutenant Knap",
        "Attribute_1_year" : 1945,
        "shared_interaction" : "translatedFor",
        "name" : "E. Osers (translatedFor) The Problems of Lieutenant Knap",
        "interaction" : "translatedFor",
        "certainty" : "definite",
        "SUID" : 5026,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "5021",
        "source" : "5019",
        "target" : "5014",
        "shared_name" : "Michael Ayrton (designedJacketFor) The Problems of Lieutenant Knap",
        "Attribute_1_year" : 1945,
        "shared_interaction" : "designedJacketFor",
        "name" : "Michael Ayrton (designedJacketFor) The Problems of Lieutenant Knap",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 5021,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "5016",
        "source" : "5012",
        "target" : "5014",
        "shared_name" : "Jiri Mucha (authorOf) The Problems of Lieutenant Knap",
        "Attribute_1_year" : 1945,
        "shared_interaction" : "authorOf",
        "name" : "Jiri Mucha (authorOf) The Problems of Lieutenant Knap",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 5016,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4998",
        "source" : "4996",
        "target" : "4991",
        "shared_name" : "Cavendish Morton (designedJacketFor) Nunwell Symphony",
        "Attribute_1_year" : 1945,
        "shared_interaction" : "designedJacketFor",
        "name" : "Cavendish Morton (designedJacketFor) Nunwell Symphony",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 4998,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4993",
        "source" : "4989",
        "target" : "4991",
        "shared_name" : "Cecil Aspinall-Oglander (authorOf) Nunwell Symphony",
        "Attribute_1_year" : 1944,
        "shared_interaction" : "authorOf",
        "name" : "Cecil Aspinall-Oglander (authorOf) Nunwell Symphony",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4993,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4986",
        "source" : "4984",
        "target" : "4979",
        "shared_name" : "Howard Coster (illustratedJacketFor) E. M. Forster A Study",
        "Attribute_1_year" : 1944,
        "shared_interaction" : "illustratedJacketFor",
        "Column" : "photograph",
        "name" : "Howard Coster (illustratedJacketFor) E. M. Forster A Study",
        "interaction" : "illustratedJacketFor",
        "certainty" : "definite",
        "SUID" : 4986,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4981",
        "source" : "4977",
        "target" : "4979",
        "shared_name" : "Lionel Trilling (authorOf) E. M. Forster A Study",
        "Attribute_1_year" : 1944,
        "shared_interaction" : "authorOf",
        "name" : "Lionel Trilling (authorOf) E. M. Forster A Study",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4981,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "5067",
        "source" : "4967",
        "target" : "5065",
        "shared_name" : "William Sansom (authorOf) Three",
        "Attribute_1_year" : 1946,
        "shared_interaction" : "authorOf",
        "name" : "William Sansom (authorOf) Three",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 5067,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4971",
        "source" : "4967",
        "target" : "4969",
        "shared_name" : "William Sansom (authorOf) Fireman Flower and other stories",
        "Attribute_1_year" : 1944,
        "shared_interaction" : "authorOf",
        "name" : "William Sansom (authorOf) Fireman Flower and other stories",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4971,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4974",
        "source" : "4962",
        "target" : "4969",
        "shared_name" : "Keith Vaughn (designedJacketFor) Fireman Flower and other stories",
        "Attribute_1_year" : 1944,
        "shared_interaction" : "designedJacketFor",
        "name" : "Keith Vaughn (designedJacketFor) Fireman Flower and other stories",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 4974,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4964",
        "source" : "4962",
        "target" : "4957",
        "shared_name" : "Keith Vaughn (designedCoverFor) The Sphere of Glass and other poems",
        "Attribute_1_year" : 1944,
        "shared_interaction" : "designedCoverFor",
        "name" : "Keith Vaughn (designedCoverFor) The Sphere of Glass and other poems",
        "interaction" : "designedCoverFor",
        "certainty" : "definite",
        "SUID" : 4964,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4948",
        "source" : "4944",
        "target" : "4946",
        "shared_name" : "Friedrich Holderlin (authorOf) Selected Poems_5",
        "Attribute_1_year" : 1944,
        "shared_interaction" : "authorOf",
        "name" : "Friedrich Holderlin (authorOf) Selected Poems_5",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4948,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4935",
        "source" : "4931",
        "target" : "4933",
        "shared_name" : "Barbara Baker (authorOf) The Three Rings",
        "Attribute_1_year" : 1944,
        "shared_interaction" : "authorOf",
        "name" : "Barbara Baker (authorOf) The Three Rings",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4935,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4920",
        "source" : "4918",
        "target" : "4913",
        "shared_name" : "O. Wild (designedJacketFor) Against the Tide",
        "Attribute_1_year" : 1943,
        "shared_interaction" : "designedJacketFor",
        "name" : "O. Wild (designedJacketFor) Against the Tide",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 4920,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4915",
        "source" : "4911",
        "target" : "4913",
        "shared_name" : "Arnim Westerholt (authorOf) Against the Tide",
        "Attribute_1_year" : 1943,
        "shared_interaction" : "authorOf",
        "name" : "Arnim Westerholt (authorOf) Against the Tide",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4915,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4908",
        "source" : "4906",
        "target" : "4901",
        "shared_name" : "William Chappell (designedJacketFor) For My Brother A True Story by Jose Martinez Berlanga As Told to Lincoln Kirstein",
        "Attribute_1_year" : 1943,
        "shared_interaction" : "designedJacketFor",
        "name" : "William Chappell (designedJacketFor) For My Brother A True Story by Jose Martinez Berlanga As Told to Lincoln Kirstein",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 4908,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4903",
        "source" : "4899",
        "target" : "4901",
        "shared_name" : "Lincoln Kirstein (authorOf) For My Brother A True Story by Jose Martinez Berlanga As Told to Lincoln Kirstein",
        "Attribute_1_year" : 1943,
        "shared_interaction" : "authorOf",
        "name" : "Lincoln Kirstein (authorOf) For My Brother A True Story by Jose Martinez Berlanga As Told to Lincoln Kirstein",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4903,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4896",
        "source" : "4894",
        "target" : "4889",
        "shared_name" : "Leonard Rosoman (designedJacketFor) Caught",
        "Attribute_1_year" : 1943,
        "shared_interaction" : "designedJacketFor",
        "name" : "Leonard Rosoman (designedJacketFor) Caught",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 4896,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4883",
        "source" : "4881",
        "target" : "4876",
        "shared_name" : "J. L. Gili (translatedFor) Selected Poems of Lorca",
        "Attribute_1_year" : 1943,
        "shared_interaction" : "translatedFor",
        "name" : "J. L. Gili (translatedFor) Selected Poems of Lorca",
        "interaction" : "translatedFor",
        "certainty" : "definite",
        "SUID" : 4883,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4878",
        "source" : "4874",
        "target" : "4876",
        "shared_name" : "Federico Garcia Lorca (authorOf) Selected Poems of Lorca",
        "Attribute_1_year" : 1943,
        "shared_interaction" : "authorOf",
        "name" : "Federico Garcia Lorca (authorOf) Selected Poems of Lorca",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4878,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4860",
        "source" : "4856",
        "target" : "4858",
        "shared_name" : "Arthur Rimbaud (authorOf) Selected Verse Poems",
        "Attribute_1_year" : 1942,
        "shared_interaction" : "authorOf",
        "name" : "Arthur Rimbaud (authorOf) Selected Verse Poems",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4860,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4853",
        "source" : "4851",
        "target" : "4846",
        "shared_name" : "Graham Sutherland (designedJacketFor) Channel Packet",
        "Attribute_1_year" : 1942,
        "shared_interaction" : "designedJacketFor",
        "name" : "Graham Sutherland (designedJacketFor) Channel Packet",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 4853,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4863",
        "source" : "4838",
        "target" : "4858",
        "shared_name" : "Norman Cameron (translatedFor) Selected Verse Poems",
        "Attribute_1_year" : 1942,
        "shared_interaction" : "translatedFor",
        "name" : "Norman Cameron (translatedFor) Selected Verse Poems",
        "interaction" : "translatedFor",
        "certainty" : "definite",
        "SUID" : 4863,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4840",
        "source" : "4838",
        "target" : "4833",
        "shared_name" : "Norman Cameron (authorOf) Work in Hand",
        "Attribute_1_year" : 1942,
        "shared_interaction" : "authorOf",
        "name" : "Norman Cameron (authorOf) Work in Hand",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4840,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4835",
        "source" : "4831",
        "target" : "4833",
        "shared_name" : "Alan Hodge (authorOf) Work in Hand",
        "Attribute_1_year" : 1942,
        "shared_interaction" : "authorOf",
        "name" : "Alan Hodge (authorOf) Work in Hand",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4835,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "5009",
        "source" : "4826",
        "target" : "5004",
        "shared_name" : "John Piper (designedJacketFor) Loving",
        "Attribute_1_year" : 1945,
        "shared_interaction" : "designedJacketFor",
        "name" : "John Piper (designedJacketFor) Loving",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 5009,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4828",
        "source" : "4826",
        "target" : "4821",
        "shared_name" : "John Piper (designedJacketFor) Admiral's Widow Being the Life and Letters of the Hon. Mrs. Edward Boscawen from 1761 to 1805",
        "Attribute_1_year" : 1942,
        "shared_interaction" : "designedJacketFor",
        "name" : "John Piper (designedJacketFor) Admiral's Widow Being the Life and Letters of the Hon. Mrs. Edward Boscawen from 1761 to 1805",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 4828,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4823",
        "source" : "4819",
        "target" : "4821",
        "shared_name" : "Brig.-General Cecil Aspinall-Oglander (authorOf) Admiral's Widow Being the Life and Letters of the Hon. Mrs. Edward Boscawen from 1761 to 1805",
        "Attribute_1_year" : 1941,
        "shared_interaction" : "authorOf",
        "name" : "Brig.-General Cecil Aspinall-Oglander (authorOf) Admiral's Widow Being the Life and Letters of the Hon. Mrs. Edward Boscawen from 1761 to 1805",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4823,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4799",
        "source" : "4795",
        "target" : "4797",
        "shared_name" : "Herman Melville (authorOf) Selected Poems_4",
        "Attribute_1_year" : 1941,
        "shared_interaction" : "authorOf",
        "name" : "Herman Melville (authorOf) Selected Poems_4",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4799,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4784",
        "source" : "4782",
        "target" : "4777",
        "shared_name" : "Robert Buhler (designedJacketFor) The Backward Son",
        "Attribute_1_year" : 1940,
        "shared_interaction" : "designedJacketFor",
        "name" : "Robert Buhler (designedJacketFor) The Backward Son",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 4784,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4763",
        "source" : "4759",
        "target" : "4761",
        "shared_name" : "Ahmed Ali (authorOf) Twilight in Delhi",
        "Attribute_1_year" : 1940,
        "shared_interaction" : "authorOf",
        "name" : "Ahmed Ali (authorOf) Twilight in Delhi",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4763,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4721",
        "source" : "4719",
        "target" : "4699",
        "shared_name" : "Robert Waller (contributedTo) Poets of Tomorrow",
        "Attribute_1_year" : 1939,
        "shared_interaction" : "contributedTo",
        "name" : "Robert Waller (contributedTo) Poets of Tomorrow",
        "interaction" : "contributedTo",
        "certainty" : "definite",
        "SUID" : 4721,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4716",
        "source" : "4714",
        "target" : "4699",
        "shared_name" : "Ruthven Todd (contributedTo) Poets of Tomorrow",
        "Attribute_1_year" : 1939,
        "shared_interaction" : "contributedTo",
        "name" : "Ruthven Todd (contributedTo) Poets of Tomorrow",
        "interaction" : "contributedTo",
        "certainty" : "definite",
        "SUID" : 4716,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4711",
        "source" : "4709",
        "target" : "4699",
        "shared_name" : "H. B. Mallalieu (contributedTo) Poets of Tomorrow",
        "Attribute_1_year" : 1939,
        "shared_interaction" : "contributedTo",
        "name" : "H. B. Mallalieu (contributedTo) Poets of Tomorrow",
        "interaction" : "contributedTo",
        "certainty" : "definite",
        "SUID" : 4711,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4706",
        "source" : "4704",
        "target" : "4699",
        "shared_name" : "Peter Hewett (contributedTo) Poets of Tomorrow",
        "Attribute_1_year" : 1939,
        "shared_interaction" : "contributedTo",
        "name" : "Peter Hewett (contributedTo) Poets of Tomorrow",
        "interaction" : "contributedTo",
        "certainty" : "definite",
        "SUID" : 4706,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "5001",
        "source" : "4694",
        "target" : "4991",
        "shared_name" : "Hans Wild (illustratedFor) Nunwell Symphony",
        "Attribute_1_year" : 1945,
        "shared_interaction" : "illustratedFor",
        "Column" : "photographs",
        "name" : "Hans Wild (illustratedFor) Nunwell Symphony",
        "interaction" : "illustratedFor",
        "certainty" : "definite",
        "SUID" : 5001,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4696",
        "source" : "4694",
        "target" : "4684",
        "shared_name" : "Hans Wild (illustratedFor) Goodbye to Berlin",
        "Attribute_1_year" : 1939,
        "shared_interaction" : "illustratedFor",
        "Column" : "photograph",
        "name" : "Hans Wild (illustratedFor) Goodbye to Berlin",
        "interaction" : "illustratedFor",
        "certainty" : "likely",
        "SUID" : 4696,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4691",
        "source" : "4689",
        "target" : "4684",
        "shared_name" : "Humphrey Spender (designedJacketFor) Goodbye to Berlin",
        "Attribute_1_year" : 1939,
        "shared_interaction" : "designedJacketFor",
        "name" : "Humphrey Spender (designedJacketFor) Goodbye to Berlin",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 4691,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4678",
        "source" : "4674",
        "target" : "4676",
        "shared_name" : "Henry Thomas Hopkinson (authorOf) The Man Below",
        "Attribute_1_year" : 1939,
        "shared_interaction" : "authorOf",
        "name" : "Henry Thomas Hopkinson (authorOf) The Man Below",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4678,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4660",
        "source" : "4656",
        "target" : "4658",
        "shared_name" : "Sally Graves (authorOf) A History of Socialism",
        "Attribute_1_year" : 1939,
        "shared_interaction" : "authorOf",
        "name" : "Sally Graves (authorOf) A History of Socialism",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4660,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4626",
        "source" : "4622",
        "target" : "4624",
        "shared_name" : "T. C. Worsley (authorOf) Education Today and Tomorrow",
        "Attribute_1_year" : 1939,
        "shared_interaction" : "authorOf",
        "name" : "T. C. Worsley (authorOf) Education Today and Tomorrow",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4626,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4592",
        "source" : "4590",
        "target" : "4585",
        "shared_name" : "Elizabeth Irving Watson (designedJacketFor) Mile End",
        "Attribute_1_year" : 1938,
        "shared_interaction" : "designedJacketFor",
        "name" : "Elizabeth Irving Watson (designedJacketFor) Mile End",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 4592,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4587",
        "source" : "4583",
        "target" : "4585",
        "shared_name" : "Kathleen Nott (authorOf) Mile End",
        "Attribute_1_year" : 1938,
        "shared_interaction" : "authorOf",
        "name" : "Kathleen Nott (authorOf) Mile End",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4587,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4580",
        "source" : "4578",
        "target" : "4573",
        "shared_name" : "Joan Hall (translatedFor) Clinical Aspects of Psycho-Analysis",
        "Attribute_1_year" : 1938,
        "shared_interaction" : "translatedFor",
        "Column2" : "Published May 1938, the last book to have the Woolfs' name on the title page",
        "name" : "Joan Hall (translatedFor) Clinical Aspects of Psycho-Analysis",
        "interaction" : "translatedFor",
        "certainty" : "definite",
        "SUID" : 4580,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4570",
        "source" : "4568",
        "target" : "4563",
        "shared_name" : "Robert Medley (designedJacketFor) Lions and Shadows An Education in the Twenties",
        "Attribute_1_year" : 1938,
        "shared_interaction" : "designedJacketFor",
        "name" : "Robert Medley (designedJacketFor) Lions and Shadows An Education in the Twenties",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 4570,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4560",
        "source" : "4558",
        "target" : "4533",
        "shared_name" : "Helena Thornhill (illustratedFor) Julian Bell Essays, Poems and Letters",
        "Attribute_1_year" : 1938,
        "shared_interaction" : "illustratedFor",
        "Column" : "photograph",
        "name" : "Helena Thornhill (illustratedFor) Julian Bell Essays, Poems and Letters",
        "interaction" : "illustratedFor",
        "certainty" : "definite",
        "SUID" : 4560,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4546",
        "source" : "4544",
        "target" : "4533",
        "shared_name" : "David Garnett (contributedTo) Julian Bell Essays, Poems and Letters",
        "Attribute_1_year" : 1938,
        "shared_interaction" : "contributedTo",
        "name" : "David Garnett (contributedTo) Julian Bell Essays, Poems and Letters",
        "interaction" : "contributedTo",
        "certainty" : "definite",
        "SUID" : 4546,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4525",
        "source" : "4521",
        "target" : "4523",
        "shared_name" : "Percy Arnold (authorOf) The Banders of London",
        "Attribute_1_year" : 1937,
        "shared_interaction" : "authorOf",
        "name" : "Percy Arnold (authorOf) The Banders of London",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4525,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4511",
        "source" : "4503",
        "target" : "643",
        "shared_name" : "Virginia Parsons (daughterOf) Viola Tree",
        "shared_interaction" : "daughterOf",
        "name" : "Virginia Parsons (daughterOf) Viola Tree",
        "interaction" : "daughterOf",
        "SUID" : 4511,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4508",
        "source" : "4503",
        "target" : "4498",
        "shared_name" : "Virginia Parsons (designedJacketFor) Can I Help You? Your Manners--Menus--Amusements--Friends--Charades--Make-ups--Travel--Calling--Children--Love Affairs",
        "Attribute_1_year" : 1937,
        "shared_interaction" : "designedJacketFor",
        "name" : "Virginia Parsons (designedJacketFor) Can I Help You? Your Manners--Menus--Amusements--Friends--Charades--Make-ups--Travel--Calling--Children--Love Affairs",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 4508,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4505",
        "source" : "4503",
        "target" : "4498",
        "shared_name" : "Virginia Parsons (illustratedFor) Can I Help You? Your Manners--Menus--Amusements--Friends--Charades--Make-ups--Travel--Calling--Children--Love Affairs",
        "Attribute_1_year" : 1937,
        "shared_interaction" : "illustratedFor",
        "name" : "Virginia Parsons (illustratedFor) Can I Help You? Your Manners--Menus--Amusements--Friends--Charades--Make-ups--Travel--Calling--Children--Love Affairs",
        "interaction" : "illustratedFor",
        "certainty" : "definite",
        "SUID" : 4505,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4495",
        "source" : "4493",
        "target" : "4488",
        "shared_name" : "Naomi Mitchison (authorOf) Socrates",
        "Attribute_1_year" : 1937,
        "shared_interaction" : "authorOf",
        "name" : "Naomi Mitchison (authorOf) Socrates",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4495,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4490",
        "source" : "4486",
        "target" : "4488",
        "shared_name" : "R. H. S. Crossman (authorOf) Socrates",
        "Attribute_1_year" : 1937,
        "shared_interaction" : "authorOf",
        "name" : "R. H. S. Crossman (authorOf) Socrates",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4490,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4449",
        "source" : "4447",
        "target" : "4442",
        "shared_name" : "Cecil Baines (translatedFor) The Ego and the Mechanisms of Defence",
        "Attribute_1_year" : 1937,
        "shared_interaction" : "translatedFor",
        "name" : "Cecil Baines (translatedFor) The Ego and the Mechanisms of Defence",
        "interaction" : "translatedFor",
        "certainty" : "definite",
        "SUID" : 4449,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4452",
        "source" : "4440",
        "target" : "2182",
        "shared_name" : "Anna Freud (daughterOf) Sigmund Freud",
        "shared_interaction" : "daughterOf",
        "name" : "Anna Freud (daughterOf) Sigmund Freud",
        "interaction" : "daughterOf",
        "SUID" : 4452,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4444",
        "source" : "4440",
        "target" : "4442",
        "shared_name" : "Anna Freud (authorOf) The Ego and the Mechanisms of Defence",
        "Attribute_1_year" : 1937,
        "shared_interaction" : "authorOf",
        "name" : "Anna Freud (authorOf) The Ego and the Mechanisms of Defence",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4444,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4429",
        "source" : "4424",
        "target" : "4419",
        "shared_name" : "Patricia Russell (wifeOf) Bertrand Russell",
        "shared_interaction" : "wifeOf",
        "Column2" : "from 1936-1952",
        "name" : "Patricia Russell (wifeOf) Bertrand Russell",
        "interaction" : "wifeOf",
        "SUID" : 4429,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4426",
        "source" : "4424",
        "target" : "4409",
        "shared_name" : "Patricia Russell (editorOf) The Amberley Papers The Letters and Diaries of Lord and Lady Amberley",
        "Attribute_1_year" : 1937,
        "shared_interaction" : "editorOf",
        "name" : "Patricia Russell (editorOf) The Amberley Papers The Letters and Diaries of Lord and Lady Amberley",
        "interaction" : "editorOf",
        "certainty" : "definite",
        "SUID" : 4426,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4421",
        "source" : "4419",
        "target" : "4409",
        "shared_name" : "Bertrand Russell (editorOf) The Amberley Papers The Letters and Diaries of Lord and Lady Amberley",
        "Attribute_1_year" : 1937,
        "shared_interaction" : "editorOf",
        "name" : "Bertrand Russell (editorOf) The Amberley Papers The Letters and Diaries of Lord and Lady Amberley",
        "interaction" : "editorOf",
        "certainty" : "definite",
        "SUID" : 4421,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4416",
        "source" : "4414",
        "target" : "4409",
        "shared_name" : "Lady Amberley (authorOf) The Amberley Papers The Letters and Diaries of Lord and Lady Amberley",
        "Attribute_1_year" : 1937,
        "shared_interaction" : "authorOf",
        "name" : "Lady Amberley (authorOf) The Amberley Papers The Letters and Diaries of Lord and Lady Amberley",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4416,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4411",
        "source" : "4407",
        "target" : "4409",
        "shared_name" : "Lord Amberley (authorOf) The Amberley Papers The Letters and Diaries of Lord and Lady Amberley",
        "Attribute_1_year" : 1937,
        "shared_interaction" : "authorOf",
        "name" : "Lord Amberley (authorOf) The Amberley Papers The Letters and Diaries of Lord and Lady Amberley",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4411,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4404",
        "source" : "4399",
        "target" : "4394",
        "shared_name" : "Enid Marx (illustratedFor) A Childhood",
        "Attribute_1_year" : 1937,
        "shared_interaction" : "illustratedFor",
        "name" : "Enid Marx (illustratedFor) A Childhood",
        "interaction" : "illustratedFor",
        "certainty" : "definite",
        "SUID" : 4404,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4401",
        "source" : "4399",
        "target" : "4394",
        "shared_name" : "Enid Marx (designedJacketFor) A Childhood",
        "Attribute_1_year" : 1937,
        "shared_interaction" : "designedJacketFor",
        "name" : "Enid Marx (designedJacketFor) A Childhood",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 4401,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4396",
        "source" : "4392",
        "target" : "4394",
        "shared_name" : "Francesca Allinson (authorOf) A Childhood",
        "Attribute_1_year" : 1937,
        "shared_interaction" : "authorOf",
        "name" : "Francesca Allinson (authorOf) A Childhood",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4396,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4381",
        "source" : "4379",
        "target" : "4374",
        "shared_name" : "Ludvig Perno (translatedFor) On Socialism",
        "Attribute_1_year" : 1936,
        "shared_interaction" : "translatedFor",
        "name" : "Ludvig Perno (translatedFor) On Socialism",
        "interaction" : "translatedFor",
        "certainty" : "definite",
        "SUID" : 4381,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4368",
        "source" : "4364",
        "target" : "4366",
        "shared_name" : "K. Swinstead-Smith (authorOf) The Marchesa and Other Stories",
        "Attribute_1_year" : 1936,
        "shared_interaction" : "authorOf",
        "name" : "K. Swinstead-Smith (authorOf) The Marchesa and Other Stories",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4368,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4361",
        "source" : "4359",
        "target" : "4333",
        "shared_name" : "Mary Agnes Hamilton (contributedTo) Our Freedom and Its Results by Five Women, Eleanor F. Rathbone, Erna Reiss, Ray Strachey, Allison Neilans, Mary Agnes Hamilton",
        "Attribute_1_year" : 1936,
        "shared_interaction" : "contributedTo",
        "name" : "Mary Agnes Hamilton (contributedTo) Our Freedom and Its Results by Five Women, Eleanor F. Rathbone, Erna Reiss, Ray Strachey, Allison Neilans, Mary Agnes Hamilton",
        "interaction" : "contributedTo",
        "certainty" : "definite",
        "SUID" : 4361,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4356",
        "source" : "4354",
        "target" : "4333",
        "shared_name" : "Allison Neilans (contributedTo) Our Freedom and Its Results by Five Women, Eleanor F. Rathbone, Erna Reiss, Ray Strachey, Allison Neilans, Mary Agnes Hamilton",
        "Attribute_1_year" : 1936,
        "shared_interaction" : "contributedTo",
        "name" : "Allison Neilans (contributedTo) Our Freedom and Its Results by Five Women, Eleanor F. Rathbone, Erna Reiss, Ray Strachey, Allison Neilans, Mary Agnes Hamilton",
        "interaction" : "contributedTo",
        "certainty" : "definite",
        "SUID" : 4356,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4348",
        "source" : "4346",
        "target" : "4333",
        "shared_name" : "Erna Reiss (contributedTo) Our Freedom and Its Results by Five Women, Eleanor F. Rathbone, Erna Reiss, Ray Strachey, Allison Neilans, Mary Agnes Hamilton",
        "Attribute_1_year" : 1936,
        "shared_interaction" : "contributedTo",
        "name" : "Erna Reiss (contributedTo) Our Freedom and Its Results by Five Women, Eleanor F. Rathbone, Erna Reiss, Ray Strachey, Allison Neilans, Mary Agnes Hamilton",
        "interaction" : "contributedTo",
        "certainty" : "definite",
        "SUID" : 4348,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4343",
        "source" : "4341",
        "target" : "4333",
        "shared_name" : "Eleanor F. Rathbone (contributedTo) Our Freedom and Its Results by Five Women, Eleanor F. Rathbone, Erna Reiss, Ray Strachey, Allison Neilans, Mary Agnes Hamilton",
        "Attribute_1_year" : 1936,
        "shared_interaction" : "contributedTo",
        "name" : "Eleanor F. Rathbone (contributedTo) Our Freedom and Its Results by Five Women, Eleanor F. Rathbone, Erna Reiss, Ray Strachey, Allison Neilans, Mary Agnes Hamilton",
        "interaction" : "contributedTo",
        "certainty" : "definite",
        "SUID" : 4343,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4351",
        "source" : "4331",
        "target" : "4333",
        "shared_name" : "Ray Strachey (contributedTo) Our Freedom and Its Results by Five Women, Eleanor F. Rathbone, Erna Reiss, Ray Strachey, Allison Neilans, Mary Agnes Hamilton",
        "Attribute_1_year" : 1936,
        "shared_interaction" : "contributedTo",
        "name" : "Ray Strachey (contributedTo) Our Freedom and Its Results by Five Women, Eleanor F. Rathbone, Erna Reiss, Ray Strachey, Allison Neilans, Mary Agnes Hamilton",
        "interaction" : "contributedTo",
        "certainty" : "definite",
        "SUID" : 4351,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4335",
        "source" : "4331",
        "target" : "4333",
        "shared_name" : "Ray Strachey (editorOf) Our Freedom and Its Results by Five Women, Eleanor F. Rathbone, Erna Reiss, Ray Strachey, Allison Neilans, Mary Agnes Hamilton",
        "Attribute_1_year" : 1936,
        "shared_interaction" : "editorOf",
        "name" : "Ray Strachey (editorOf) Our Freedom and Its Results by Five Women, Eleanor F. Rathbone, Erna Reiss, Ray Strachey, Allison Neilans, Mary Agnes Hamilton",
        "interaction" : "editorOf",
        "certainty" : "definite",
        "SUID" : 4335,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4325",
        "source" : "4321",
        "target" : "4323",
        "shared_name" : "Securitas (authorOf) Adventures in Investing by \"Securitas\" (Financial Editor of Time and Tide)",
        "Attribute_1_year" : 1936,
        "shared_interaction" : "authorOf",
        "name" : "Securitas (authorOf) Adventures in Investing by \"Securitas\" (Financial Editor of Time and Tide)",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4325,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4653",
        "source" : "4305",
        "target" : "4648",
        "shared_name" : "Katherine Jones (translatedFor) Moses and Monotheism",
        "Attribute_1_year" : 1939,
        "shared_interaction" : "translatedFor",
        "name" : "Katherine Jones (translatedFor) Moses and Monotheism",
        "interaction" : "translatedFor",
        "certainty" : "definite",
        "SUID" : 4653,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4307",
        "source" : "4305",
        "target" : "4300",
        "shared_name" : "Katherine Jones (translatedFor) The Unknown Murderer",
        "Attribute_1_year" : 1936,
        "shared_interaction" : "translatedFor",
        "name" : "Katherine Jones (translatedFor) The Unknown Murderer",
        "interaction" : "translatedFor",
        "certainty" : "definite",
        "SUID" : 4307,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4297",
        "source" : "4295",
        "target" : "4290",
        "shared_name" : "Anthony Wolfe (translatedFor) Envy",
        "Attribute_1_year" : 1936,
        "shared_interaction" : "translatedFor",
        "name" : "Anthony Wolfe (translatedFor) Envy",
        "interaction" : "translatedFor",
        "certainty" : "definite",
        "SUID" : 4297,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4292",
        "source" : "4288",
        "target" : "4290",
        "shared_name" : "Yuri Olyesha (authorOf) Envy",
        "Attribute_1_year" : 1936,
        "shared_interaction" : "authorOf",
        "name" : "Yuri Olyesha (authorOf) Envy",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4292,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4282",
        "source" : "4278",
        "target" : "4280",
        "shared_name" : "Mary Gordon (authorOf) Chase of the Wild Goose The story of Lady Eleanor Butler and Miss Sarah Ponsonby, known as the Ladies of Llangollen",
        "Attribute_1_year" : 1936,
        "shared_interaction" : "authorOf",
        "name" : "Mary Gordon (authorOf) Chase of the Wild Goose The story of Lady Eleanor Butler and Miss Sarah Ponsonby, known as the Ladies of Llangollen",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4282,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4275",
        "source" : "4273",
        "target" : "4268",
        "shared_name" : "J. W. Strange (editorOf) The Roots of War A Pamphlet on War and the Social Order",
        "Attribute_1_year" : 1936,
        "shared_interaction" : "editorOf",
        "name" : "J. W. Strange (editorOf) The Roots of War A Pamphlet on War and the Social Order",
        "interaction" : "editorOf",
        "certainty" : "likely",
        "SUID" : 4275,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4270",
        "source" : "4266",
        "target" : "4268",
        "shared_name" : "Friends Anti-War Group (authorOf) The Roots of War A Pamphlet on War and the Social Order",
        "Attribute_1_year" : 1936,
        "shared_interaction" : "authorOf",
        "name" : "Friends Anti-War Group (authorOf) The Roots of War A Pamphlet on War and the Social Order",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4270,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4252",
        "source" : "4248",
        "target" : "4250",
        "shared_name" : "Fritz Faulkner (authorOf) Windless Sky",
        "Attribute_1_year" : 1936,
        "shared_interaction" : "authorOf",
        "name" : "Fritz Faulkner (authorOf) Windless Sky",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4252,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4386",
        "source" : "4230",
        "target" : "4384",
        "shared_name" : "Anna D. Whyte (authorOf) Lights Are Bright",
        "Attribute_1_year" : 1936,
        "shared_interaction" : "authorOf",
        "name" : "Anna D. Whyte (authorOf) Lights Are Bright",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4386,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4234",
        "source" : "4230",
        "target" : "4232",
        "shared_name" : "Anna D. Whyte (authorOf) Change Your Sky",
        "Attribute_1_year" : 1935,
        "shared_interaction" : "authorOf",
        "name" : "Anna D. Whyte (authorOf) Change Your Sky",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4234,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4227",
        "source" : "4225",
        "target" : "4220",
        "shared_name" : "Hugh Dalton (wroteIntroductionFor) A Derelict Area A Study of the South-West Durham Coalfield",
        "Attribute_1_year" : 1935,
        "shared_interaction" : "wroteIntroductionFor",
        "name" : "Hugh Dalton (wroteIntroductionFor) A Derelict Area A Study of the South-West Durham Coalfield",
        "interaction" : "wroteIntroductionFor",
        "certainty" : "definite",
        "SUID" : 4227,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4222",
        "source" : "4218",
        "target" : "4220",
        "shared_name" : "Thomas Sharp (authorOf) A Derelict Area A Study of the South-West Durham Coalfield",
        "Attribute_1_year" : 1935,
        "shared_interaction" : "authorOf",
        "name" : "Thomas Sharp (authorOf) A Derelict Area A Study of the South-West Durham Coalfield",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4222,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4174",
        "source" : "4172",
        "target" : "4167",
        "shared_name" : "John Cournos (translatedFor) Grammar of Love",
        "Attribute_1_year" : 1935,
        "shared_interaction" : "translatedFor",
        "name" : "John Cournos (translatedFor) Grammar of Love",
        "interaction" : "translatedFor",
        "certainty" : "definite",
        "SUID" : 4174,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4161",
        "source" : "4157",
        "target" : "4159",
        "shared_name" : "Susan Buchan (authorOf) Funeral March of a Marionette Charlotte of Albany",
        "Attribute_1_year" : 1935,
        "shared_interaction" : "authorOf",
        "name" : "Susan Buchan (authorOf) Funeral March of a Marionette Charlotte of Albany",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4161,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4154",
        "source" : "4152",
        "target" : "4147",
        "shared_name" : "Ethel Smth (wrotePrefaceFor) The 6,000 Beards of Athos",
        "Attribute_1_year" : 1935,
        "shared_interaction" : "wrotePrefaceFor",
        "name" : "Ethel Smth (wrotePrefaceFor) The 6,000 Beards of Athos",
        "interaction" : "wrotePrefaceFor",
        "certainty" : "definite",
        "SUID" : 4154,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4149",
        "source" : "4145",
        "target" : "4147",
        "shared_name" : "Ralph Brewster (authorOf) The 6,000 Beards of Athos",
        "Attribute_1_year" : 1934,
        "shared_interaction" : "authorOf",
        "name" : "Ralph Brewster (authorOf) The 6,000 Beards of Athos",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4149,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4134",
        "source" : "4132",
        "target" : "4127",
        "shared_name" : "Anthony Butts (designedJacketFor) In a Province",
        "Attribute_1_year" : 1934,
        "shared_interaction" : "designedJacketFor",
        "name" : "Anthony Butts (designedJacketFor) In a Province",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 4134,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4129",
        "source" : "4125",
        "target" : "4127",
        "shared_name" : "Laurens Van de Post (authorOf) In a Province",
        "Attribute_1_year" : 1934,
        "shared_interaction" : "authorOf",
        "name" : "Laurens Van de Post (authorOf) In a Province",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4129,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4122",
        "source" : "4120",
        "target" : "4115",
        "shared_name" : "Ben Nicolson (designedJacketFor) The dark island",
        "Attribute_1_year" : 1934,
        "shared_interaction" : "designedJacketFor",
        "name" : "Ben Nicolson (designedJacketFor) The dark island",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 4122,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4106",
        "source" : "4102",
        "target" : "4104",
        "shared_name" : "Geza Roheim (authorOf) The Riddle of the Sphinx or Human Origins",
        "Attribute_1_year" : 1934,
        "shared_interaction" : "authorOf",
        "name" : "Geza Roheim (authorOf) The Riddle of the Sphinx or Human Origins",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4106,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4954",
        "source" : "4097",
        "target" : "4946",
        "shared_name" : "J. B. Leishman (wroteIntroductionFor) Selected Poems_5",
        "Attribute_1_year" : 1944,
        "shared_interaction" : "wroteIntroductionFor",
        "name" : "J. B. Leishman (wroteIntroductionFor) Selected Poems_5",
        "interaction" : "wroteIntroductionFor",
        "certainty" : "definite",
        "SUID" : 4954,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4951",
        "source" : "4097",
        "target" : "4946",
        "shared_name" : "J. B. Leishman (translatedFor) Selected Poems_5",
        "Attribute_1_year" : 1944,
        "shared_interaction" : "translatedFor",
        "name" : "J. B. Leishman (translatedFor) Selected Poems_5",
        "interaction" : "translatedFor",
        "certainty" : "definite",
        "SUID" : 4951,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4808",
        "source" : "4097",
        "target" : "4797",
        "shared_name" : "J. B. Leishman (translatedFor) Selected Poems_4",
        "Attribute_1_year" : 1941,
        "shared_interaction" : "translatedFor",
        "name" : "J. B. Leishman (translatedFor) Selected Poems_4",
        "interaction" : "translatedFor",
        "certainty" : "definite",
        "SUID" : 4808,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4737",
        "source" : "4097",
        "target" : "4732",
        "shared_name" : "J. B. Leishman (translatedFor) Duino Elegies",
        "Attribute_1_year" : 1939,
        "shared_interaction" : "translatedFor",
        "name" : "J. B. Leishman (translatedFor) Duino Elegies",
        "interaction" : "translatedFor",
        "certainty" : "definite",
        "SUID" : 4737,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4603",
        "source" : "4097",
        "target" : "4595",
        "shared_name" : "J. B. Leishman (wroteIntroductionFor) Later Poems",
        "Attribute_1_year" : 1938,
        "shared_interaction" : "wroteIntroductionFor",
        "name" : "J. B. Leishman (wroteIntroductionFor) Later Poems",
        "interaction" : "wroteIntroductionFor",
        "certainty" : "definite",
        "SUID" : 4603,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4600",
        "source" : "4097",
        "target" : "4595",
        "shared_name" : "J. B. Leishman (translatedFor) Later Poems",
        "Attribute_1_year" : 1938,
        "shared_interaction" : "translatedFor",
        "name" : "J. B. Leishman (translatedFor) Later Poems",
        "interaction" : "translatedFor",
        "certainty" : "definite",
        "SUID" : 4600,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4318",
        "source" : "4097",
        "target" : "4310",
        "shared_name" : "J. B. Leishman (wroteIntroductionFor) Sonnets to Orpheus Written as a monument for Wera Oukama Knoop",
        "Attribute_1_year" : 1936,
        "shared_interaction" : "wroteIntroductionFor",
        "name" : "J. B. Leishman (wroteIntroductionFor) Sonnets to Orpheus Written as a monument for Wera Oukama Knoop",
        "interaction" : "wroteIntroductionFor",
        "certainty" : "definite",
        "SUID" : 4318,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4315",
        "source" : "4097",
        "target" : "4310",
        "shared_name" : "J. B. Leishman (translatedFor) Sonnets to Orpheus Written as a monument for Wera Oukama Knoop",
        "Attribute_1_year" : 1936,
        "shared_interaction" : "translatedFor",
        "name" : "J. B. Leishman (translatedFor) Sonnets to Orpheus Written as a monument for Wera Oukama Knoop",
        "interaction" : "translatedFor",
        "certainty" : "definite",
        "SUID" : 4315,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4215",
        "source" : "4097",
        "target" : "4207",
        "shared_name" : "J. B. Leishman (wroteIntroductionFor) Requiem and Other Poems",
        "Attribute_1_year" : 1935,
        "shared_interaction" : "wroteIntroductionFor",
        "name" : "J. B. Leishman (wroteIntroductionFor) Requiem and Other Poems",
        "interaction" : "wroteIntroductionFor",
        "certainty" : "definite",
        "SUID" : 4215,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4212",
        "source" : "4097",
        "target" : "4207",
        "shared_name" : "J. B. Leishman (translatedFor) Requiem and Other Poems",
        "Attribute_1_year" : 1935,
        "shared_interaction" : "translatedFor",
        "name" : "J. B. Leishman (translatedFor) Requiem and Other Poems",
        "interaction" : "translatedFor",
        "certainty" : "definite",
        "SUID" : 4212,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4099",
        "source" : "4097",
        "target" : "4092",
        "shared_name" : "J. B. Leishman (translatedFor) Poems_10",
        "Attribute_1_year" : 1934,
        "shared_interaction" : "translatedFor",
        "name" : "J. B. Leishman (translatedFor) Poems_10",
        "interaction" : "translatedFor",
        "certainty" : "definite",
        "SUID" : 4099,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4089",
        "source" : "4087",
        "target" : "4082",
        "shared_name" : "Irma Petroff (authorOf) The Secret of Hitler's Victory",
        "Attribute_1_year" : 1934,
        "shared_interaction" : "authorOf",
        "name" : "Irma Petroff (authorOf) The Secret of Hitler's Victory",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4089,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4084",
        "source" : "4080",
        "target" : "4082",
        "shared_name" : "Peter Petroff (authorOf) The Secret of Hitler's Victory",
        "Attribute_1_year" : 1934,
        "shared_interaction" : "authorOf",
        "name" : "Peter Petroff (authorOf) The Secret of Hitler's Victory",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4084,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4069",
        "source" : "4067",
        "target" : "4059",
        "shared_name" : "Professor Julian Huxley (wroteForewordFor) An African Speaks for His People",
        "Attribute_1_year" : 1934,
        "shared_interaction" : "wroteForewordFor",
        "name" : "Professor Julian Huxley (wroteForewordFor) An African Speaks for His People",
        "interaction" : "wroteForewordFor",
        "certainty" : "definite",
        "SUID" : 4069,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4061",
        "source" : "4057",
        "target" : "4059",
        "shared_name" : "Parmenas Githendu Mockerie (authorOf) An African Speaks for His People",
        "Attribute_1_year" : 1934,
        "shared_interaction" : "authorOf",
        "name" : "Parmenas Githendu Mockerie (authorOf) An African Speaks for His People",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4061,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4054",
        "source" : "4052",
        "target" : "4047",
        "shared_name" : "Betty Graham (designedJacketFor) Good Merchant",
        "Attribute_1_year" : 1934,
        "shared_interaction" : "designedJacketFor",
        "name" : "Betty Graham (designedJacketFor) Good Merchant",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 4054,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4049",
        "source" : "4045",
        "target" : "4047",
        "shared_name" : "John L. Graham (authorOf) Good Merchant",
        "Attribute_1_year" : 1934,
        "shared_interaction" : "authorOf",
        "name" : "John L. Graham (authorOf) Good Merchant",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4049,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4025",
        "source" : "4021",
        "target" : "4023",
        "shared_name" : "Constance Butler (authorOf) Illyria, Lady",
        "Attribute_1_year" : 1934,
        "shared_interaction" : "authorOf",
        "name" : "Constance Butler (authorOf) Illyria, Lady",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4025,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4002",
        "source" : "4000",
        "target" : "3940",
        "shared_name" : "R. E. Warner (contributedTo) New Country Prose and Poetry by the authors of New Signatures",
        "Attribute_1_year" : 1933,
        "shared_interaction" : "contributedTo",
        "name" : "R. E. Warner (contributedTo) New Country Prose and Poetry by the authors of New Signatures",
        "interaction" : "contributedTo",
        "certainty" : "definite",
        "SUID" : 4002,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4608",
        "source" : "3995",
        "target" : "4606",
        "shared_name" : "Edward Upward (authorOf) Journey to the Border",
        "Attribute_1_year" : 1938,
        "shared_interaction" : "authorOf",
        "name" : "Edward Upward (authorOf) Journey to the Border",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4608,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3997",
        "source" : "3995",
        "target" : "3940",
        "shared_name" : "Edward Upward (contributedTo) New Country Prose and Poetry by the authors of New Signatures",
        "Attribute_1_year" : 1933,
        "shared_interaction" : "contributedTo",
        "name" : "Edward Upward (contributedTo) New Country Prose and Poetry by the authors of New Signatures",
        "interaction" : "contributedTo",
        "certainty" : "definite",
        "SUID" : 3997,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3980",
        "source" : "3978",
        "target" : "3940",
        "shared_name" : "Charles Madge (contributedTo) New Country Prose and Poetry by the authors of New Signatures",
        "Attribute_1_year" : 1933,
        "shared_interaction" : "contributedTo",
        "name" : "Charles Madge (contributedTo) New Country Prose and Poetry by the authors of New Signatures",
        "interaction" : "contributedTo",
        "certainty" : "definite",
        "SUID" : 3980,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3966",
        "source" : "3964",
        "target" : "3940",
        "shared_name" : "Richard Goodman (contributedTo) New Country Prose and Poetry by the authors of New Signatures",
        "Attribute_1_year" : 1933,
        "shared_interaction" : "contributedTo",
        "name" : "Richard Goodman (contributedTo) New Country Prose and Poetry by the authors of New Signatures",
        "interaction" : "contributedTo",
        "certainty" : "definite",
        "SUID" : 3966,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3958",
        "source" : "3956",
        "target" : "3940",
        "shared_name" : "G. F. Brett (contributedTo) New Country Prose and Poetry by the authors of New Signatures",
        "Attribute_1_year" : 1933,
        "shared_interaction" : "contributedTo",
        "name" : "G. F. Brett (contributedTo) New Country Prose and Poetry by the authors of New Signatures",
        "interaction" : "contributedTo",
        "certainty" : "definite",
        "SUID" : 3958,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3953",
        "source" : "3951",
        "target" : "3940",
        "shared_name" : "T. O. Beachcroft (contributedTo) New Country Prose and Poetry by the authors of New Signatures",
        "Attribute_1_year" : 1933,
        "shared_interaction" : "contributedTo",
        "name" : "T. O. Beachcroft (contributedTo) New Country Prose and Poetry by the authors of New Signatures",
        "interaction" : "contributedTo",
        "certainty" : "definite",
        "SUID" : 3953,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3934",
        "source" : "3930",
        "target" : "3932",
        "shared_name" : "A. Prophett (authorOf) The Twilight Age, A Fragment of Life",
        "Attribute_1_year" : 1933,
        "shared_interaction" : "authorOf",
        "name" : "A. Prophett (authorOf) The Twilight Age, A Fragment of Life",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 3934,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3919",
        "source" : "3917",
        "target" : "3912",
        "shared_name" : "Jane Soames (translatedFor) The Political and Social Doctrine of Fascism",
        "Attribute_1_year" : 1933,
        "shared_interaction" : "translatedFor",
        "name" : "Jane Soames (translatedFor) The Political and Social Doctrine of Fascism",
        "interaction" : "translatedFor",
        "certainty" : "definite",
        "SUID" : 3919,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3914",
        "source" : "3910",
        "target" : "3912",
        "shared_name" : "Benito Mussolini (authorOf) The Political and Social Doctrine of Fascism",
        "Attribute_1_year" : 1933,
        "shared_interaction" : "authorOf",
        "name" : "Benito Mussolini (authorOf) The Political and Social Doctrine of Fascism",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 3914,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3904",
        "source" : "3902",
        "target" : "3897",
        "shared_name" : "Margaret Miller (authorOf) Financial Democracy",
        "Attribute_1_year" : 1933,
        "shared_interaction" : "authorOf",
        "name" : "Margaret Miller (authorOf) Financial Democracy",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 3904,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3899",
        "source" : "3895",
        "target" : "3897",
        "shared_name" : "Douglas Campbell (authorOf) Financial Democracy",
        "Attribute_1_year" : 1933,
        "shared_interaction" : "authorOf",
        "name" : "Douglas Campbell (authorOf) Financial Democracy",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 3899,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3889",
        "source" : "3885",
        "target" : "3887",
        "shared_name" : "Imre Madách (authorOf) The Tragedy of Man",
        "Attribute_1_year" : 1933,
        "shared_interaction" : "authorOf",
        "name" : "Imre Madách (authorOf) The Tragedy of Man",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 3889,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3882",
        "source" : "3880",
        "target" : "3875",
        "shared_name" : "Ronald Grierson (designedJacketFor) Livingstones A Novel of Contemporary Life",
        "Attribute_1_year" : 1933,
        "shared_interaction" : "designedJacketFor",
        "name" : "Ronald Grierson (designedJacketFor) Livingstones A Novel of Contemporary Life",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 3882,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3877",
        "source" : "3873",
        "target" : "3875",
        "shared_name" : "Derrick Leon (authorOf) Livingstones A Novel of Contemporary Life",
        "Attribute_1_year" : 1933,
        "shared_interaction" : "authorOf",
        "name" : "Derrick Leon (authorOf) Livingstones A Novel of Contemporary Life",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 3877,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3870",
        "source" : "3868",
        "target" : "3860",
        "shared_name" : "W. J. H. Sprott (translatedFor) New Introductory Lectures on Psycho-Analysis",
        "Attribute_1_year" : 1933,
        "shared_interaction" : "translatedFor",
        "name" : "W. J. H. Sprott (translatedFor) New Introductory Lectures on Psycho-Analysis",
        "interaction" : "translatedFor",
        "certainty" : "definite",
        "SUID" : 3870,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3857",
        "source" : "3855",
        "target" : "3840",
        "shared_name" : "Priscilla Ellingford (designedJacketFor) The Well of Days",
        "Attribute_1_year" : 1933,
        "shared_interaction" : "designedJacketFor",
        "name" : "Priscilla Ellingford (designedJacketFor) The Well of Days",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 3857,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3852",
        "source" : "3850",
        "target" : "3840",
        "shared_name" : "Hamish Miles (translatedFor) The Well of Days",
        "Attribute_1_year" : 1933,
        "shared_interaction" : "translatedFor",
        "name" : "Hamish Miles (translatedFor) The Well of Days",
        "interaction" : "translatedFor",
        "certainty" : "definite",
        "SUID" : 3852,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3847",
        "source" : "3845",
        "target" : "3840",
        "shared_name" : "Gleb Struve (translatedFor) The Well of Days",
        "Attribute_1_year" : 1933,
        "shared_interaction" : "translatedFor",
        "name" : "Gleb Struve (translatedFor) The Well of Days",
        "interaction" : "translatedFor",
        "certainty" : "definite",
        "SUID" : 3847,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3815",
        "source" : "3811",
        "target" : "3813",
        "shared_name" : "Julia Strachey (authorOf) Cheerful Weather for the Wedding",
        "Attribute_1_year" : 1932,
        "shared_interaction" : "authorOf",
        "name" : "Julia Strachey (authorOf) Cheerful Weather for the Wedding",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 3815,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3808",
        "source" : "3806",
        "target" : "3801",
        "shared_name" : "George Plank (designedJacketFor) Family History",
        "Attribute_1_year" : 1932,
        "shared_interaction" : "designedJacketFor",
        "name" : "George Plank (designedJacketFor) Family History",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 3808,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3992",
        "source" : "3796",
        "target" : "3940",
        "shared_name" : "A. S. J. Tessimond (contributedTo) New Country Prose and Poetry by the authors of New Signatures",
        "Attribute_1_year" : 1933,
        "shared_interaction" : "contributedTo",
        "name" : "A. S. J. Tessimond (contributedTo) New Country Prose and Poetry by the authors of New Signatures",
        "interaction" : "contributedTo",
        "certainty" : "definite",
        "SUID" : 3992,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3798",
        "source" : "3796",
        "target" : "3761",
        "shared_name" : "A. S. J. Tessimond (contributedTo) New Signatures Poems by Several Hands",
        "Attribute_1_year" : 1932,
        "shared_interaction" : "contributedTo",
        "name" : "A. S. J. Tessimond (contributedTo) New Signatures Poems by Several Hands",
        "interaction" : "contributedTo",
        "certainty" : "definite",
        "SUID" : 3798,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3784",
        "source" : "3782",
        "target" : "3761",
        "shared_name" : "William Empson (contributedTo) New Signatures Poems by Several Hands",
        "Attribute_1_year" : 1932,
        "shared_interaction" : "contributedTo",
        "name" : "William Empson (contributedTo) New Signatures Poems by Several Hands",
        "interaction" : "contributedTo",
        "certainty" : "definite",
        "SUID" : 3784,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3779",
        "source" : "3777",
        "target" : "3761",
        "shared_name" : "Richard Eberhart (contributedTo) New Signatures Poems by Several Hands",
        "Attribute_1_year" : 1932,
        "shared_interaction" : "contributedTo",
        "name" : "Richard Eberhart (contributedTo) New Signatures Poems by Several Hands",
        "interaction" : "contributedTo",
        "certainty" : "definite",
        "SUID" : 3779,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4629",
        "source" : "3766",
        "target" : "4624",
        "shared_name" : "W. H. Auden (authorOf) Education Today and Tomorrow",
        "Attribute_1_year" : 1939,
        "shared_interaction" : "authorOf",
        "name" : "W. H. Auden (authorOf) Education Today and Tomorrow",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4629,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3948",
        "source" : "3766",
        "target" : "3940",
        "shared_name" : "W. H. Auden (contributedTo) New Country Prose and Poetry by the authors of New Signatures",
        "Attribute_1_year" : 1933,
        "shared_interaction" : "contributedTo",
        "name" : "W. H. Auden (contributedTo) New Country Prose and Poetry by the authors of New Signatures",
        "interaction" : "contributedTo",
        "certainty" : "definite",
        "SUID" : 3948,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3768",
        "source" : "3766",
        "target" : "3761",
        "shared_name" : "W. H. Auden (contributedTo) New Signatures Poems by Several Hands",
        "Attribute_1_year" : 1932,
        "shared_interaction" : "contributedTo",
        "name" : "W. H. Auden (contributedTo) New Signatures Poems by Several Hands",
        "interaction" : "contributedTo",
        "certainty" : "definite",
        "SUID" : 3768,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3986",
        "source" : "3759",
        "target" : "3940",
        "shared_name" : "Michael Roberts (contributedTo) New Country Prose and Poetry by the authors of New Signatures",
        "Attribute_1_year" : 1933,
        "shared_interaction" : "contributedTo",
        "name" : "Michael Roberts (contributedTo) New Country Prose and Poetry by the authors of New Signatures",
        "interaction" : "contributedTo",
        "certainty" : "definite",
        "SUID" : 3986,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3942",
        "source" : "3759",
        "target" : "3940",
        "shared_name" : "Michael Roberts (editorOf) New Country Prose and Poetry by the authors of New Signatures",
        "Attribute_1_year" : 1933,
        "shared_interaction" : "editorOf",
        "name" : "Michael Roberts (editorOf) New Country Prose and Poetry by the authors of New Signatures",
        "interaction" : "editorOf",
        "certainty" : "definite",
        "SUID" : 3942,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3763",
        "source" : "3759",
        "target" : "3761",
        "shared_name" : "Michael Roberts (editorOf) New Signatures Poems by Several Hands",
        "Attribute_1_year" : 1932,
        "shared_interaction" : "editorOf",
        "name" : "Michael Roberts (editorOf) New Signatures Poems by Several Hands",
        "interaction" : "editorOf",
        "certainty" : "definite",
        "SUID" : 3763,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3753",
        "source" : "3751",
        "target" : "3746",
        "shared_name" : "The Rt. Hon. Wedgwood Benn. (wroteForewordFor) India in Transition",
        "Attribute_1_year" : 1932,
        "shared_interaction" : "wroteForewordFor",
        "name" : "The Rt. Hon. Wedgwood Benn. (wroteForewordFor) India in Transition",
        "interaction" : "wroteForewordFor",
        "certainty" : "definite",
        "SUID" : 3753,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3748",
        "source" : "3744",
        "target" : "3746",
        "shared_name" : "D. Graham Pole (authorOf) India in Transition",
        "Attribute_1_year" : 1932,
        "shared_interaction" : "authorOf",
        "name" : "D. Graham Pole (authorOf) India in Transition",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 3748,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3725",
        "source" : "3723",
        "target" : "3718",
        "shared_name" : "Herbert Agar. (translatedFor) The Defeat of Baudelaire A Psycho-Analytical Study of the Neuroses of Charles Baudelaire",
        "Attribute_1_year" : 1932,
        "shared_interaction" : "translatedFor",
        "name" : "Herbert Agar. (translatedFor) The Defeat of Baudelaire A Psycho-Analytical Study of the Neuroses of Charles Baudelaire",
        "interaction" : "translatedFor",
        "certainty" : "definite",
        "SUID" : 3725,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4575",
        "source" : "3716",
        "target" : "4573",
        "shared_name" : "René Laforgue (authorOf) Clinical Aspects of Psycho-Analysis",
        "Attribute_1_year" : 1938,
        "shared_interaction" : "authorOf",
        "name" : "René Laforgue (authorOf) Clinical Aspects of Psycho-Analysis",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4575,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3720",
        "source" : "3716",
        "target" : "3718",
        "shared_name" : "René Laforgue (authorOf) The Defeat of Baudelaire A Psycho-Analytical Study of the Neuroses of Charles Baudelaire",
        "Attribute_1_year" : 1932,
        "shared_interaction" : "authorOf",
        "name" : "René Laforgue (authorOf) The Defeat of Baudelaire A Psycho-Analytical Study of the Neuroses of Charles Baudelaire",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 3720,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4671",
        "source" : "3711",
        "target" : "4666",
        "shared_name" : "John Banting (designedJacketFor) Party Going",
        "Attribute_1_year" : 1939,
        "shared_interaction" : "designedJacketFor",
        "name" : "John Banting (designedJacketFor) Party Going",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 4671,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4371",
        "source" : "3711",
        "target" : "4366",
        "shared_name" : "John Banting (designedJacketFor) The Marchesa and Other Stories",
        "Attribute_1_year" : 1936,
        "shared_interaction" : "designedJacketFor",
        "name" : "John Banting (designedJacketFor) The Marchesa and Other Stories",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 4371,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4255",
        "source" : "3711",
        "target" : "4250",
        "shared_name" : "John Banting (designedJacketFor) Windless Sky",
        "Attribute_1_year" : 1936,
        "shared_interaction" : "designedJacketFor",
        "name" : "John Banting (designedJacketFor) Windless Sky",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 4255,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4193",
        "source" : "3711",
        "target" : "4188",
        "shared_name" : "John Banting (designedJacketFor) Mr. Norris changes Trains",
        "Attribute_1_year" : 1935,
        "shared_interaction" : "designedJacketFor",
        "name" : "John Banting (designedJacketFor) Mr. Norris changes Trains",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 4193,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4177",
        "source" : "3711",
        "target" : "4167",
        "shared_name" : "John Banting (designedJacketFor) Grammar of Love",
        "Attribute_1_year" : 1935,
        "shared_interaction" : "designedJacketFor",
        "name" : "John Banting (designedJacketFor) Grammar of Love",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 4177,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4028",
        "source" : "3711",
        "target" : "4023",
        "shared_name" : "John Banting (designedJacketFor) Illyria, Lady",
        "Attribute_1_year" : 1934,
        "shared_interaction" : "designedJacketFor",
        "name" : "John Banting (designedJacketFor) Illyria, Lady",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 4028,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3937",
        "source" : "3711",
        "target" : "3932",
        "shared_name" : "John Banting (designedJacketFor) The Twilight Age, A Fragment of Life",
        "Attribute_1_year" : 1933,
        "shared_interaction" : "designedJacketFor",
        "name" : "John Banting (designedJacketFor) The Twilight Age, A Fragment of Life",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 3937,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3741",
        "source" : "3711",
        "target" : "3736",
        "shared_name" : "John Banting (designedJacketFor) The Case is Altered",
        "Attribute_1_year" : 1932,
        "shared_interaction" : "designedJacketFor",
        "name" : "John Banting (designedJacketFor) The Case is Altered",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 3741,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3713",
        "source" : "3711",
        "target" : "3706",
        "shared_name" : "John Banting (designedJacketFor) The Memorial Portrait of a Family",
        "Attribute_1_year" : 1932,
        "shared_interaction" : "designedJacketFor",
        "name" : "John Banting (designedJacketFor) The Memorial Portrait of a Family",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 3713,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4686",
        "source" : "3704",
        "target" : "4684",
        "shared_name" : "Christopher Isherwood (authorOf) Goodbye to Berlin",
        "Attribute_1_year" : 1939,
        "shared_interaction" : "authorOf",
        "name" : "Christopher Isherwood (authorOf) Goodbye to Berlin",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4686,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4565",
        "source" : "3704",
        "target" : "4563",
        "shared_name" : "Christopher Isherwood (authorOf) Lions and Shadows An Education in the Twenties",
        "Attribute_1_year" : 1938,
        "shared_interaction" : "authorOf",
        "name" : "Christopher Isherwood (authorOf) Lions and Shadows An Education in the Twenties",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4565,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4472",
        "source" : "3704",
        "target" : "4470",
        "shared_name" : "Christopher Isherwood (authorOf) Sally Bowles",
        "Attribute_1_year" : 1937,
        "shared_interaction" : "authorOf",
        "name" : "Christopher Isherwood (authorOf) Sally Bowles",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4472,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4190",
        "source" : "3704",
        "target" : "4188",
        "shared_name" : "Christopher Isherwood (authorOf) Mr. Norris changes Trains",
        "Attribute_1_year" : 1935,
        "shared_interaction" : "authorOf",
        "name" : "Christopher Isherwood (authorOf) Mr. Norris changes Trains",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4190,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3972",
        "source" : "3704",
        "target" : "3940",
        "shared_name" : "Christopher Isherwood (contributedTo) New Country Prose and Poetry by the authors of New Signatures",
        "Attribute_1_year" : 1933,
        "shared_interaction" : "contributedTo",
        "name" : "Christopher Isherwood (contributedTo) New Country Prose and Poetry by the authors of New Signatures",
        "interaction" : "contributedTo",
        "certainty" : "definite",
        "SUID" : 3972,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3708",
        "source" : "3704",
        "target" : "3706",
        "shared_name" : "Christopher Isherwood (authorOf) The Memorial Portrait of a Family",
        "Attribute_1_year" : 1932,
        "shared_interaction" : "authorOf",
        "name" : "Christopher Isherwood (authorOf) The Memorial Portrait of a Family",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 3708,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3698",
        "source" : "3694",
        "target" : "3696",
        "shared_name" : "Irvine Lyn Ll. (authorOf) Ten Letter-Writers",
        "Attribute_1_year" : 1932,
        "shared_interaction" : "authorOf",
        "name" : "Irvine Lyn Ll. (authorOf) Ten Letter-Writers",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 3698,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3680",
        "source" : "3676",
        "target" : "3678",
        "shared_name" : "G. T. Garratt (authorOf) The Mugwumps and the Labour Party",
        "Attribute_1_year" : 1932,
        "shared_interaction" : "authorOf",
        "name" : "G. T. Garratt (authorOf) The Mugwumps and the Labour Party",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 3680,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3662",
        "source" : "3658",
        "target" : "3660",
        "shared_name" : "Dr. Helene Deutsch (authorOf) Psycho-analysis of the Neuroses",
        "Attribute_1_year" : 1932,
        "shared_interaction" : "authorOf",
        "name" : "Dr. Helene Deutsch (authorOf) Psycho-analysis of the Neuroses",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 3662,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3636",
        "source" : "3632",
        "target" : "3634",
        "shared_name" : "Marjorie Wise (authorOf) English Village Schools",
        "Attribute_1_year" : 1931,
        "shared_interaction" : "authorOf",
        "name" : "Marjorie Wise (authorOf) English Village Schools",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 3636,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3626",
        "source" : "3622",
        "target" : "3624",
        "shared_name" : "Rupert Trouton (authorOf) Unemployment Its Causes and Their Remedies",
        "Attribute_1_year" : 1931,
        "shared_interaction" : "authorOf",
        "name" : "Rupert Trouton (authorOf) Unemployment Its Causes and Their Remedies",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 3626,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3619",
        "source" : "3617",
        "target" : "3612",
        "shared_name" : "E. J. Langford Garstin (coeditedWith) The Search A Quarterly Review",
        "Attribute_1_year" : 1931,
        "shared_interaction" : "coeditedWith",
        "name" : "E. J. Langford Garstin (coeditedWith) The Search A Quarterly Review",
        "interaction" : "coeditedWith",
        "certainty" : "definite",
        "SUID" : 3619,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3590",
        "source" : "3588",
        "target" : "3532",
        "shared_name" : "Insel-Verlag (bookAgentFor) Duineser Elegien Elegies from the Castle of Duino",
        "Attribute_1_year" : 1931,
        "shared_interaction" : "bookAgentFor",
        "name" : "Insel-Verlag (bookAgentFor) Duineser Elegien Elegies from the Castle of Duino",
        "interaction" : "bookAgentFor",
        "certainty" : "definite",
        "SUID" : 3590,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3585",
        "source" : "3583",
        "target" : "3532",
        "shared_name" : "Willi Laste (printedFor) Duineser Elegien Elegies from the Castle of Duino",
        "Attribute_1_year" : 1931,
        "shared_interaction" : "printedFor",
        "name" : "Willi Laste (printedFor) Duineser Elegien Elegies from the Castle of Duino",
        "interaction" : "printedFor",
        "certainty" : "definite",
        "SUID" : 3585,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3580",
        "source" : "3578",
        "target" : "3532",
        "shared_name" : "Hans Schulze (typesetFor) Duineser Elegien Elegies from the Castle of Duino",
        "Attribute_1_year" : 1931,
        "shared_interaction" : "typesetFor",
        "name" : "Hans Schulze (typesetFor) Duineser Elegien Elegies from the Castle of Duino",
        "interaction" : "typesetFor",
        "certainty" : "definite",
        "SUID" : 3580,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3575",
        "source" : "3573",
        "target" : "3532",
        "shared_name" : "Walter Tanz (typesetFor) Duineser Elegien Elegies from the Castle of Duino",
        "Attribute_1_year" : 1931,
        "shared_interaction" : "typesetFor",
        "name" : "Walter Tanz (typesetFor) Duineser Elegien Elegies from the Castle of Duino",
        "interaction" : "typesetFor",
        "certainty" : "definite",
        "SUID" : 3575,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3570",
        "source" : "3568",
        "target" : "3532",
        "shared_name" : "Cranach Press (madePaperFor) Duineser Elegien Elegies from the Castle of Duino",
        "Attribute_1_year" : 1931,
        "shared_interaction" : "madePaperFor",
        "name" : "Cranach Press (madePaperFor) Duineser Elegien Elegies from the Castle of Duino",
        "interaction" : "madePaperFor",
        "certainty" : "definite",
        "SUID" : 3570,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3565",
        "source" : "3563",
        "target" : "3532",
        "shared_name" : "G. T. Friend (cutTypeFor) Duineser Elegien Elegies from the Castle of Duino",
        "Attribute_1_year" : 1931,
        "shared_interaction" : "cutTypeFor",
        "name" : "G. T. Friend (cutTypeFor) Duineser Elegien Elegies from the Castle of Duino",
        "interaction" : "cutTypeFor",
        "certainty" : "definite",
        "SUID" : 3565,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3560",
        "source" : "3558",
        "target" : "3532",
        "shared_name" : "E. Prince (cutTypeFor) Duineser Elegien Elegies from the Castle of Duino",
        "Attribute_1_year" : 1931,
        "shared_interaction" : "cutTypeFor",
        "name" : "E. Prince (cutTypeFor) Duineser Elegien Elegies from the Castle of Duino",
        "interaction" : "cutTypeFor",
        "certainty" : "definite",
        "SUID" : 3560,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3555",
        "source" : "3553",
        "target" : "3532",
        "shared_name" : "Edward Johnston (designedTypeFor) Duineser Elegien Elegies from the Castle of Duino",
        "Attribute_1_year" : 1931,
        "shared_interaction" : "designedTypeFor",
        "name" : "Edward Johnston (designedTypeFor) Duineser Elegien Elegies from the Castle of Duino",
        "interaction" : "designedTypeFor",
        "certainty" : "definite",
        "SUID" : 3555,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3550",
        "source" : "3548",
        "target" : "3532",
        "shared_name" : "Eric Gill (illustratedFor) Duineser Elegien Elegies from the Castle of Duino",
        "Attribute_1_year" : 1931,
        "shared_interaction" : "illustratedFor",
        "Column" : "woodcut initials",
        "name" : "Eric Gill (illustratedFor) Duineser Elegien Elegies from the Castle of Duino",
        "interaction" : "illustratedFor",
        "certainty" : "definite",
        "SUID" : 3550,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3545",
        "source" : "3543",
        "target" : "3532",
        "shared_name" : "Count Harry Kessler (plannedFormatOf) Duineser Elegien Elegies from the Castle of Duino",
        "Attribute_1_year" : 1931,
        "shared_interaction" : "plannedFormatOf",
        "name" : "Count Harry Kessler (plannedFormatOf) Duineser Elegien Elegies from the Castle of Duino",
        "interaction" : "plannedFormatOf",
        "certainty" : "definite",
        "SUID" : 3545,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3691",
        "source" : "3516",
        "target" : "3686",
        "shared_name" : "John Armstrong (designedJacketFor) O Providence",
        "Attribute_1_year" : 1932,
        "shared_interaction" : "designedJacketFor",
        "name" : "John Armstrong (designedJacketFor) O Providence",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 3691,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3518",
        "source" : "3516",
        "target" : "3511",
        "shared_name" : "John Armstrong (designedJacketFor) Sado",
        "Attribute_1_year" : 1931,
        "shared_interaction" : "designedJacketFor",
        "name" : "John Armstrong (designedJacketFor) Sado",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 3518,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3497",
        "source" : "3493",
        "target" : "3495",
        "shared_name" : "Allen Havens (authorOf) The Trap",
        "Attribute_1_year" : 1931,
        "shared_interaction" : "authorOf",
        "name" : "Allen Havens (authorOf) The Trap",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 3497,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3969",
        "source" : "3483",
        "target" : "3940",
        "shared_name" : "John Hampson (contributedTo) New Country Prose and Poetry by the authors of New Signatures",
        "Attribute_1_year" : 1933,
        "shared_interaction" : "contributedTo",
        "name" : "John Hampson (contributedTo) New Country Prose and Poetry by the authors of New Signatures",
        "interaction" : "contributedTo",
        "certainty" : "definite",
        "SUID" : 3969,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3688",
        "source" : "3483",
        "target" : "3686",
        "shared_name" : "John Hampson (authorOf) O Providence",
        "Attribute_1_year" : 1932,
        "shared_interaction" : "authorOf",
        "name" : "John Hampson (authorOf) O Providence",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 3688,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3487",
        "source" : "3483",
        "target" : "3485",
        "shared_name" : "John Hampson (authorOf) Saturday Night at the Greyhound",
        "Attribute_1_year" : 1931,
        "shared_interaction" : "authorOf",
        "name" : "John Hampson (authorOf) Saturday Night at the Greyhound",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 3487,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3477",
        "source" : "3473",
        "target" : "3475",
        "shared_name" : "Margaret Llewelyn Davies (editorOf) Life as we have known it By Co-Operative working women",
        "Attribute_1_year" : 1931,
        "shared_interaction" : "editorOf",
        "name" : "Margaret Llewelyn Davies (editorOf) Life as we have known it By Co-Operative working women",
        "interaction" : "editorOf",
        "certainty" : "definite",
        "SUID" : 3477,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3470",
        "source" : "3468",
        "target" : "3400",
        "shared_name" : "A. D. W. (contributedTo) An Anthology of Cambridge Women's Verse",
        "Attribute_1_year" : 1931,
        "shared_interaction" : "contributedTo",
        "name" : "A. D. W. (contributedTo) An Anthology of Cambridge Women's Verse",
        "interaction" : "contributedTo",
        "certainty" : "definite",
        "SUID" : 3470,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3462",
        "source" : "3460",
        "target" : "3400",
        "shared_name" : "Kathleen Raine (contributedTo) An Anthology of Cambridge Women's Verse",
        "Attribute_1_year" : 1931,
        "shared_interaction" : "contributedTo",
        "name" : "Kathleen Raine (contributedTo) An Anthology of Cambridge Women's Verse",
        "interaction" : "contributedTo",
        "certainty" : "definite",
        "SUID" : 3462,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3457",
        "source" : "3455",
        "target" : "3400",
        "shared_name" : "F. Picot (contributedTo) An Anthology of Cambridge Women's Verse",
        "Attribute_1_year" : 1931,
        "shared_interaction" : "contributedTo",
        "name" : "F. Picot (contributedTo) An Anthology of Cambridge Women's Verse",
        "interaction" : "contributedTo",
        "certainty" : "definite",
        "SUID" : 3457,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3452",
        "source" : "3450",
        "target" : "3400",
        "shared_name" : "E. E. Phare (contributedTo) An Anthology of Cambridge Women's Verse",
        "Attribute_1_year" : 1931,
        "shared_interaction" : "contributedTo",
        "name" : "E. E. Phare (contributedTo) An Anthology of Cambridge Women's Verse",
        "interaction" : "contributedTo",
        "certainty" : "definite",
        "SUID" : 3452,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3447",
        "source" : "3445",
        "target" : "3400",
        "shared_name" : "M. N. (contributedTo) An Anthology of Cambridge Women's Verse",
        "Attribute_1_year" : 1931,
        "shared_interaction" : "contributedTo",
        "name" : "M. N. (contributedTo) An Anthology of Cambridge Women's Verse",
        "interaction" : "contributedTo",
        "certainty" : "definite",
        "SUID" : 3447,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3442",
        "source" : "3440",
        "target" : "3400",
        "shared_name" : "Helen Megaw (contributedTo) An Anthology of Cambridge Women's Verse",
        "Attribute_1_year" : 1931,
        "shared_interaction" : "contributedTo",
        "name" : "Helen Megaw (contributedTo) An Anthology of Cambridge Women's Verse",
        "interaction" : "contributedTo",
        "certainty" : "definite",
        "SUID" : 3442,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3437",
        "source" : "3435",
        "target" : "3400",
        "shared_name" : "Morwenna Lyne (contributedTo) An Anthology of Cambridge Women's Verse",
        "Attribute_1_year" : 1931,
        "shared_interaction" : "contributedTo",
        "name" : "Morwenna Lyne (contributedTo) An Anthology of Cambridge Women's Verse",
        "interaction" : "contributedTo",
        "certainty" : "definite",
        "SUID" : 3437,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3432",
        "source" : "3430",
        "target" : "3400",
        "shared_name" : "E. S. D. H. (contributedTo) An Anthology of Cambridge Women's Verse",
        "Attribute_1_year" : 1931,
        "shared_interaction" : "contributedTo",
        "name" : "E. S. D. H. (contributedTo) An Anthology of Cambridge Women's Verse",
        "interaction" : "contributedTo",
        "certainty" : "definite",
        "SUID" : 3432,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3427",
        "source" : "3425",
        "target" : "3400",
        "shared_name" : "Muriel Hardill (contributedTo) An Anthology of Cambridge Women's Verse",
        "Attribute_1_year" : 1931,
        "shared_interaction" : "contributedTo",
        "name" : "Muriel Hardill (contributedTo) An Anthology of Cambridge Women's Verse",
        "interaction" : "contributedTo",
        "certainty" : "definite",
        "SUID" : 3427,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3422",
        "source" : "3420",
        "target" : "3400",
        "shared_name" : "Alethea Graham (contributedTo) An Anthology of Cambridge Women's Verse",
        "Attribute_1_year" : 1931,
        "shared_interaction" : "contributedTo",
        "name" : "Alethea Graham (contributedTo) An Anthology of Cambridge Women's Verse",
        "interaction" : "contributedTo",
        "certainty" : "definite",
        "SUID" : 3422,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3417",
        "source" : "3415",
        "target" : "3400",
        "shared_name" : "Jocelyne Gibson (contributedTo) An Anthology of Cambridge Women's Verse",
        "Attribute_1_year" : 1931,
        "shared_interaction" : "contributedTo",
        "name" : "Jocelyne Gibson (contributedTo) An Anthology of Cambridge Women's Verse",
        "interaction" : "contributedTo",
        "certainty" : "definite",
        "SUID" : 3417,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3412",
        "source" : "3410",
        "target" : "3400",
        "shared_name" : "Gwendolen Freeman (contributedTo) An Anthology of Cambridge Women's Verse",
        "Attribute_1_year" : 1931,
        "shared_interaction" : "contributedTo",
        "name" : "Gwendolen Freeman (contributedTo) An Anthology of Cambridge Women's Verse",
        "interaction" : "contributedTo",
        "certainty" : "definite",
        "SUID" : 3412,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3407",
        "source" : "3405",
        "target" : "3400",
        "shared_name" : "Margaret Diggle (contributedTo) An Anthology of Cambridge Women's Verse",
        "Attribute_1_year" : 1931,
        "shared_interaction" : "contributedTo",
        "name" : "Margaret Diggle (contributedTo) An Anthology of Cambridge Women's Verse",
        "interaction" : "contributedTo",
        "certainty" : "definite",
        "SUID" : 3407,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3465",
        "source" : "3398",
        "target" : "3400",
        "shared_name" : "Margaret Thomas (contributedTo) An Anthology of Cambridge Women's Verse",
        "Attribute_1_year" : 1931,
        "shared_interaction" : "contributedTo",
        "name" : "Margaret Thomas (contributedTo) An Anthology of Cambridge Women's Verse",
        "interaction" : "contributedTo",
        "certainty" : "definite",
        "SUID" : 3465,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3402",
        "source" : "3398",
        "target" : "3400",
        "shared_name" : "Margaret Thomas (editorOf) An Anthology of Cambridge Women's Verse",
        "Attribute_1_year" : 1931,
        "shared_interaction" : "editorOf",
        "name" : "Margaret Thomas (editorOf) An Anthology of Cambridge Women's Verse",
        "interaction" : "editorOf",
        "certainty" : "definite",
        "SUID" : 3402,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3395",
        "source" : "3393",
        "target" : "3383",
        "shared_name" : "George Strauss, MP (authorOf) What We Saw in Russia",
        "Attribute_1_year" : 1931,
        "shared_interaction" : "authorOf",
        "name" : "George Strauss, MP (authorOf) What We Saw in Russia",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 3395,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3390",
        "source" : "3388",
        "target" : "3383",
        "shared_name" : "E. J. Strachey, MP (authorOf) What We Saw in Russia",
        "Attribute_1_year" : 1931,
        "shared_interaction" : "authorOf",
        "name" : "E. J. Strachey, MP (authorOf) What We Saw in Russia",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 3390,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3385",
        "source" : "3381",
        "target" : "3383",
        "shared_name" : "Aneurin Bevan, MP (authorOf) What We Saw in Russia",
        "Attribute_1_year" : 1931,
        "shared_interaction" : "authorOf",
        "name" : "Aneurin Bevan, MP (authorOf) What We Saw in Russia",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 3385,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3361",
        "source" : "3359",
        "target" : "3244",
        "shared_name" : "Francis Brett Young (contributedTo) A Broadcast Anthology of Modern Poetry",
        "Attribute_1_year" : 1930,
        "shared_interaction" : "contributedTo",
        "name" : "Francis Brett Young (contributedTo) A Broadcast Anthology of Modern Poetry",
        "interaction" : "contributedTo",
        "certainty" : "definite",
        "SUID" : 3361,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3353",
        "source" : "3351",
        "target" : "3244",
        "shared_name" : "Muriel Stuart (contributedTo) A Broadcast Anthology of Modern Poetry",
        "Attribute_1_year" : 1930,
        "shared_interaction" : "contributedTo",
        "name" : "Muriel Stuart (contributedTo) A Broadcast Anthology of Modern Poetry",
        "interaction" : "contributedTo",
        "certainty" : "definite",
        "SUID" : 3353,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3348",
        "source" : "3346",
        "target" : "3244",
        "shared_name" : "J. C. Squire (contributedTo) A Broadcast Anthology of Modern Poetry",
        "Attribute_1_year" : 1930,
        "shared_interaction" : "contributedTo",
        "name" : "J. C. Squire (contributedTo) A Broadcast Anthology of Modern Poetry",
        "interaction" : "contributedTo",
        "certainty" : "definite",
        "SUID" : 3348,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3343",
        "source" : "3341",
        "target" : "3244",
        "shared_name" : "Sacheverell Sitwell (contributedTo) A Broadcast Anthology of Modern Poetry",
        "Attribute_1_year" : 1930,
        "shared_interaction" : "contributedTo",
        "name" : "Sacheverell Sitwell (contributedTo) A Broadcast Anthology of Modern Poetry",
        "interaction" : "contributedTo",
        "certainty" : "definite",
        "SUID" : 3343,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3329",
        "source" : "3327",
        "target" : "3244",
        "shared_name" : "Wilfred Owen (contributedTo) A Broadcast Anthology of Modern Poetry",
        "Attribute_1_year" : 1930,
        "shared_interaction" : "contributedTo",
        "name" : "Wilfred Owen (contributedTo) A Broadcast Anthology of Modern Poetry",
        "interaction" : "contributedTo",
        "certainty" : "definite",
        "SUID" : 3329,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3324",
        "source" : "3322",
        "target" : "3244",
        "shared_name" : "Robert Nichols (contributedTo) A Broadcast Anthology of Modern Poetry",
        "Attribute_1_year" : 1930,
        "shared_interaction" : "contributedTo",
        "name" : "Robert Nichols (contributedTo) A Broadcast Anthology of Modern Poetry",
        "interaction" : "contributedTo",
        "certainty" : "definite",
        "SUID" : 3324,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3313",
        "source" : "3311",
        "target" : "3244",
        "shared_name" : "James Joyce (contributedTo) A Broadcast Anthology of Modern Poetry",
        "Attribute_1_year" : 1930,
        "shared_interaction" : "contributedTo",
        "name" : "James Joyce (contributedTo) A Broadcast Anthology of Modern Poetry",
        "interaction" : "contributedTo",
        "certainty" : "definite",
        "SUID" : 3313,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3308",
        "source" : "3306",
        "target" : "3244",
        "shared_name" : "Julian Grenfell (contributedTo) A Broadcast Anthology of Modern Poetry",
        "Attribute_1_year" : 1930,
        "shared_interaction" : "contributedTo",
        "name" : "Julian Grenfell (contributedTo) A Broadcast Anthology of Modern Poetry",
        "interaction" : "contributedTo",
        "certainty" : "definite",
        "SUID" : 3308,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3300",
        "source" : "3298",
        "target" : "3244",
        "shared_name" : "Gerald Gould (contributedTo) A Broadcast Anthology of Modern Poetry",
        "Attribute_1_year" : 1930,
        "shared_interaction" : "contributedTo",
        "name" : "Gerald Gould (contributedTo) A Broadcast Anthology of Modern Poetry",
        "interaction" : "contributedTo",
        "certainty" : "definite",
        "SUID" : 3300,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3295",
        "source" : "3293",
        "target" : "3244",
        "shared_name" : "John Freeman (contributedTo) A Broadcast Anthology of Modern Poetry",
        "Attribute_1_year" : 1930,
        "shared_interaction" : "contributedTo",
        "name" : "John Freeman (contributedTo) A Broadcast Anthology of Modern Poetry",
        "interaction" : "contributedTo",
        "certainty" : "definite",
        "SUID" : 3295,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3287",
        "source" : "3285",
        "target" : "3244",
        "shared_name" : "John Drinkwater (contributedTo) A Broadcast Anthology of Modern Poetry",
        "Attribute_1_year" : 1930,
        "shared_interaction" : "contributedTo",
        "name" : "John Drinkwater (contributedTo) A Broadcast Anthology of Modern Poetry",
        "interaction" : "contributedTo",
        "certainty" : "definite",
        "SUID" : 3287,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3279",
        "source" : "3277",
        "target" : "3244",
        "shared_name" : "Richard Church (contributedTo) A Broadcast Anthology of Modern Poetry",
        "Attribute_1_year" : 1930,
        "shared_interaction" : "contributedTo",
        "name" : "Richard Church (contributedTo) A Broadcast Anthology of Modern Poetry",
        "interaction" : "contributedTo",
        "certainty" : "definite",
        "SUID" : 3279,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3274",
        "source" : "3272",
        "target" : "3244",
        "shared_name" : "Roy Campbell (contributedTo) A Broadcast Anthology of Modern Poetry",
        "Attribute_1_year" : 1930,
        "shared_interaction" : "contributedTo",
        "name" : "Roy Campbell (contributedTo) A Broadcast Anthology of Modern Poetry",
        "interaction" : "contributedTo",
        "certainty" : "definite",
        "SUID" : 3274,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3269",
        "source" : "3267",
        "target" : "3244",
        "shared_name" : "Rupert Brooke (contributedTo) A Broadcast Anthology of Modern Poetry",
        "Attribute_1_year" : 1930,
        "shared_interaction" : "contributedTo",
        "name" : "Rupert Brooke (contributedTo) A Broadcast Anthology of Modern Poetry",
        "interaction" : "contributedTo",
        "certainty" : "definite",
        "SUID" : 3269,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3261",
        "source" : "3259",
        "target" : "3244",
        "shared_name" : "Kenneth Ashley (contributedTo) A Broadcast Anthology of Modern Poetry",
        "Attribute_1_year" : 1930,
        "shared_interaction" : "contributedTo",
        "name" : "Kenneth Ashley (contributedTo) A Broadcast Anthology of Modern Poetry",
        "interaction" : "contributedTo",
        "certainty" : "definite",
        "SUID" : 3261,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3256",
        "source" : "3254",
        "target" : "3244",
        "shared_name" : "Martin Armstrong (contributedTo) A Broadcast Anthology of Modern Poetry",
        "Attribute_1_year" : 1930,
        "shared_interaction" : "contributedTo",
        "name" : "Martin Armstrong (contributedTo) A Broadcast Anthology of Modern Poetry",
        "interaction" : "contributedTo",
        "certainty" : "definite",
        "SUID" : 3256,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3251",
        "source" : "3249",
        "target" : "3244",
        "shared_name" : "Claude Colleer Abbott (contributedTo) A Broadcast Anthology of Modern Poetry",
        "Attribute_1_year" : 1930,
        "shared_interaction" : "contributedTo",
        "name" : "Claude Colleer Abbott (contributedTo) A Broadcast Anthology of Modern Poetry",
        "interaction" : "contributedTo",
        "certainty" : "definite",
        "SUID" : 3251,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3241",
        "source" : "3239",
        "target" : "3229",
        "shared_name" : "Eugenio Montale (wroteIntroductionFor) The Nice Old Man and the Pretty Girl and other stories",
        "Attribute_1_year" : 1930,
        "shared_interaction" : "wroteIntroductionFor",
        "name" : "Eugenio Montale (wroteIntroductionFor) The Nice Old Man and the Pretty Girl and other stories",
        "interaction" : "wroteIntroductionFor",
        "certainty" : "definite",
        "SUID" : 3241,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3236",
        "source" : "3234",
        "target" : "3229",
        "shared_name" : "L. Collison-Morley (translatedFor) The Nice Old Man and the Pretty Girl and other stories",
        "Attribute_1_year" : 1930,
        "shared_interaction" : "translatedFor",
        "name" : "L. Collison-Morley (translatedFor) The Nice Old Man and the Pretty Girl and other stories",
        "interaction" : "translatedFor",
        "certainty" : "definite",
        "SUID" : 3236,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3216",
        "source" : "3214",
        "target" : "3209",
        "shared_name" : "John Linton (translatedFor) The Notebook of Malte Laurids Brigge",
        "Attribute_1_year" : 1930,
        "shared_interaction" : "translatedFor",
        "name" : "John Linton (translatedFor) The Notebook of Malte Laurids Brigge",
        "interaction" : "translatedFor",
        "certainty" : "definite",
        "SUID" : 3216,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4805",
        "source" : "3207",
        "target" : "4797",
        "shared_name" : "Rainer Maria Rilke (authorOf) Selected Poems_4",
        "Attribute_1_year" : 1941,
        "shared_interaction" : "authorOf",
        "name" : "Rainer Maria Rilke (authorOf) Selected Poems_4",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4805,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4734",
        "source" : "3207",
        "target" : "4732",
        "shared_name" : "Rainer Maria Rilke (authorOf) Duino Elegies",
        "Attribute_1_year" : 1939,
        "shared_interaction" : "authorOf",
        "name" : "Rainer Maria Rilke (authorOf) Duino Elegies",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4734,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4597",
        "source" : "3207",
        "target" : "4595",
        "shared_name" : "Rainer Maria Rilke (authorOf) Later Poems",
        "Attribute_1_year" : 1938,
        "shared_interaction" : "authorOf",
        "name" : "Rainer Maria Rilke (authorOf) Later Poems",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4597,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4312",
        "source" : "3207",
        "target" : "4310",
        "shared_name" : "Rainer Maria Rilke (authorOf) Sonnets to Orpheus Written as a monument for Wera Oukama Knoop",
        "Attribute_1_year" : 1936,
        "shared_interaction" : "authorOf",
        "name" : "Rainer Maria Rilke (authorOf) Sonnets to Orpheus Written as a monument for Wera Oukama Knoop",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4312,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4209",
        "source" : "3207",
        "target" : "4207",
        "shared_name" : "Rainer Maria Rilke (authorOf) Requiem and Other Poems",
        "Attribute_1_year" : 1935,
        "shared_interaction" : "authorOf",
        "name" : "Rainer Maria Rilke (authorOf) Requiem and Other Poems",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4209,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4094",
        "source" : "3207",
        "target" : "4092",
        "shared_name" : "Rainer Maria Rilke (authorOf) Poems_10",
        "Attribute_1_year" : 1934,
        "shared_interaction" : "authorOf",
        "name" : "Rainer Maria Rilke (authorOf) Poems_10",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4094,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3534",
        "source" : "3207",
        "target" : "3532",
        "shared_name" : "Rainer Maria Rilke (authorOf) Duineser Elegien Elegies from the Castle of Duino",
        "Attribute_1_year" : 1931,
        "shared_interaction" : "authorOf",
        "name" : "Rainer Maria Rilke (authorOf) Duineser Elegien Elegies from the Castle of Duino",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 3534,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3211",
        "source" : "3207",
        "target" : "3209",
        "shared_name" : "Rainer Maria Rilke (authorOf) The Notebook of Malte Laurids Brigge",
        "Attribute_1_year" : 1930,
        "shared_interaction" : "authorOf",
        "name" : "Rainer Maria Rilke (authorOf) The Notebook of Malte Laurids Brigge",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 3211,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4204",
        "source" : "3199",
        "target" : "4196",
        "shared_name" : "Katherine John (translatedFor) Aesthetics and Psychology",
        "Attribute_1_year" : 1935,
        "shared_interaction" : "translatedFor",
        "name" : "Katherine John (translatedFor) Aesthetics and Psychology",
        "interaction" : "translatedFor",
        "certainty" : "definite",
        "SUID" : 4204,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3204",
        "source" : "3199",
        "target" : "3194",
        "shared_name" : "Katherine John (wroteIntroductionFor) Life of Milton Together with Observations on Paradise Lost",
        "Attribute_1_year" : 1930,
        "shared_interaction" : "wroteIntroductionFor",
        "name" : "Katherine John (wroteIntroductionFor) Life of Milton Together with Observations on Paradise Lost",
        "interaction" : "wroteIntroductionFor",
        "certainty" : "definite",
        "SUID" : 3204,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3201",
        "source" : "3199",
        "target" : "3194",
        "shared_name" : "Katherine John (translatedFor) Life of Milton Together with Observations on Paradise Lost",
        "Attribute_1_year" : 1930,
        "shared_interaction" : "translatedFor",
        "name" : "Katherine John (translatedFor) Life of Milton Together with Observations on Paradise Lost",
        "interaction" : "translatedFor",
        "certainty" : "definite",
        "SUID" : 3201,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3196",
        "source" : "3192",
        "target" : "3194",
        "shared_name" : "Louis Racine (authorOf) Life of Milton Together with Observations on Paradise Lost",
        "Attribute_1_year" : 1930,
        "shared_interaction" : "authorOf",
        "name" : "Louis Racine (authorOf) Life of Milton Together with Observations on Paradise Lost",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 3196,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3189",
        "source" : "3187",
        "target" : "3182",
        "shared_name" : "Horace Liverlight (printedFor) Dear Judas and Other Poems",
        "Attribute_1_year" : 1930,
        "shared_interaction" : "printedFor",
        "name" : "Horace Liverlight (printedFor) Dear Judas and Other Poems",
        "interaction" : "printedFor",
        "certainty" : "definite",
        "SUID" : 3189,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3176",
        "source" : "3172",
        "target" : "3174",
        "shared_name" : "John S. Hoyland (authorOf) History as Direction",
        "Attribute_1_year" : 1930,
        "shared_interaction" : "authorOf",
        "name" : "John S. Hoyland (authorOf) History as Direction",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 3176,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "5062",
        "source" : "3159",
        "target" : "5049",
        "shared_name" : "Trekkie Ritchie (Parsons) (designedJacketFor) Scottish Nursery Rhymes",
        "Attribute_1_year" : 1946,
        "shared_interaction" : "designedJacketFor",
        "name" : "Trekkie Ritchie (Parsons) (designedJacketFor) Scottish Nursery Rhymes",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 5062,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "5059",
        "source" : "3159",
        "target" : "5049",
        "shared_name" : "Trekkie Ritchie (Parsons) (illustratedFor) Scottish Nursery Rhymes",
        "Attribute_1_year" : 1946,
        "shared_interaction" : "illustratedFor",
        "name" : "Trekkie Ritchie (Parsons) (illustratedFor) Scottish Nursery Rhymes",
        "interaction" : "illustratedFor",
        "certainty" : "definite",
        "SUID" : 5059,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "5044",
        "source" : "3159",
        "target" : "5039",
        "shared_name" : "Trekkie Ritchie (Parsons) (designedJacketFor) Mist in the Tagus",
        "Attribute_1_year" : 1946,
        "shared_interaction" : "designedJacketFor",
        "name" : "Trekkie Ritchie (Parsons) (designedJacketFor) Mist in the Tagus",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 5044,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4941",
        "source" : "3159",
        "target" : "4933",
        "shared_name" : "Trekkie Ritchie (Parsons) (illustratedFor) The Three Rings",
        "Attribute_1_year" : 1944,
        "shared_interaction" : "illustratedFor",
        "name" : "Trekkie Ritchie (Parsons) (illustratedFor) The Three Rings",
        "interaction" : "illustratedFor",
        "certainty" : "definite",
        "SUID" : 4941,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4938",
        "source" : "3159",
        "target" : "4933",
        "shared_name" : "Trekkie Ritchie (Parsons) (designedJacketFor) The Three Rings",
        "Attribute_1_year" : 1944,
        "shared_interaction" : "designedJacketFor",
        "name" : "Trekkie Ritchie (Parsons) (designedJacketFor) The Three Rings",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 4938,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3673",
        "source" : "3159",
        "target" : "3668",
        "shared_name" : "Trekkie Ritchie (Parsons) (designedJacketFor) St. Martin's Summer",
        "Attribute_1_year" : 1932,
        "shared_interaction" : "designedJacketFor",
        "name" : "Trekkie Ritchie (Parsons) (designedJacketFor) St. Martin's Summer",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 3673,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3598",
        "source" : "3159",
        "target" : "3593",
        "shared_name" : "Trekkie Ritchie (Parsons) (designedJacketFor) All Passion Spent",
        "Attribute_1_year" : 1931,
        "shared_interaction" : "designedJacketFor",
        "name" : "Trekkie Ritchie (Parsons) (designedJacketFor) All Passion Spent",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 3598,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3490",
        "source" : "3159",
        "target" : "3485",
        "shared_name" : "Trekkie Ritchie (Parsons) (designedJacketFor) Saturday Night at the Greyhound",
        "Attribute_1_year" : 1931,
        "shared_interaction" : "designedJacketFor",
        "name" : "Trekkie Ritchie (Parsons) (designedJacketFor) Saturday Night at the Greyhound",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 3490,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3227",
        "source" : "3159",
        "target" : "950",
        "shared_name" : "Trekkie Ritchie (Parsons) (sisterOf) Alice Ritchie",
        "shared_interaction" : "sisterOf",
        "name" : "Trekkie Ritchie (Parsons) (sisterOf) Alice Ritchie",
        "interaction" : "sisterOf",
        "SUID" : 3227,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3224",
        "source" : "3159",
        "target" : "3219",
        "shared_name" : "Trekkie Ritchie (Parsons) (designedJacketFor) Occupied Territory",
        "Attribute_1_year" : 1930,
        "shared_interaction" : "designedJacketFor",
        "name" : "Trekkie Ritchie (Parsons) (designedJacketFor) Occupied Territory",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 3224,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3161",
        "source" : "3159",
        "target" : "3154",
        "shared_name" : "Trekkie Ritchie (Parsons) (designedJacketFor) Drifting Men",
        "Attribute_1_year" : 1930,
        "shared_interaction" : "designedJacketFor",
        "name" : "Trekkie Ritchie (Parsons) (designedJacketFor) Drifting Men",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 3161,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3151",
        "source" : "3149",
        "target" : "3139",
        "shared_name" : "Hugh Sykes (editorOf) Cambridge Poetry 1930",
        "Attribute_1_year" : 1930,
        "shared_interaction" : "editorOf",
        "name" : "Hugh Sykes (editorOf) Cambridge Poetry 1930",
        "interaction" : "editorOf",
        "certainty" : "definite",
        "SUID" : 3151,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3146",
        "source" : "3144",
        "target" : "3139",
        "shared_name" : "Michael Redgrave (editorOf) Cambridge Poetry 1930",
        "Attribute_1_year" : 1930,
        "shared_interaction" : "editorOf",
        "name" : "Michael Redgrave (editorOf) Cambridge Poetry 1930",
        "interaction" : "editorOf",
        "certainty" : "definite",
        "SUID" : 3146,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3114",
        "source" : "3104",
        "target" : "3109",
        "shared_name" : "Duckworth (importerOf) Night and Day",
        "Attribute_1_year" : 1929,
        "shared_interaction" : "importerOf",
        "name" : "Duckworth (importerOf) Night and Day",
        "interaction" : "importerOf",
        "certainty" : "definite",
        "SUID" : 3114,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3106",
        "source" : "3104",
        "target" : "3099",
        "shared_name" : "Duckworth (importerOf) The Voyage Out",
        "Attribute_1_year" : 1929,
        "shared_interaction" : "importerOf",
        "name" : "Duckworth (importerOf) The Voyage Out",
        "interaction" : "importerOf",
        "certainty" : "definite",
        "SUID" : 3106,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3096",
        "source" : "3091",
        "target" : "3086",
        "shared_name" : "Beryl de Zoete (wroteIntroductionFor) The Hoax",
        "Attribute_1_year" : 1929,
        "shared_interaction" : "wroteIntroductionFor",
        "name" : "Beryl de Zoete (wroteIntroductionFor) The Hoax",
        "interaction" : "wroteIntroductionFor",
        "certainty" : "definite",
        "SUID" : 3096,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3093",
        "source" : "3091",
        "target" : "3086",
        "shared_name" : "Beryl de Zoete (translatedFor) The Hoax",
        "Attribute_1_year" : 1929,
        "shared_interaction" : "translatedFor",
        "name" : "Beryl de Zoete (translatedFor) The Hoax",
        "interaction" : "translatedFor",
        "certainty" : "definite",
        "SUID" : 3093,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3231",
        "source" : "3084",
        "target" : "3229",
        "shared_name" : "Italo Svevo (authorOf) The Nice Old Man and the Pretty Girl and other stories",
        "Attribute_1_year" : 1930,
        "shared_interaction" : "authorOf",
        "name" : "Italo Svevo (authorOf) The Nice Old Man and the Pretty Girl and other stories",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 3231,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3088",
        "source" : "3084",
        "target" : "3086",
        "shared_name" : "Italo Svevo (authorOf) The Hoax",
        "Attribute_1_year" : 1929,
        "shared_interaction" : "authorOf",
        "name" : "Italo Svevo (authorOf) The Hoax",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 3088,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3073",
        "source" : "3068",
        "target" : "3063",
        "shared_name" : "E. J. Trenchman (wroteIntroductionFor) The Diary of Montaigne's Journey to Italy in 1580 and 1581",
        "Attribute_1_year" : 1929,
        "shared_interaction" : "wroteIntroductionFor",
        "name" : "E. J. Trenchman (wroteIntroductionFor) The Diary of Montaigne's Journey to Italy in 1580 and 1581",
        "interaction" : "wroteIntroductionFor",
        "certainty" : "definite",
        "SUID" : 3073,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3070",
        "source" : "3068",
        "target" : "3063",
        "shared_name" : "E. J. Trenchman (translatedFor) The Diary of Montaigne's Journey to Italy in 1580 and 1581",
        "Attribute_1_year" : 1929,
        "shared_interaction" : "translatedFor",
        "name" : "E. J. Trenchman (translatedFor) The Diary of Montaigne's Journey to Italy in 1580 and 1581",
        "interaction" : "translatedFor",
        "certainty" : "definite",
        "SUID" : 3070,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3065",
        "source" : "3061",
        "target" : "3063",
        "shared_name" : "Michel de Montaigne (authorOf) The Diary of Montaigne's Journey to Italy in 1580 and 1581",
        "Attribute_1_year" : 1929,
        "shared_interaction" : "authorOf",
        "name" : "Michel de Montaigne (authorOf) The Diary of Montaigne's Journey to Italy in 1580 and 1581",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 3065,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4748",
        "source" : "3056",
        "target" : "4743",
        "shared_name" : "Richard Kennedy (designedJacketFor) After the Deluge A Study of Communal Psychology Vol. II 1830 & 1832",
        "Attribute_1_year" : 1939,
        "shared_interaction" : "designedJacketFor",
        "name" : "Richard Kennedy (designedJacketFor) After the Deluge A Study of Communal Psychology Vol. II 1830 & 1832",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 4748,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4729",
        "source" : "3056",
        "target" : "4724",
        "shared_name" : "Richard Kennedy (designedJacketFor) Coeducation in its Historical and Theoretical Setting",
        "Attribute_1_year" : 1939,
        "shared_interaction" : "designedJacketFor",
        "name" : "Richard Kennedy (designedJacketFor) Coeducation in its Historical and Theoretical Setting",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 4729,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4663",
        "source" : "3056",
        "target" : "4658",
        "shared_name" : "Richard Kennedy (designedJacketFor) A History of Socialism",
        "Attribute_1_year" : 1939,
        "shared_interaction" : "designedJacketFor",
        "name" : "Richard Kennedy (designedJacketFor) A History of Socialism",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 4663,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4528",
        "source" : "3056",
        "target" : "4523",
        "shared_name" : "Richard Kennedy (designedJacketFor) The Banders of London",
        "Attribute_1_year" : 1938,
        "shared_interaction" : "designedJacketFor",
        "name" : "Richard Kennedy (designedJacketFor) The Banders of London",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 4528,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4475",
        "source" : "3056",
        "target" : "4470",
        "shared_name" : "Richard Kennedy (designedJacketFor) Sally Bowles",
        "Attribute_1_year" : 1937,
        "shared_interaction" : "designedJacketFor",
        "name" : "Richard Kennedy (designedJacketFor) Sally Bowles",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 4475,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4467",
        "source" : "3056",
        "target" : "4462",
        "shared_name" : "Richard Kennedy (designedJacketFor) Diet and High Blood Pressure",
        "Attribute_1_year" : 1937,
        "shared_interaction" : "designedJacketFor",
        "name" : "Richard Kennedy (designedJacketFor) Diet and High Blood Pressure",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 4467,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4338",
        "source" : "3056",
        "target" : "4333",
        "shared_name" : "Richard Kennedy (designedJacketFor) Our Freedom and Its Results by Five Women, Eleanor F. Rathbone, Erna Reiss, Ray Strachey, Allison Neilans, Mary Agnes Hamilton",
        "Attribute_1_year" : 1936,
        "shared_interaction" : "designedJacketFor",
        "name" : "Richard Kennedy (designedJacketFor) Our Freedom and Its Results by Five Women, Eleanor F. Rathbone, Erna Reiss, Ray Strachey, Allison Neilans, Mary Agnes Hamilton",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 4338,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4328",
        "source" : "3056",
        "target" : "4323",
        "shared_name" : "Richard Kennedy (designedJacketFor) Adventures in Investing by \"Securitas\" (Financial Editor of Time and Tide)",
        "Attribute_1_year" : 1936,
        "shared_interaction" : "designedJacketFor",
        "name" : "Richard Kennedy (designedJacketFor) Adventures in Investing by \"Securitas\" (Financial Editor of Time and Tide)",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 4328,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4077",
        "source" : "3056",
        "target" : "4072",
        "shared_name" : "Richard Kennedy (designedJacketFor) Progressive Schools Their Principles and Practice",
        "Attribute_1_year" : 1934,
        "shared_interaction" : "designedJacketFor",
        "name" : "Richard Kennedy (designedJacketFor) Progressive Schools Their Principles and Practice",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 4077,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4064",
        "source" : "3056",
        "target" : "4059",
        "shared_name" : "Richard Kennedy (designedJacketFor) An African Speaks for His People",
        "Attribute_1_year" : 1934,
        "shared_interaction" : "designedJacketFor",
        "name" : "Richard Kennedy (designedJacketFor) An African Speaks for His People",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 4064,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3945",
        "source" : "3056",
        "target" : "3940",
        "shared_name" : "Richard Kennedy (designedJacketFor) New Country Prose and Poetry by the authors of New Signatures",
        "Attribute_1_year" : 1933,
        "shared_interaction" : "designedJacketFor",
        "name" : "Richard Kennedy (designedJacketFor) New Country Prose and Poetry by the authors of New Signatures",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 3945,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3927",
        "source" : "3056",
        "target" : "3922",
        "shared_name" : "Richard Kennedy (designedJacketFor) The Myth of Governor Eyre",
        "Attribute_1_year" : 1933,
        "shared_interaction" : "designedJacketFor",
        "name" : "Richard Kennedy (designedJacketFor) The Myth of Governor Eyre",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 3927,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3907",
        "source" : "3056",
        "target" : "3897",
        "shared_name" : "Richard Kennedy (designedJacketFor) Financial Democracy",
        "Attribute_1_year" : 1933,
        "shared_interaction" : "designedJacketFor",
        "name" : "Richard Kennedy (designedJacketFor) Financial Democracy",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 3907,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3756",
        "source" : "3056",
        "target" : "3746",
        "shared_name" : "Richard Kennedy (designedJacketFor) India in Transition",
        "Attribute_1_year" : 1932,
        "shared_interaction" : "designedJacketFor",
        "name" : "Richard Kennedy (designedJacketFor) India in Transition",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 3756,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3733",
        "source" : "3056",
        "target" : "3728",
        "shared_name" : "Richard Kennedy (designedJacketFor) Public Schools Their Failure and Their Reform",
        "Attribute_1_year" : 1932,
        "shared_interaction" : "designedJacketFor",
        "name" : "Richard Kennedy (designedJacketFor) Public Schools Their Failure and Their Reform",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 3733,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3701",
        "source" : "3056",
        "target" : "3696",
        "shared_name" : "Richard Kennedy (designedJacketFor) Ten Letter-Writers",
        "Attribute_1_year" : 1932,
        "shared_interaction" : "designedJacketFor",
        "name" : "Richard Kennedy (designedJacketFor) Ten Letter-Writers",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 3701,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3683",
        "source" : "3056",
        "target" : "3678",
        "shared_name" : "Richard Kennedy (designedJacketFor) The Mugwumps and the Labour Party",
        "Attribute_1_year" : 1932,
        "shared_interaction" : "designedJacketFor",
        "name" : "Richard Kennedy (designedJacketFor) The Mugwumps and the Labour Party",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 3683,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3655",
        "source" : "3056",
        "target" : "3650",
        "shared_name" : "Richard Kennedy (designedJacketFor) The New Boer War",
        "Attribute_1_year" : 1932,
        "shared_interaction" : "designedJacketFor",
        "name" : "Richard Kennedy (designedJacketFor) The New Boer War",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 3655,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3639",
        "source" : "3056",
        "target" : "3634",
        "shared_name" : "Richard Kennedy (designedJacketFor) English Village Schools",
        "Attribute_1_year" : 1931,
        "shared_interaction" : "designedJacketFor",
        "name" : "Richard Kennedy (designedJacketFor) English Village Schools",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 3639,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3508",
        "source" : "3056",
        "target" : "3503",
        "shared_name" : "Richard Kennedy (designedJacketFor) The Sensitive One",
        "Attribute_1_year" : 1931,
        "shared_interaction" : "designedJacketFor",
        "name" : "Richard Kennedy (designedJacketFor) The Sensitive One",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 3508,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3500",
        "source" : "3056",
        "target" : "3495",
        "shared_name" : "Richard Kennedy (designedJacketFor) The Trap",
        "Attribute_1_year" : 1931,
        "shared_interaction" : "designedJacketFor",
        "name" : "Richard Kennedy (designedJacketFor) The Trap",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 3500,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3128",
        "source" : "3056",
        "target" : "3123",
        "shared_name" : "Richard Kennedy (designedJacketFor) Dawn on Mont Blanc Being Incidentally the tragedy of an aggravating young man",
        "Attribute_1_year" : 1930,
        "shared_interaction" : "designedJacketFor",
        "name" : "Richard Kennedy (designedJacketFor) Dawn on Mont Blanc Being Incidentally the tragedy of an aggravating young man",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 3128,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3058",
        "source" : "3056",
        "target" : "3051",
        "shared_name" : "Richard Kennedy (designedJacketFor) Death of My Aunt",
        "Attribute_1_year" : 1929,
        "shared_interaction" : "designedJacketFor",
        "name" : "Richard Kennedy (designedJacketFor) Death of My Aunt",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 3058,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3048",
        "source" : "3046",
        "target" : "3041",
        "shared_name" : "Thos. J. Hewitt (authorOf) An Outline of Musical History Vol. I From the Earliest Times to Handel and Bach; Vol. II From C. P. E. Bach to Modern Music by Ralph Hill",
        "Attribute_1_year" : 1929,
        "shared_interaction" : "authorOf",
        "name" : "Thos. J. Hewitt (authorOf) An Outline of Musical History Vol. I From the Earliest Times to Handel and Bach; Vol. II From C. P. E. Bach to Modern Music by Ralph Hill",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 3048,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3043",
        "source" : "3039",
        "target" : "3041",
        "shared_name" : "Ralph Hill (authorOf) An Outline of Musical History Vol. I From the Earliest Times to Handel and Bach; Vol. II From C. P. E. Bach to Modern Music by Ralph Hill",
        "Attribute_1_year" : 1929,
        "shared_interaction" : "authorOf",
        "name" : "Ralph Hill (authorOf) An Outline of Musical History Vol. I From the Earliest Times to Handel and Bach; Vol. II From C. P. E. Bach to Modern Music by Ralph Hill",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 3043,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3036",
        "source" : "3034",
        "target" : "3024",
        "shared_name" : "Rabindranath Tagore (wroteForewordFor) A Woman of India. Being the Life of Saroj Nalini (Founder of the Women's Institute Movement in India)",
        "Attribute_1_year" : 1929,
        "shared_interaction" : "wroteForewordFor",
        "name" : "Rabindranath Tagore (wroteForewordFor) A Woman of India. Being the Life of Saroj Nalini (Founder of the Women's Institute Movement in India)",
        "interaction" : "wroteForewordFor",
        "certainty" : "definite",
        "SUID" : 3036,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3031",
        "source" : "3029",
        "target" : "3024",
        "shared_name" : "C. F. Andrews (wroteIntroductionFor) A Woman of India. Being the Life of Saroj Nalini (Founder of the Women's Institute Movement in India)",
        "Attribute_1_year" : 1929,
        "shared_interaction" : "wroteIntroductionFor",
        "name" : "C. F. Andrews (wroteIntroductionFor) A Woman of India. Being the Life of Saroj Nalini (Founder of the Women's Institute Movement in India)",
        "interaction" : "wroteIntroductionFor",
        "certainty" : "definite",
        "SUID" : 3031,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3026",
        "source" : "3022",
        "target" : "3024",
        "shared_name" : "G. S. Dutt (authorOf) A Woman of India. Being the Life of Saroj Nalini (Founder of the Women's Institute Movement in India)",
        "Attribute_1_year" : 1929,
        "shared_interaction" : "authorOf",
        "name" : "G. S. Dutt (authorOf) A Woman of India. Being the Life of Saroj Nalini (Founder of the Women's Institute Movement in India)",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 3026,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3141",
        "source" : "3014",
        "target" : "3139",
        "shared_name" : "John Davenport (editorOf) Cambridge Poetry 1930",
        "Attribute_1_year" : 1930,
        "shared_interaction" : "editorOf",
        "Column2" : "Another with many contributors. List them all?",
        "name" : "John Davenport (editorOf) Cambridge Poetry 1930",
        "interaction" : "editorOf",
        "certainty" : "definite",
        "SUID" : 3141,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3016",
        "source" : "3014",
        "target" : "3004",
        "shared_name" : "John Davenport (editorOf) Cambridge Poetry 1929",
        "Attribute_1_year" : 1929,
        "shared_interaction" : "editorOf",
        "name" : "John Davenport (editorOf) Cambridge Poetry 1929",
        "interaction" : "editorOf",
        "certainty" : "definite",
        "SUID" : 3016,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3011",
        "source" : "3009",
        "target" : "3004",
        "shared_name" : "Basil Wright (editorOf) Cambridge Poetry 1929",
        "Attribute_1_year" : 1929,
        "shared_interaction" : "editorOf",
        "name" : "Basil Wright (editorOf) Cambridge Poetry 1929",
        "interaction" : "editorOf",
        "certainty" : "definite",
        "SUID" : 3011,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3006",
        "source" : "3002",
        "target" : "3004",
        "shared_name" : "Christopher Salmarshe (editorOf) Cambridge Poetry 1929",
        "Attribute_1_year" : 1929,
        "shared_interaction" : "editorOf",
        "name" : "Christopher Salmarshe (editorOf) Cambridge Poetry 1929",
        "interaction" : "editorOf",
        "certainty" : "definite",
        "SUID" : 3006,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2999",
        "source" : "2997",
        "target" : "2987",
        "shared_name" : "Georg Kolbe (wroteNoteFor) Undying Faces",
        "Attribute_1_year" : 1929,
        "shared_interaction" : "wroteNoteFor",
        "name" : "Georg Kolbe (wroteNoteFor) Undying Faces",
        "interaction" : "wroteNoteFor",
        "certainty" : "definite",
        "SUID" : 2999,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2994",
        "source" : "2992",
        "target" : "2987",
        "shared_name" : "Margaret M. Green (translatedFor) Undying Faces",
        "Attribute_1_year" : 1929,
        "shared_interaction" : "translatedFor",
        "name" : "Margaret M. Green (translatedFor) Undying Faces",
        "interaction" : "translatedFor",
        "certainty" : "definite",
        "SUID" : 2994,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2989",
        "source" : "2985",
        "target" : "2987",
        "shared_name" : "Ernst Benkard (authorOf) Undying Faces",
        "Attribute_1_year" : 1929,
        "shared_interaction" : "authorOf",
        "name" : "Ernst Benkard (authorOf) Undying Faces",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 2989,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2982",
        "source" : "2980",
        "target" : "2975",
        "shared_name" : "Worthing Art Gallery (providedArtworkFor) Orlando A Biography",
        "Attribute_1_year" : 1928,
        "shared_interaction" : "providedArtworkFor",
        "name" : "Worthing Art Gallery (providedArtworkFor) Orlando A Biography",
        "interaction" : "providedArtworkFor",
        "certainty" : "definite",
        "SUID" : 2982,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4681",
        "source" : "2951",
        "target" : "4676",
        "shared_name" : "E. McKnight Kauffer (designedJacketFor) The Man Below",
        "Attribute_1_year" : 1939,
        "shared_interaction" : "designedJacketFor",
        "name" : "E. McKnight Kauffer (designedJacketFor) The Man Below",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 4681,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4437",
        "source" : "2951",
        "target" : "4432",
        "shared_name" : "E. McKnight Kauffer (designedJacketFor) Smoky Crusade",
        "Attribute_1_year" : 1937,
        "shared_interaction" : "designedJacketFor",
        "name" : "E. McKnight Kauffer (designedJacketFor) Smoky Crusade",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 4437,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4245",
        "source" : "2951",
        "target" : "4240",
        "shared_name" : "E. McKnight Kauffer (designedJacketFor) Quack, Quack!",
        "Attribute_1_year" : 1935,
        "shared_interaction" : "designedJacketFor",
        "name" : "E. McKnight Kauffer (designedJacketFor) Quack, Quack!",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 4245,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3179",
        "source" : "2951",
        "target" : "3174",
        "shared_name" : "E. McKnight Kauffer (designedJacketFor) History as Direction",
        "Attribute_1_year" : 1930,
        "shared_interaction" : "designedJacketFor",
        "name" : "E. McKnight Kauffer (designedJacketFor) History as Direction",
        "interaction" : "designedJacketFor",
        "certainty" : "likely",
        "SUID" : 3179,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2953",
        "source" : "2951",
        "target" : "2941",
        "shared_name" : "E. McKnight Kauffer (designedJacketFor) Words and Poetry",
        "Attribute_1_year" : 1928,
        "shared_interaction" : "designedJacketFor",
        "name" : "E. McKnight Kauffer (designedJacketFor) Words and Poetry",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 2953,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2948",
        "source" : "2946",
        "target" : "2941",
        "shared_name" : "Lytton Strachey (wroteIntroductionFor) Words and Poetry",
        "Attribute_1_year" : 1928,
        "shared_interaction" : "wroteIntroductionFor",
        "name" : "Lytton Strachey (wroteIntroductionFor) Words and Poetry",
        "interaction" : "wroteIntroductionFor",
        "certainty" : "definite",
        "SUID" : 2948,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2943",
        "source" : "2939",
        "target" : "2941",
        "shared_name" : "George W. H. Rylands (authorOf) Words and Poetry",
        "Attribute_1_year" : 1928,
        "shared_interaction" : "authorOf",
        "name" : "George W. H. Rylands (authorOf) Words and Poetry",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 2943,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3665",
        "source" : "2934",
        "target" : "3660",
        "shared_name" : "W. D. Robson-Scott (translatedFor) Psycho-analysis of the Neuroses",
        "Attribute_1_year" : 1932,
        "shared_interaction" : "translatedFor",
        "name" : "W. D. Robson-Scott (translatedFor) Psycho-analysis of the Neuroses",
        "interaction" : "translatedFor",
        "certainty" : "definite",
        "SUID" : 3665,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2936",
        "source" : "2934",
        "target" : "2929",
        "shared_name" : "W. D. Robson-Scott (translatedFor) The Future of an Illusion",
        "Attribute_1_year" : 1928,
        "shared_interaction" : "translatedFor",
        "name" : "W. D. Robson-Scott (translatedFor) The Future of an Illusion",
        "interaction" : "translatedFor",
        "certainty" : "definite",
        "SUID" : 2936,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4774",
        "source" : "2924",
        "target" : "4769",
        "shared_name" : "H. N. Brailsford (wrotePrefaceFor) England's Pleasant Land A Pageant Play",
        "Attribute_1_year" : 1940,
        "shared_interaction" : "wrotePrefaceFor",
        "name" : "H. N. Brailsford (wrotePrefaceFor) England's Pleasant Land A Pageant Play",
        "interaction" : "wrotePrefaceFor",
        "certainty" : "definite",
        "SUID" : 4774,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2926",
        "source" : "2924",
        "target" : "2919",
        "shared_name" : "H. N. Brailsford (wrotePrefaceFor) The Triumphant Machine (A Study of Machine Civilization)",
        "Attribute_1_year" : 1928,
        "shared_interaction" : "wrotePrefaceFor",
        "name" : "H. N. Brailsford (wrotePrefaceFor) The Triumphant Machine (A Study of Machine Civilization)",
        "interaction" : "wrotePrefaceFor",
        "certainty" : "definite",
        "SUID" : 2926,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4434",
        "source" : "2917",
        "target" : "4432",
        "shared_name" : "R. M. Fox (authorOf) Smoky Crusade",
        "Attribute_1_year" : 1937,
        "shared_interaction" : "authorOf",
        "name" : "R. M. Fox (authorOf) Smoky Crusade",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4434,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3156",
        "source" : "2917",
        "target" : "3154",
        "shared_name" : "R. M. Fox (authorOf) Drifting Men",
        "Attribute_1_year" : 1930,
        "shared_interaction" : "authorOf",
        "name" : "R. M. Fox (authorOf) Drifting Men",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 3156,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2921",
        "source" : "2917",
        "target" : "2919",
        "shared_name" : "R. M. Fox (authorOf) The Triumphant Machine (A Study of Machine Civilization)",
        "Attribute_1_year" : 1928,
        "shared_interaction" : "authorOf",
        "name" : "R. M. Fox (authorOf) The Triumphant Machine (A Study of Machine Civilization)",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 2921,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2914",
        "source" : "2912",
        "target" : "2907",
        "shared_name" : "D. Maclise (illustratedFor) L. E. L. A Mystery of the Thirties",
        "Attribute_1_year" : 1928,
        "shared_interaction" : "illustratedFor",
        "name" : "D. Maclise (illustratedFor) L. E. L. A Mystery of the Thirties",
        "interaction" : "illustratedFor",
        "certainty" : "definite",
        "SUID" : 2914,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2909",
        "source" : "2905",
        "target" : "2907",
        "shared_name" : "D. E. Enfield (authorOf) L. E. L. A Mystery of the Thirties",
        "Attribute_1_year" : 1928,
        "shared_interaction" : "authorOf",
        "name" : "D. E. Enfield (authorOf) L. E. L. A Mystery of the Thirties",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 2909,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2882",
        "source" : "2878",
        "target" : "2880",
        "shared_name" : "Laura Riding (authorOf) Voltaire A Biographical Fantasy",
        "Attribute_1_year" : 1927,
        "shared_interaction" : "authorOf",
        "name" : "Laura Riding (authorOf) Voltaire A Biographical Fantasy",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 2882,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2875",
        "source" : "2873",
        "target" : "2834",
        "shared_name" : "Jeffrey E. Jeffrey (coauthorWith) Books and the Public",
        "Attribute_1_year" : 1927,
        "shared_interaction" : "coauthorWith",
        "name" : "Jeffrey E. Jeffrey (coauthorWith) Books and the Public",
        "interaction" : "coauthorWith",
        "certainty" : "definite",
        "SUID" : 2875,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2870",
        "source" : "2868",
        "target" : "2834",
        "shared_name" : "Charles Young (coauthorWith) Books and the Public",
        "Attribute_1_year" : 1927,
        "shared_interaction" : "coauthorWith",
        "name" : "Charles Young (coauthorWith) Books and the Public",
        "interaction" : "coauthorWith",
        "certainty" : "definite",
        "SUID" : 2870,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2865",
        "source" : "2863",
        "target" : "2834",
        "shared_name" : "Henry B. Saxton (coauthorWith) Books and the Public",
        "Attribute_1_year" : 1927,
        "shared_interaction" : "coauthorWith",
        "name" : "Henry B. Saxton (coauthorWith) Books and the Public",
        "interaction" : "coauthorWith",
        "certainty" : "definite",
        "SUID" : 2865,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2854",
        "source" : "2852",
        "target" : "2834",
        "shared_name" : "Basil Blackwell (coauthorWith) Books and the Public",
        "Attribute_1_year" : 1927,
        "shared_interaction" : "coauthorWith",
        "name" : "Basil Blackwell (coauthorWith) Books and the Public",
        "interaction" : "coauthorWith",
        "certainty" : "definite",
        "SUID" : 2854,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2849",
        "source" : "2847",
        "target" : "2834",
        "shared_name" : "Michael Sadleir (coauthorWith) Books and the Public",
        "Attribute_1_year" : 1927,
        "shared_interaction" : "coauthorWith",
        "name" : "Michael Sadleir (coauthorWith) Books and the Public",
        "interaction" : "coauthorWith",
        "certainty" : "definite",
        "SUID" : 2849,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2844",
        "source" : "2842",
        "target" : "2834",
        "shared_name" : "Stanley Unwin (coauthorWith) Books and the Public",
        "Attribute_1_year" : 1927,
        "shared_interaction" : "coauthorWith",
        "name" : "Stanley Unwin (coauthorWith) Books and the Public",
        "interaction" : "coauthorWith",
        "certainty" : "definite",
        "SUID" : 2844,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2836",
        "source" : "2832",
        "target" : "2834",
        "shared_name" : "The Editor of THE NATION (editorOf) Books and the Public",
        "Attribute_1_year" : 1927,
        "shared_interaction" : "editorOf",
        "name" : "The Editor of THE NATION (editorOf) Books and the Public",
        "interaction" : "editorOf",
        "certainty" : "definite",
        "SUID" : 2836,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4549",
        "source" : "2819",
        "target" : "4533",
        "shared_name" : "Charles Mauron (contributedTo) Julian Bell Essays, Poems and Letters",
        "Attribute_1_year" : 1938,
        "shared_interaction" : "contributedTo",
        "name" : "Charles Mauron (contributedTo) Julian Bell Essays, Poems and Letters",
        "interaction" : "contributedTo",
        "certainty" : "definite",
        "SUID" : 4549,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4198",
        "source" : "2819",
        "target" : "4196",
        "shared_name" : "Charles Mauron (authorOf) Aesthetics and Psychology",
        "Attribute_1_year" : 1935,
        "shared_interaction" : "authorOf",
        "name" : "Charles Mauron (authorOf) Aesthetics and Psychology",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4198,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2823",
        "source" : "2819",
        "target" : "2821",
        "shared_name" : "Charles Mauron (authorOf) The Nature of Beauty in Art and Literature",
        "Attribute_1_year" : 1927,
        "shared_interaction" : "authorOf",
        "name" : "Charles Mauron (authorOf) The Nature of Beauty in Art and Literature",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 2823,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2816",
        "source" : "2814",
        "target" : "2801",
        "shared_name" : "[St. Win] (providedPaperFor) Interpretations",
        "Attribute_1_year" : 1927,
        "shared_interaction" : "providedPaperFor",
        "name" : "[St. Win] (providedPaperFor) Interpretations",
        "interaction" : "providedPaperFor",
        "certainty" : "speculative",
        "SUID" : 2816,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2812",
        "source" : "2799",
        "target" : "441",
        "shared_name" : "Lydia Lopokova (spouseOf) John Maynard Keynes",
        "shared_interaction" : "spouseOf",
        "name" : "Lydia Lopokova (spouseOf) John Maynard Keynes",
        "interaction" : "spouseOf",
        "SUID" : 2812,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2809",
        "source" : "2799",
        "target" : "2801",
        "shared_name" : "Lydia Lopokova (printedFor) Interpretations",
        "Attribute_1_year" : 1927,
        "shared_interaction" : "printedFor",
        "name" : "Lydia Lopokova (printedFor) Interpretations",
        "interaction" : "printedFor",
        "certainty" : "definite",
        "SUID" : 2809,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2806",
        "source" : "2799",
        "target" : "2801",
        "shared_name" : "Lydia Lopokova (printedFor) Interpretations",
        "Attribute_1_year" : 1927,
        "shared_interaction" : "printedFor",
        "name" : "Lydia Lopokova (printedFor) Interpretations",
        "interaction" : "printedFor",
        "certainty" : "definite",
        "SUID" : 2806,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2803",
        "source" : "2799",
        "target" : "2801",
        "shared_name" : "Lydia Lopokova (authorOf) Interpretations",
        "Attribute_1_year" : 1927,
        "shared_interaction" : "authorOf",
        "name" : "Lydia Lopokova (authorOf) Interpretations",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 2803,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4538",
        "source" : "2794",
        "target" : "4533",
        "shared_name" : "Quentin Bell (editorOf) Julian Bell Essays, Poems and Letters",
        "Attribute_1_year" : 1938,
        "shared_interaction" : "editorOf",
        "name" : "Quentin Bell (editorOf) Julian Bell Essays, Poems and Letters",
        "interaction" : "editorOf",
        "certainty" : "definite",
        "SUID" : 4538,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2796",
        "source" : "2794",
        "target" : "2789",
        "shared_name" : "Quentin Bell (designedJacketFor) Mr. Baldin Explains and other Dream Interviews",
        "Attribute_1_year" : 1927,
        "shared_interaction" : "designedJacketFor",
        "name" : "Quentin Bell (designedJacketFor) Mr. Baldin Explains and other Dream Interviews",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 2796,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2860",
        "source" : "2787",
        "target" : "2834",
        "shared_name" : "Peter Ibbetson (coauthorWith) Books and the Public",
        "Attribute_1_year" : 1927,
        "shared_interaction" : "coauthorWith",
        "name" : "Peter Ibbetson (coauthorWith) Books and the Public",
        "interaction" : "coauthorWith",
        "certainty" : "definite",
        "SUID" : 2860,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2791",
        "source" : "2787",
        "target" : "2789",
        "shared_name" : "Peter Ibbetson (authorOf) Mr. Baldin Explains and other Dream Interviews",
        "Attribute_1_year" : 1927,
        "shared_interaction" : "authorOf",
        "name" : "Peter Ibbetson (authorOf) Mr. Baldin Explains and other Dream Interviews",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 2791,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2768",
        "source" : "2766",
        "target" : "2736",
        "shared_name" : "W. T. Symons (coauthorWith) Coal A Challenge to the National Conscience",
        "Attribute_1_year" : 1927,
        "shared_interaction" : "coauthorWith",
        "name" : "W. T. Symons (coauthorWith) Coal A Challenge to the National Conscience",
        "interaction" : "coauthorWith",
        "certainty" : "definite",
        "SUID" : 2768,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2763",
        "source" : "2761",
        "target" : "2736",
        "shared_name" : "Egerton Swann (coauthorWith) Coal A Challenge to the National Conscience",
        "Attribute_1_year" : 1927,
        "shared_interaction" : "coauthorWith",
        "name" : "Egerton Swann (coauthorWith) Coal A Challenge to the National Conscience",
        "interaction" : "coauthorWith",
        "certainty" : "definite",
        "SUID" : 2763,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2758",
        "source" : "2756",
        "target" : "2736",
        "shared_name" : "Maurice B. Recckitt (coauthorWith) Coal A Challenge to the National Conscience",
        "Attribute_1_year" : 1927,
        "shared_interaction" : "coauthorWith",
        "name" : "Maurice B. Recckitt (coauthorWith) Coal A Challenge to the National Conscience",
        "interaction" : "coauthorWith",
        "certainty" : "definite",
        "SUID" : 2758,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2753",
        "source" : "2751",
        "target" : "2736",
        "shared_name" : "Alan Porter (coauthorWith) Coal A Challenge to the National Conscience",
        "Attribute_1_year" : 1927,
        "shared_interaction" : "coauthorWith",
        "name" : "Alan Porter (coauthorWith) Coal A Challenge to the National Conscience",
        "interaction" : "coauthorWith",
        "certainty" : "definite",
        "SUID" : 2753,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2748",
        "source" : "2746",
        "target" : "2736",
        "shared_name" : "Albert Newsome (coauthorWith) Coal A Challenge to the National Conscience",
        "Attribute_1_year" : 1927,
        "shared_interaction" : "coauthorWith",
        "name" : "Albert Newsome (coauthorWith) Coal A Challenge to the National Conscience",
        "interaction" : "coauthorWith",
        "certainty" : "definite",
        "SUID" : 2748,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2743",
        "source" : "2741",
        "target" : "2736",
        "shared_name" : "Philippe Mairet (coauthorWith) Coal A Challenge to the National Conscience",
        "Attribute_1_year" : 1927,
        "shared_interaction" : "coauthorWith",
        "name" : "Philippe Mairet (coauthorWith) Coal A Challenge to the National Conscience",
        "interaction" : "coauthorWith",
        "certainty" : "definite",
        "SUID" : 2743,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2738",
        "source" : "2734",
        "target" : "2736",
        "shared_name" : "V. A. Dermant (authorOf) Coal A Challenge to the National Conscience",
        "Attribute_1_year" : 1927,
        "shared_interaction" : "authorOf",
        "name" : "V. A. Dermant (authorOf) Coal A Challenge to the National Conscience",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 2738,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4263",
        "source" : "2729",
        "target" : "4258",
        "shared_name" : "Alix Strachey (translatedFor) Inhibitions, Symptoms and Anxiety",
        "Attribute_1_year" : 1936,
        "shared_interaction" : "translatedFor",
        "name" : "Alix Strachey (translatedFor) Inhibitions, Symptoms and Anxiety",
        "interaction" : "translatedFor",
        "certainty" : "definite",
        "SUID" : 4263,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2731",
        "source" : "2729",
        "target" : "2716",
        "shared_name" : "Alix Strachey (translatedFor) Selected Papers of Karl Abraham",
        "Attribute_1_year" : 1927,
        "shared_interaction" : "translatedFor",
        "name" : "Alix Strachey (translatedFor) Selected Papers of Karl Abraham",
        "interaction" : "translatedFor",
        "certainty" : "definite",
        "SUID" : 2731,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3529",
        "source" : "2724",
        "target" : "3521",
        "shared_name" : "Douglas Bryan (translatedFor) Ritual Psycho-Analytic Studies",
        "Attribute_1_year" : 1931,
        "shared_interaction" : "translatedFor",
        "name" : "Douglas Bryan (translatedFor) Ritual Psycho-Analytic Studies",
        "interaction" : "translatedFor",
        "certainty" : "definite",
        "SUID" : 3529,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2726",
        "source" : "2724",
        "target" : "2716",
        "shared_name" : "Douglas Bryan (translatedFor) Selected Papers of Karl Abraham",
        "Attribute_1_year" : 1927,
        "shared_interaction" : "translatedFor",
        "name" : "Douglas Bryan (translatedFor) Selected Papers of Karl Abraham",
        "interaction" : "translatedFor",
        "certainty" : "definite",
        "SUID" : 2726,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2718",
        "source" : "2714",
        "target" : "2716",
        "shared_name" : "Karl Abraham (authorOf) Selected Papers of Karl Abraham",
        "Attribute_1_year" : 1927,
        "shared_interaction" : "authorOf",
        "name" : "Karl Abraham (authorOf) Selected Papers of Karl Abraham",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 2718,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2711",
        "source" : "2709",
        "target" : "2704",
        "shared_name" : "Theodore Besterman (editorOf) Youth: The Magazine of the British Federation of Youth",
        "Attribute_1_year" : 1926,
        "shared_interaction" : "editorOf",
        "Column2" : "** Could not include. Published the first six issues between March and AUgust 1926, then publication was taken over by the British Federation of Youth who continued publishing through October 1929.",
        "name" : "Theodore Besterman (editorOf) Youth: The Magazine of the British Federation of Youth",
        "interaction" : "editorOf",
        "certainty" : "definite",
        "SUID" : 2711,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2706",
        "source" : "2702",
        "target" : "2704",
        "shared_name" : "Youth (authorOf) Youth: The Magazine of the British Federation of Youth",
        "Attribute_1_year" : 1926,
        "shared_interaction" : "authorOf",
        "name" : "Youth (authorOf) Youth: The Magazine of the British Federation of Youth",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 2706,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2958",
        "source" : "2689",
        "target" : "2956",
        "shared_name" : "Stanley Snaith (authorOf) A Flying Scroll",
        "Attribute_1_year" : 1928,
        "shared_interaction" : "authorOf",
        "name" : "Stanley Snaith (authorOf) A Flying Scroll",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 2958,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2693",
        "source" : "2689",
        "target" : "2691",
        "shared_name" : "Stanley Snaith (authorOf) April Morning",
        "Attribute_1_year" : 1926,
        "shared_interaction" : "authorOf",
        "name" : "Stanley Snaith (authorOf) April Morning",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 2693,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2658",
        "source" : "2656",
        "target" : "2651",
        "shared_name" : "Jane Isabel Suttie (translatedFor) Further Contributions to the Theory and Technique of Psycho-Analysis",
        "Attribute_1_year" : 1926,
        "shared_interaction" : "translatedFor",
        "name" : "Jane Isabel Suttie (translatedFor) Further Contributions to the Theory and Technique of Psycho-Analysis",
        "interaction" : "translatedFor",
        "certainty" : "definite",
        "SUID" : 2658,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2653",
        "source" : "2649",
        "target" : "2651",
        "shared_name" : "Sandor Ferenczi (authorOf) Further Contributions to the Theory and Technique of Psycho-Analysis",
        "Attribute_1_year" : 1926,
        "shared_interaction" : "authorOf",
        "name" : "Sandor Ferenczi (authorOf) Further Contributions to the Theory and Technique of Psycho-Analysis",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 2653,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2643",
        "source" : "2639",
        "target" : "2641",
        "shared_name" : "Mary Stella Edwards (authorOf) Time and Change Poems",
        "Attribute_1_year" : 1926,
        "shared_interaction" : "authorOf",
        "name" : "Mary Stella Edwards (authorOf) Time and Change Poems",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 2643,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2630",
        "source" : "2626",
        "target" : "2628",
        "shared_name" : "Julia Margaret Cameron (authorOf) Victorian Photographs of Famous Men & Fair Women",
        "Attribute_1_year" : 1926,
        "shared_interaction" : "authorOf",
        "name" : "Julia Margaret Cameron (authorOf) Victorian Photographs of Famous Men & Fair Women",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 2630,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2623",
        "source" : "2621",
        "target" : "2616",
        "shared_name" : "Bishop Gore (wroteForewordFor) The People of Ararat",
        "Attribute_1_year" : 1926,
        "shared_interaction" : "wroteForewordFor",
        "name" : "Bishop Gore (wroteForewordFor) The People of Ararat",
        "interaction" : "wroteForewordFor",
        "certainty" : "definite",
        "SUID" : 2623,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2618",
        "source" : "2614",
        "target" : "2616",
        "shared_name" : "Joseph Burtt (authorOf) The People of Ararat",
        "Attribute_1_year" : 1926,
        "shared_interaction" : "authorOf",
        "name" : "Joseph Burtt (authorOf) The People of Ararat",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 2618,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2611",
        "source" : "2609",
        "target" : "2604",
        "shared_name" : "G. K. Chesterton (wrotePrefaceFor) Chosen Poems",
        "Attribute_1_year" : 1926,
        "shared_interaction" : "wrotePrefaceFor",
        "name" : "G. K. Chesterton (wrotePrefaceFor) Chosen Poems",
        "interaction" : "wrotePrefaceFor",
        "certainty" : "definite",
        "SUID" : 2611,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2606",
        "source" : "2602",
        "target" : "2604",
        "shared_name" : "Douglas Ainslie (authorOf) Chosen Poems",
        "Attribute_1_year" : 1926,
        "shared_interaction" : "authorOf",
        "name" : "Douglas Ainslie (authorOf) Chosen Poems",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 2606,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2539",
        "source" : "2537",
        "target" : "2529",
        "shared_name" : "A. W. Devis (illustratedFor) Original Letters from India (1779-1815)",
        "Attribute_1_year" : 1925,
        "shared_interaction" : "illustratedFor",
        "name" : "A. W. Devis (illustratedFor) Original Letters from India (1779-1815)",
        "interaction" : "illustratedFor",
        "certainty" : "definite",
        "SUID" : 2539,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2531",
        "source" : "2527",
        "target" : "2529",
        "shared_name" : "Mrs. Eliza Fay (authorOf) Original Letters from India (1779-1815)",
        "Attribute_1_year" : 1925,
        "shared_interaction" : "authorOf",
        "name" : "Mrs. Eliza Fay (authorOf) Original Letters from India (1779-1815)",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 2531,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2518",
        "source" : "2516",
        "target" : "2505",
        "shared_name" : "Eugene McCown (designedCoverFor) Parallax",
        "Attribute_1_year" : 1925,
        "shared_interaction" : "designedCoverFor",
        "name" : "Eugene McCown (designedCoverFor) Parallax",
        "interaction" : "designedCoverFor",
        "certainty" : "definite",
        "SUID" : 2518,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2507",
        "source" : "2503",
        "target" : "2505",
        "shared_name" : "Nancy Cunard (authorOf) Parallax",
        "Attribute_1_year" : 1925,
        "shared_interaction" : "authorOf",
        "name" : "Nancy Cunard (authorOf) Parallax",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 2507,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2497",
        "source" : "2493",
        "target" : "2495",
        "shared_name" : "Ferenc Békássy (authorOf) Adriatica and Other Poems",
        "Attribute_1_year" : 1925,
        "shared_interaction" : "authorOf",
        "name" : "Ferenc Békássy (authorOf) Adriatica and Other Poems",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 2497,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2481",
        "source" : "2477",
        "target" : "2479",
        "shared_name" : "John Crowe Ransom (authorOf) Grace After Meat",
        "Attribute_1_year" : 1924,
        "shared_interaction" : "authorOf",
        "name" : "John Crowe Ransom (authorOf) Grace After Meat",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 2481,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2646",
        "source" : "2472",
        "target" : "2641",
        "shared_name" : "Professor Gilbert Murray (wrotePrefaceFor) Time and Change Poems",
        "Attribute_1_year" : 1926,
        "shared_interaction" : "wrotePrefaceFor",
        "name" : "Professor Gilbert Murray (wrotePrefaceFor) Time and Change Poems",
        "interaction" : "wrotePrefaceFor",
        "certainty" : "definite",
        "SUID" : 2646,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2474",
        "source" : "2472",
        "target" : "2467",
        "shared_name" : "Professor Gilbert Murray (wroteIntroductionFor) Kenya",
        "Attribute_1_year" : 1924,
        "shared_interaction" : "wroteIntroductionFor",
        "name" : "Professor Gilbert Murray (wroteIntroductionFor) Kenya",
        "interaction" : "wroteIntroductionFor",
        "certainty" : "definite",
        "SUID" : 2474,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4480",
        "source" : "2454",
        "target" : "4478",
        "shared_name" : "Joan Riviere (authorOf) Love, Hate and Reparation Two Lectures",
        "Attribute_1_year" : 1937,
        "shared_interaction" : "authorOf",
        "name" : "Joan Riviere (authorOf) Love, Hate and Reparation Two Lectures",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4480,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3169",
        "source" : "2454",
        "target" : "3164",
        "shared_name" : "Joan Riviere (translatedFor) Civilization and its Discontents",
        "Attribute_1_year" : 1930,
        "shared_interaction" : "translatedFor",
        "name" : "Joan Riviere (translatedFor) Civilization and its Discontents",
        "interaction" : "translatedFor",
        "certainty" : "definite",
        "SUID" : 3169,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2776",
        "source" : "2454",
        "target" : "2771",
        "shared_name" : "Joan Riviere (translatedFor) The Ego and the Id",
        "Attribute_1_year" : 1927,
        "shared_interaction" : "translatedFor",
        "name" : "Joan Riviere (translatedFor) The Ego and the Id",
        "interaction" : "translatedFor",
        "certainty" : "definite",
        "SUID" : 2776,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2456",
        "source" : "2454",
        "target" : "2449",
        "shared_name" : "Joan Riviere (translatedFor) Collected Papers",
        "Attribute_1_year" : 1924,
        "shared_interaction" : "translatedFor",
        "name" : "Joan Riviere (translatedFor) Collected Papers",
        "interaction" : "translatedFor",
        "certainty" : "definite",
        "SUID" : 2456,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2435",
        "source" : "2433",
        "target" : "2416",
        "shared_name" : "Prince D. S. Mirsky (wrotePrefaceFor) The Life of the Archpriest Avvakum by Himself",
        "Attribute_1_year" : 1924,
        "shared_interaction" : "wrotePrefaceFor",
        "name" : "Prince D. S. Mirsky (wrotePrefaceFor) The Life of the Archpriest Avvakum by Himself",
        "interaction" : "wrotePrefaceFor",
        "certainty" : "definite",
        "SUID" : 2435,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2423",
        "source" : "2421",
        "target" : "2416",
        "shared_name" : "Jane Harrison (translatedFor) The Life of the Archpriest Avvakum by Himself",
        "Attribute_1_year" : 1924,
        "shared_interaction" : "translatedFor",
        "Column2" : "**NOTE in 1924 the Press moved to Tavistock Square",
        "name" : "Jane Harrison (translatedFor) The Life of the Archpriest Avvakum by Himself",
        "interaction" : "translatedFor",
        "certainty" : "definite",
        "SUID" : 2423,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2418",
        "source" : "2414",
        "target" : "2416",
        "shared_name" : "Avvakum (authorOf) The Life of the Archpriest Avvakum by Himself",
        "Attribute_1_year" : 1924,
        "shared_interaction" : "authorOf",
        "name" : "Avvakum (authorOf) The Life of the Archpriest Avvakum by Himself",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 2418,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4376",
        "source" : "2401",
        "target" : "4374",
        "shared_name" : "Leo Tolstoy (authorOf) On Socialism",
        "Attribute_1_year" : 1936,
        "shared_interaction" : "authorOf",
        "name" : "Leo Tolstoy (authorOf) On Socialism",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4376,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2405",
        "source" : "2401",
        "target" : "2403",
        "shared_name" : "Leo Tolstoy (authorOf) Tolstoi's Love Letters with a study of the autobiographical elements in Tolstoi's work, by Paul Biryukov",
        "Attribute_1_year" : 1923,
        "shared_interaction" : "authorOf",
        "name" : "Leo Tolstoy (authorOf) Tolstoi's Love Letters with a study of the autobiographical elements in Tolstoi's work, by Paul Biryukov",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 2405,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2398",
        "source" : "2396",
        "target" : "2391",
        "shared_name" : "Harold Wright (editorOf) Letters",
        "Attribute_1_year" : 1923,
        "shared_interaction" : "editorOf",
        "name" : "Harold Wright (editorOf) Letters",
        "interaction" : "editorOf",
        "certainty" : "definite",
        "SUID" : 2398,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2393",
        "source" : "2389",
        "target" : "2391",
        "shared_name" : "Stephen Reynolds (authorOf) Letters",
        "Attribute_1_year" : 1923,
        "shared_interaction" : "authorOf",
        "name" : "Stephen Reynolds (authorOf) Letters",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 2393,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2373",
        "source" : "2363",
        "target" : "441",
        "shared_name" : "Gordon Hannington Luce (brieflyRomanticallyInvolvedWith) John Maynard Keynes",
        "shared_interaction" : "brieflyRomanticallyInvolvedWith",
        "name" : "Gordon Hannington Luce (brieflyRomanticallyInvolvedWith) John Maynard Keynes",
        "interaction" : "brieflyRomanticallyInvolvedWith",
        "SUID" : 2373,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2367",
        "source" : "2363",
        "target" : "2365",
        "shared_name" : "Gordon Hannington Luce (authorOf) Poems_9",
        "Attribute_1_year" : 1923,
        "shared_interaction" : "authorOf",
        "name" : "Gordon Hannington Luce (authorOf) Poems_9",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 2367,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2354",
        "source" : "2350",
        "target" : "2352",
        "shared_name" : "Ena Limebeer (authorOf) To a Proud Phantom",
        "Attribute_1_year" : 1923,
        "shared_interaction" : "authorOf",
        "name" : "Ena Limebeer (authorOf) To a Proud Phantom",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 2354,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2464",
        "source" : "2339",
        "target" : "2459",
        "shared_name" : "William Nicholson (designedCoverFor) Mock Beggar Hill",
        "Attribute_1_year" : 1924,
        "shared_interaction" : "designedCoverFor",
        "name" : "William Nicholson (designedCoverFor) Mock Beggar Hill",
        "interaction" : "designedCoverFor",
        "certainty" : "definite",
        "SUID" : 2464,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2341",
        "source" : "2339",
        "target" : "2334",
        "shared_name" : "William Nicholson (designedCoverFor) The Feather Bed",
        "Attribute_1_year" : 1923,
        "shared_interaction" : "designedCoverFor",
        "name" : "William Nicholson (designedCoverFor) The Feather Bed",
        "interaction" : "designedCoverFor",
        "certainty" : "definite",
        "SUID" : 2341,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2325",
        "source" : "2321",
        "target" : "2323",
        "shared_name" : "A. B. Goldenveizer (authorOf) Talks with Tolstoi",
        "Attribute_1_year" : 1923,
        "shared_interaction" : "authorOf",
        "name" : "A. B. Goldenveizer (authorOf) Talks with Tolstoi",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 2325,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2304",
        "source" : "2302",
        "target" : "2291",
        "shared_name" : "C. P. Cavafy (providedPoemFor) Pharos and Pharillon",
        "Attribute_1_year" : 1923,
        "shared_interaction" : "providedPoemFor",
        "name" : "C. P. Cavafy (providedPoemFor) Pharos and Pharillon",
        "interaction" : "providedPoemFor",
        "certainty" : "definite",
        "SUID" : 2304,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3818",
        "source" : "2269",
        "target" : "3813",
        "shared_name" : "Duncan Grant (designedJacketFor) Cheerful Weather for the Wedding",
        "Attribute_1_year" : 1932,
        "shared_interaction" : "designedJacketFor",
        "name" : "Duncan Grant (designedJacketFor) Cheerful Weather for the Wedding",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 3818,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2370",
        "source" : "2269",
        "target" : "2365",
        "shared_name" : "Duncan Grant (illustratedFor) Poems_9",
        "Attribute_1_year" : 1923,
        "shared_interaction" : "illustratedFor",
        "name" : "Duncan Grant (illustratedFor) Poems_9",
        "interaction" : "illustratedFor",
        "certainty" : "definite",
        "SUID" : 2370,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2318",
        "source" : "2269",
        "target" : "2269",
        "shared_name" : "Duncan Grant (designedJacketFor) Duncan Grant",
        "Attribute_1_year" : 1923,
        "shared_interaction" : "designedJacketFor",
        "name" : "Duncan Grant (designedJacketFor) Duncan Grant",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 2318,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2271",
        "source" : "2269",
        "target" : "2258",
        "shared_name" : "Duncan Grant (illustratedFor) The Legend of Monte Della Sibilla or Le Paradis de la Reine Sibille",
        "Attribute_1_year" : 1923,
        "shared_interaction" : "illustratedFor",
        "name" : "Duncan Grant (illustratedFor) The Legend of Monte Della Sibilla or Le Paradis de la Reine Sibille",
        "interaction" : "illustratedFor",
        "certainty" : "speculative",
        "SUID" : 2271,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2241",
        "source" : "2239",
        "target" : "2234",
        "shared_name" : "Vasilii Spiridonov (wrotePrefaceFor) The Autobiography of Countess Sophie Tolstoi",
        "Attribute_1_year" : 1922,
        "shared_interaction" : "wrotePrefaceFor",
        "name" : "Vasilii Spiridonov (wrotePrefaceFor) The Autobiography of Countess Sophie Tolstoi",
        "interaction" : "wrotePrefaceFor",
        "certainty" : "definite",
        "SUID" : 2241,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2236",
        "source" : "2232",
        "target" : "2234",
        "shared_name" : "Countess Sophie Tolstoi (authorOf) The Autobiography of Countess Sophie Tolstoi",
        "Attribute_1_year" : 1922,
        "shared_interaction" : "authorOf",
        "name" : "Countess Sophie Tolstoi (authorOf) The Autobiography of Countess Sophie Tolstoi",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 2236,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2230",
        "source" : "2217",
        "target" : "183",
        "shared_name" : "Fredegond Shove (cousinOf) Virginia Woolf",
        "shared_interaction" : "cousinOf",
        "name" : "Fredegond Shove (cousinOf) Virginia Woolf",
        "interaction" : "cousinOf",
        "SUID" : 2230,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2221",
        "source" : "2217",
        "target" : "2219",
        "shared_name" : "Fredegond Shove (authorOf) Daybreak",
        "Attribute_1_year" : 1922,
        "shared_interaction" : "authorOf",
        "name" : "Fredegond Shove (authorOf) Daybreak",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 2221,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2666",
        "source" : "2204",
        "target" : "2664",
        "shared_name" : "Ruth Manning-Sanders (authorOf) Martha Wish-You-Ill",
        "Attribute_1_year" : 1926,
        "shared_interaction" : "authorOf",
        "name" : "Ruth Manning-Sanders (authorOf) Martha Wish-You-Ill",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 2666,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2208",
        "source" : "2204",
        "target" : "2206",
        "shared_name" : "Ruth Manning-Sanders (authorOf) Karn",
        "Attribute_1_year" : 1922,
        "shared_interaction" : "authorOf",
        "name" : "Ruth Manning-Sanders (authorOf) Karn",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 2208,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4185",
        "source" : "2199",
        "target" : "4180",
        "shared_name" : "James Strachey (translatedFor) An Autobiographical Study",
        "Attribute_1_year" : 1935,
        "shared_interaction" : "translatedFor",
        "name" : "James Strachey (translatedFor) An Autobiographical Study",
        "interaction" : "translatedFor",
        "certainty" : "definite",
        "SUID" : 4185,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2201",
        "source" : "2199",
        "target" : "2194",
        "shared_name" : "James Strachey (translatedFor) Group Psychology and the Analysis of the Ego",
        "Attribute_1_year" : 1922,
        "shared_interaction" : "translatedFor",
        "name" : "James Strachey (translatedFor) Group Psychology and the Analysis of the Ego",
        "interaction" : "translatedFor",
        "certainty" : "definite",
        "SUID" : 2201,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2191",
        "source" : "2189",
        "target" : "2184",
        "shared_name" : "C. J. M. Hubback (translatedFor) Beyond the Pleasure Principle",
        "Attribute_1_year" : 1922,
        "shared_interaction" : "translatedFor",
        "name" : "C. J. M. Hubback (translatedFor) Beyond the Pleasure Principle",
        "interaction" : "translatedFor",
        "certainty" : "definite",
        "SUID" : 2191,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4650",
        "source" : "2182",
        "target" : "4648",
        "shared_name" : "Sigmund Freud (authorOf) Moses and Monotheism",
        "Attribute_1_year" : 1939,
        "shared_interaction" : "authorOf",
        "name" : "Sigmund Freud (authorOf) Moses and Monotheism",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4650,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4642",
        "source" : "2182",
        "target" : "4640",
        "shared_name" : "Sigmund Freud (authorOf) Civilization, War and Death Selections from Three Works",
        "Attribute_1_year" : 1939,
        "shared_interaction" : "authorOf",
        "name" : "Sigmund Freud (authorOf) Civilization, War and Death Selections from Three Works",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4642,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4456",
        "source" : "2182",
        "target" : "4454",
        "shared_name" : "Sigmund Freud (authorOf) A General Selection from the Works of Sigmund Freud",
        "Attribute_1_year" : 1937,
        "shared_interaction" : "authorOf",
        "name" : "Sigmund Freud (authorOf) A General Selection from the Works of Sigmund Freud",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4456,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4260",
        "source" : "2182",
        "target" : "4258",
        "shared_name" : "Sigmund Freud (authorOf) Inhibitions, Symptoms and Anxiety",
        "Attribute_1_year" : 1936,
        "shared_interaction" : "authorOf",
        "name" : "Sigmund Freud (authorOf) Inhibitions, Symptoms and Anxiety",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4260,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4182",
        "source" : "2182",
        "target" : "4180",
        "shared_name" : "Sigmund Freud (authorOf) An Autobiographical Study",
        "Attribute_1_year" : 1935,
        "shared_interaction" : "authorOf",
        "name" : "Sigmund Freud (authorOf) An Autobiographical Study",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4182,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3862",
        "source" : "2182",
        "target" : "3860",
        "shared_name" : "Sigmund Freud (authorOf) New Introductory Lectures on Psycho-Analysis",
        "Attribute_1_year" : 1933,
        "shared_interaction" : "authorOf",
        "name" : "Sigmund Freud (authorOf) New Introductory Lectures on Psycho-Analysis",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 3862,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3526",
        "source" : "2182",
        "target" : "3521",
        "shared_name" : "Sigmund Freud (wrotePrefaceFor) Ritual Psycho-Analytic Studies",
        "Attribute_1_year" : 1931,
        "shared_interaction" : "wrotePrefaceFor",
        "name" : "Sigmund Freud (wrotePrefaceFor) Ritual Psycho-Analytic Studies",
        "interaction" : "wrotePrefaceFor",
        "certainty" : "definite",
        "SUID" : 3526,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3166",
        "source" : "2182",
        "target" : "3164",
        "shared_name" : "Sigmund Freud (authorOf) Civilization and its Discontents",
        "Attribute_1_year" : 1930,
        "shared_interaction" : "authorOf",
        "name" : "Sigmund Freud (authorOf) Civilization and its Discontents",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 3166,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2931",
        "source" : "2182",
        "target" : "2929",
        "shared_name" : "Sigmund Freud (authorOf) The Future of an Illusion",
        "Attribute_1_year" : 1928,
        "shared_interaction" : "authorOf",
        "name" : "Sigmund Freud (authorOf) The Future of an Illusion",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 2931,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2773",
        "source" : "2182",
        "target" : "2771",
        "shared_name" : "Sigmund Freud (authorOf) The Ego and the Id",
        "Attribute_1_year" : 1927,
        "shared_interaction" : "authorOf",
        "name" : "Sigmund Freud (authorOf) The Ego and the Id",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 2773,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2451",
        "source" : "2182",
        "target" : "2449",
        "shared_name" : "Sigmund Freud (authorOf) Collected Papers",
        "Attribute_1_year" : 1924,
        "shared_interaction" : "authorOf",
        "name" : "Sigmund Freud (authorOf) Collected Papers",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 2451,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2196",
        "source" : "2182",
        "target" : "2194",
        "shared_name" : "Sigmund Freud (authorOf) Group Psychology and the Analysis of the Ego",
        "Attribute_1_year" : 1922,
        "shared_interaction" : "authorOf",
        "name" : "Sigmund Freud (authorOf) Group Psychology and the Analysis of the Ego",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 2196,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2186",
        "source" : "2182",
        "target" : "2184",
        "shared_name" : "Sigmund Freud (authorOf) Beyond the Pleasure Principle",
        "Attribute_1_year" : 1922,
        "shared_interaction" : "authorOf",
        "name" : "Sigmund Freud (authorOf) Beyond the Pleasure Principle",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 2186,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2173",
        "source" : "2169",
        "target" : "2171",
        "shared_name" : "F. M. Dostoevsky (authorOf) Stavrogin's Confession and The Plan of the Life of a Great Sinner",
        "Attribute_1_year" : 1922,
        "shared_interaction" : "authorOf",
        "name" : "F. M. Dostoevsky (authorOf) Stavrogin's Confession and The Plan of the Life of a Great Sinner",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 2173,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2166",
        "source" : "2164",
        "target" : "2148",
        "shared_name" : "unnamed person in Czechoslovakia (providedCoverPapersFor) The Gentleman from San Francisco and other stories",
        "Attribute_1_year" : 1922,
        "shared_interaction" : "providedCoverPapersFor",
        "name" : "unnamed person in Czechoslovakia (providedCoverPapersFor) The Gentleman from San Francisco and other stories",
        "interaction" : "providedCoverPapersFor",
        "certainty" : "definite",
        "SUID" : 2166,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3316",
        "source" : "2159",
        "target" : "3244",
        "shared_name" : "D. H. Lawrence (contributedTo) A Broadcast Anthology of Modern Poetry",
        "Attribute_1_year" : 1930,
        "shared_interaction" : "contributedTo",
        "name" : "D. H. Lawrence (contributedTo) A Broadcast Anthology of Modern Poetry",
        "interaction" : "contributedTo",
        "certainty" : "definite",
        "SUID" : 3316,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2161",
        "source" : "2159",
        "target" : "2148",
        "shared_name" : "D. H. Lawrence (translatedFor) The Gentleman from San Francisco and other stories",
        "Attribute_1_year" : 1922,
        "shared_interaction" : "translatedFor",
        "name" : "D. H. Lawrence (translatedFor) The Gentleman from San Francisco and other stories",
        "interaction" : "translatedFor",
        "certainty" : "speculative",
        "SUID" : 2161,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4169",
        "source" : "2146",
        "target" : "4167",
        "shared_name" : "Ivan Bunin (authorOf) Grammar of Love",
        "Attribute_1_year" : 1935,
        "shared_interaction" : "authorOf",
        "name" : "Ivan Bunin (authorOf) Grammar of Love",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4169,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3842",
        "source" : "2146",
        "target" : "3840",
        "shared_name" : "Ivan Bunin (authorOf) The Well of Days",
        "Attribute_1_year" : 1933,
        "shared_interaction" : "authorOf",
        "name" : "Ivan Bunin (authorOf) The Well of Days",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 3842,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2150",
        "source" : "2146",
        "target" : "2148",
        "shared_name" : "Ivan Bunin (authorOf) The Gentleman from San Francisco and other stories",
        "Attribute_1_year" : 1922,
        "shared_interaction" : "authorOf",
        "name" : "Ivan Bunin (authorOf) The Gentleman from San Francisco and other stories",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 2150,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2143",
        "source" : "2141",
        "target" : "2131",
        "shared_name" : "K. Walter (translatedFor) The Dark",
        "Attribute_1_year" : 1922,
        "shared_interaction" : "translatedFor",
        "name" : "K. Walter (translatedFor) The Dark",
        "interaction" : "translatedFor",
        "certainty" : "definite",
        "SUID" : 2143,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2138",
        "source" : "2136",
        "target" : "2131",
        "shared_name" : "L. A. Magnus (translatedFor) The Dark",
        "Attribute_1_year" : 1922,
        "shared_interaction" : "translatedFor",
        "name" : "L. A. Magnus (translatedFor) The Dark",
        "interaction" : "translatedFor",
        "certainty" : "definite",
        "SUID" : 2138,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2133",
        "source" : "2129",
        "target" : "2131",
        "shared_name" : "Leonid Andreev (authorOf) The Dark",
        "Attribute_1_year" : 1922,
        "shared_interaction" : "authorOf",
        "name" : "Leonid Andreev (authorOf) The Dark",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 2133,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3335",
        "source" : "2093",
        "target" : "3244",
        "shared_name" : "Siegfried Sassoon (contributedTo) A Broadcast Anthology of Modern Poetry",
        "Attribute_1_year" : 1930,
        "shared_interaction" : "contributedTo",
        "name" : "Siegfried Sassoon (contributedTo) A Broadcast Anthology of Modern Poetry",
        "interaction" : "contributedTo",
        "certainty" : "definite",
        "SUID" : 3335,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2095",
        "source" : "2080",
        "target" : "2093",
        "shared_name" : "Frank Prewett (friendOf) Siegfried Sassoon",
        "shared_interaction" : "friendOf",
        "name" : "Frank Prewett (friendOf) Siegfried Sassoon",
        "interaction" : "friendOf",
        "SUID" : 2095,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2084",
        "source" : "2080",
        "target" : "2082",
        "shared_name" : "Frank Prewett (authorOf) Poems_8",
        "Attribute_1_year" : 1921,
        "shared_interaction" : "authorOf",
        "name" : "Frank Prewett (authorOf) Poems_8",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 2084,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2066",
        "source" : "2064",
        "target" : "2050",
        "shared_name" : "a little man in Holborn (providedCoverPapersFor) Twelve Original Woodcuts",
        "Attribute_1_year" : 1921,
        "shared_interaction" : "providedCoverPapersFor",
        "name" : "a little man in Holborn (providedCoverPapersFor) Twelve Original Woodcuts",
        "interaction" : "providedCoverPapersFor",
        "certainty" : "likely",
        "SUID" : 2066,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4039",
        "source" : "2020",
        "target" : "4031",
        "shared_name" : "S. S. Koteliansky (translatedFor) Reminiscences of Tolstoy, Chekhov and Andrew",
        "Attribute_1_year" : 1934,
        "shared_interaction" : "translatedFor",
        "name" : "S. S. Koteliansky (translatedFor) Reminiscences of Tolstoy, Chekhov and Andrew",
        "interaction" : "translatedFor",
        "certainty" : "definite",
        "SUID" : 4039,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2408",
        "source" : "2020",
        "target" : "2403",
        "shared_name" : "S. S. Koteliansky (translatedFor) Tolstoi's Love Letters with a study of the autobiographical elements in Tolstoi's work, by Paul Biryukov",
        "Attribute_1_year" : 1923,
        "shared_interaction" : "translatedFor",
        "name" : "S. S. Koteliansky (translatedFor) Tolstoi's Love Letters with a study of the autobiographical elements in Tolstoi's work, by Paul Biryukov",
        "interaction" : "translatedFor",
        "certainty" : "definite",
        "SUID" : 2408,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2328",
        "source" : "2020",
        "target" : "2323",
        "shared_name" : "S. S. Koteliansky (translatedFor) Talks with Tolstoi",
        "Attribute_1_year" : 1923,
        "shared_interaction" : "translatedFor",
        "name" : "S. S. Koteliansky (translatedFor) Talks with Tolstoi",
        "interaction" : "translatedFor",
        "certainty" : "definite",
        "SUID" : 2328,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2244",
        "source" : "2020",
        "target" : "2234",
        "shared_name" : "S. S. Koteliansky (translatedFor) The Autobiography of Countess Sophie Tolstoi",
        "Attribute_1_year" : 1922,
        "shared_interaction" : "translatedFor",
        "name" : "S. S. Koteliansky (translatedFor) The Autobiography of Countess Sophie Tolstoi",
        "interaction" : "translatedFor",
        "certainty" : "definite",
        "SUID" : 2244,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2176",
        "source" : "2020",
        "target" : "2171",
        "shared_name" : "S. S. Koteliansky (translatedFor) Stavrogin's Confession and The Plan of the Life of a Great Sinner",
        "Attribute_1_year" : 1922,
        "shared_interaction" : "translatedFor",
        "name" : "S. S. Koteliansky (translatedFor) Stavrogin's Confession and The Plan of the Life of a Great Sinner",
        "interaction" : "translatedFor",
        "certainty" : "definite",
        "SUID" : 2176,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2153",
        "source" : "2020",
        "target" : "2148",
        "shared_name" : "S. S. Koteliansky (translatedFor) The Gentleman from San Francisco and other stories",
        "Attribute_1_year" : 1922,
        "shared_interaction" : "translatedFor",
        "name" : "S. S. Koteliansky (translatedFor) The Gentleman from San Francisco and other stories",
        "interaction" : "translatedFor",
        "certainty" : "definite",
        "SUID" : 2153,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2074",
        "source" : "2020",
        "target" : "2069",
        "shared_name" : "S. S. Koteliansky (translatedFor) The Note-Books of Anton Tchekhov Together with Reminiscences of Tchekhov",
        "Attribute_1_year" : 1921,
        "shared_interaction" : "translatedFor",
        "name" : "S. S. Koteliansky (translatedFor) The Note-Books of Anton Tchekhov Together with Reminiscences of Tchekhov",
        "interaction" : "translatedFor",
        "certainty" : "definite",
        "SUID" : 2074,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2022",
        "source" : "2020",
        "target" : "2015",
        "shared_name" : "S. S. Koteliansky (translatedFor) Reminiscences of Leo Nicolayevitch Tolstoi",
        "Attribute_1_year" : 1920,
        "shared_interaction" : "translatedFor",
        "name" : "S. S. Koteliansky (translatedFor) Reminiscences of Leo Nicolayevitch Tolstoi",
        "interaction" : "translatedFor",
        "certainty" : "definite",
        "SUID" : 2022,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4033",
        "source" : "2013",
        "target" : "4031",
        "shared_name" : "Maxim Gorky (authorOf) Reminiscences of Tolstoy, Chekhov and Andrew",
        "Attribute_1_year" : 1934,
        "shared_interaction" : "authorOf",
        "name" : "Maxim Gorky (authorOf) Reminiscences of Tolstoy, Chekhov and Andrew",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4033,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2071",
        "source" : "2013",
        "target" : "2069",
        "shared_name" : "Maxim Gorky (authorOf) The Note-Books of Anton Tchekhov Together with Reminiscences of Tchekhov",
        "Attribute_1_year" : 1921,
        "shared_interaction" : "authorOf",
        "name" : "Maxim Gorky (authorOf) The Note-Books of Anton Tchekhov Together with Reminiscences of Tchekhov",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 2071,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2017",
        "source" : "2013",
        "target" : "2015",
        "shared_name" : "Maxim Gorky (authorOf) Reminiscences of Leo Nicolayevitch Tolstoi",
        "Attribute_1_year" : 1920,
        "shared_interaction" : "authorOf",
        "name" : "Maxim Gorky (authorOf) Reminiscences of Leo Nicolayevitch Tolstoi",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 2017,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1999",
        "source" : "1995",
        "target" : "1997",
        "shared_name" : "Laurie Lee (authorOf) The Sun My Monument",
        "Attribute_1_year" : 1944,
        "shared_interaction" : "authorOf",
        "name" : "Laurie Lee (authorOf) The Sun My Monument",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1999,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4302",
        "source" : "1978",
        "target" : "4300",
        "shared_name" : "Theodor Reik (authorOf) The Unknown Murderer",
        "Attribute_1_year" : 1936,
        "shared_interaction" : "authorOf",
        "name" : "Theodor Reik (authorOf) The Unknown Murderer",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4302,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3523",
        "source" : "1978",
        "target" : "3521",
        "shared_name" : "Theodor Reik (authorOf) Ritual Psycho-Analytic Studies",
        "Attribute_1_year" : 1931,
        "shared_interaction" : "authorOf",
        "name" : "Theodor Reik (authorOf) Ritual Psycho-Analytic Studies",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 3523,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1982",
        "source" : "1978",
        "target" : "1980",
        "shared_name" : "Theodor Reik (authorOf) From Thirty Years With Freud",
        "Attribute_1_year" : 1942,
        "shared_interaction" : "authorOf",
        "name" : "Theodor Reik (authorOf) From Thirty Years With Freud",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1982,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4464",
        "source" : "1966",
        "target" : "4462",
        "shared_name" : "Dr. I. Harris (authorOf) Diet and High Blood Pressure",
        "Attribute_1_year" : 1937,
        "shared_interaction" : "authorOf",
        "name" : "Dr. I. Harris (authorOf) Diet and High Blood Pressure",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4464,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1970",
        "source" : "1966",
        "target" : "1968",
        "shared_name" : "Dr. I. Harris (authorOf) The Calcium Bread Scandal",
        "Attribute_1_year" : 1942,
        "shared_interaction" : "authorOf",
        "name" : "Dr. I. Harris (authorOf) The Calcium Bread Scandal",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1970,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1992",
        "source" : "1959",
        "target" : "1990",
        "shared_name" : "Roy Fuller (authorOf) A Lost Season",
        "Attribute_1_year" : 1944,
        "shared_interaction" : "authorOf",
        "name" : "Roy Fuller (authorOf) A Lost Season",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1992,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1963",
        "source" : "1959",
        "target" : "1961",
        "shared_name" : "Roy Fuller (authorOf) The Middle of a War",
        "Attribute_1_year" : 1942,
        "shared_interaction" : "authorOf",
        "name" : "Roy Fuller (authorOf) The Middle of a War",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1963,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2004",
        "source" : "1947",
        "target" : "2002",
        "shared_name" : "Terence Tiller (authorOf) The Inward Animal",
        "Attribute_1_year" : 1944,
        "shared_interaction" : "authorOf",
        "name" : "Terence Tiller (authorOf) The Inward Animal",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 2004,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1951",
        "source" : "1947",
        "target" : "1949",
        "shared_name" : "Terence Tiller (authorOf) Poems_6",
        "Attribute_1_year" : 1941,
        "shared_interaction" : "authorOf",
        "name" : "Terence Tiller (authorOf) Poems_6",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1951,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1934",
        "source" : "1930",
        "target" : "1932",
        "shared_name" : "A. W. Madsen (editorOf) Why the German Republic Fell and other studies of the causes and consequences of economic inequality",
        "Attribute_1_year" : 1941,
        "shared_interaction" : "editorOf",
        "name" : "A. W. Madsen (editorOf) Why the German Republic Fell and other studies of the causes and consequences of economic inequality",
        "interaction" : "editorOf",
        "certainty" : "definite",
        "SUID" : 1934,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "5031",
        "source" : "1908",
        "target" : "5029",
        "shared_name" : "Henry Green (authorOf) Back",
        "Attribute_1_year" : 1946,
        "shared_interaction" : "authorOf",
        "name" : "Henry Green (authorOf) Back",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 5031,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "5006",
        "source" : "1908",
        "target" : "5004",
        "shared_name" : "Henry Green (authorOf) Loving",
        "Attribute_1_year" : 1945,
        "shared_interaction" : "authorOf",
        "name" : "Henry Green (authorOf) Loving",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 5006,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4891",
        "source" : "1908",
        "target" : "4889",
        "shared_name" : "Henry Green (authorOf) Caught",
        "Attribute_1_year" : 1943,
        "shared_interaction" : "authorOf",
        "name" : "Henry Green (authorOf) Caught",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4891,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4668",
        "source" : "1908",
        "target" : "4666",
        "shared_name" : "Henry Green (authorOf) Party Going",
        "Attribute_1_year" : 1939,
        "shared_interaction" : "authorOf",
        "name" : "Henry Green (authorOf) Party Going",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4668,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1912",
        "source" : "1908",
        "target" : "1910",
        "shared_name" : "Henry Green (authorOf) Pack My Bag: A Self-Portrait",
        "Attribute_1_year" : 1940,
        "shared_interaction" : "authorOf",
        "name" : "Henry Green (authorOf) Pack My Bag: A Self-Portrait",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1912,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1905",
        "source" : "1901",
        "target" : "1903",
        "shared_name" : "C. F. Fraser (authorOf) Control of Aliens in the British Commonwealth of Nations",
        "Attribute_1_year" : 1940,
        "shared_interaction" : "authorOf",
        "name" : "C. F. Fraser (authorOf) Control of Aliens in the British Commonwealth of Nations",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1905,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4886",
        "source" : "1884",
        "target" : "4876",
        "shared_name" : "Stephen Spender (translatedFor) Selected Poems of Lorca",
        "Attribute_1_year" : 1943,
        "shared_interaction" : "translatedFor",
        "name" : "Stephen Spender (translatedFor) Selected Poems of Lorca",
        "interaction" : "translatedFor",
        "certainty" : "definite",
        "SUID" : 4886,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4779",
        "source" : "1884",
        "target" : "4777",
        "shared_name" : "Stephen Spender (authorOf) The Backward Son",
        "Attribute_1_year" : 1940,
        "shared_interaction" : "authorOf",
        "name" : "Stephen Spender (authorOf) The Backward Son",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4779,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4740",
        "source" : "1884",
        "target" : "4732",
        "shared_name" : "Stephen Spender (wroteIntroductionFor) Duino Elegies",
        "Attribute_1_year" : 1939,
        "shared_interaction" : "wroteIntroductionFor",
        "name" : "Stephen Spender (wroteIntroductionFor) Duino Elegies",
        "interaction" : "wroteIntroductionFor",
        "certainty" : "definite",
        "SUID" : 4740,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3989",
        "source" : "1884",
        "target" : "3940",
        "shared_name" : "Stephen Spender (contributedTo) New Country Prose and Poetry by the authors of New Signatures",
        "Attribute_1_year" : 1933,
        "shared_interaction" : "contributedTo",
        "name" : "Stephen Spender (contributedTo) New Country Prose and Poetry by the authors of New Signatures",
        "interaction" : "contributedTo",
        "certainty" : "definite",
        "SUID" : 3989,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3793",
        "source" : "1884",
        "target" : "3761",
        "shared_name" : "Stephen Spender (contributedTo) New Signatures Poems by Several Hands",
        "Attribute_1_year" : 1932,
        "shared_interaction" : "contributedTo",
        "name" : "Stephen Spender (contributedTo) New Signatures Poems by Several Hands",
        "interaction" : "contributedTo",
        "certainty" : "definite",
        "SUID" : 3793,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1888",
        "source" : "1884",
        "target" : "1886",
        "shared_name" : "Stephen Spender (authorOf) The New Realism A Discussion",
        "Attribute_1_year" : 1939,
        "shared_interaction" : "authorOf",
        "name" : "Stephen Spender (authorOf) The New Realism A Discussion",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1888,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1881",
        "source" : "1877",
        "target" : "1879",
        "shared_name" : "Herbert Rosinski (authorOf) The German Army",
        "Attribute_1_year" : 1939,
        "shared_interaction" : "authorOf",
        "name" : "Herbert Rosinski (authorOf) The German Army",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1881,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1864",
        "source" : "1860",
        "target" : "1862",
        "shared_name" : "John Betjeman (authorOf) Antiquarian Paradise",
        "Attribute_1_year" : 1939,
        "shared_interaction" : "authorOf",
        "name" : "John Betjeman (authorOf) Antiquarian Paradise",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1864,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1857",
        "source" : "1853",
        "target" : "1855",
        "shared_name" : "Graham Bell (authorOf) The Artist and His Public",
        "Attribute_1_year" : 1939,
        "shared_interaction" : "authorOf",
        "name" : "Graham Bell (authorOf) The Artist and His Public",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1857,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1835",
        "source" : "1831",
        "target" : "1833",
        "shared_name" : "R. Palme Dutt (authorOf) The Political and Social Doctrine of Communism",
        "Attribute_1_year" : 1938,
        "shared_interaction" : "authorOf",
        "name" : "R. Palme Dutt (authorOf) The Political and Social Doctrine of Communism",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1835,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1828",
        "source" : "1824",
        "target" : "1826",
        "shared_name" : "Margaret Cole (authorOf) Books and the People",
        "Attribute_1_year" : 1938,
        "shared_interaction" : "authorOf",
        "name" : "Margaret Cole (authorOf) Books and the People",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1828,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1816",
        "source" : "1812",
        "target" : "1814",
        "shared_name" : "Libby Benedict (authorOf) The Refugees",
        "Attribute_1_year" : 1938,
        "shared_interaction" : "authorOf",
        "name" : "Libby Benedict (authorOf) The Refugees",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1816,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1809",
        "source" : "1805",
        "target" : "1807",
        "shared_name" : "Kenneth Allott (authorOf) Poems_5",
        "Attribute_1_year" : 1938,
        "shared_interaction" : "authorOf",
        "name" : "Kenneth Allott (authorOf) Poems_5",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1809,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1802",
        "source" : "1798",
        "target" : "1800",
        "shared_name" : "Marjorie Strachey (authorOf) Mazzini, Garibaldi & Cavour",
        "Attribute_1_year" : 1937,
        "shared_interaction" : "authorOf",
        "name" : "Marjorie Strachey (authorOf) Mazzini, Garibaldi & Cavour",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1802,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1795",
        "source" : "1791",
        "target" : "1793",
        "shared_name" : "Ella Freeman Sharpe (authorOf) Dream Analysis A Practical Handbook for Psycho-Analysts",
        "Attribute_1_year" : 1937,
        "shared_interaction" : "authorOf",
        "name" : "Ella Freeman Sharpe (authorOf) Dream Analysis A Practical Handbook for Psycho-Analysts",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1795,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4726",
        "source" : "1769",
        "target" : "4724",
        "shared_name" : "L. B. Pekin (authorOf) Coeducation in its Historical and Theoretical Setting",
        "Attribute_1_year" : 1939,
        "shared_interaction" : "authorOf",
        "name" : "L. B. Pekin (authorOf) Coeducation in its Historical and Theoretical Setting",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4726,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4074",
        "source" : "1769",
        "target" : "4072",
        "shared_name" : "L. B. Pekin (authorOf) Progressive Schools Their Principles and Practice",
        "Attribute_1_year" : 1934,
        "shared_interaction" : "authorOf",
        "name" : "L. B. Pekin (authorOf) Progressive Schools Their Principles and Practice",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4074,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3730",
        "source" : "1769",
        "target" : "3728",
        "shared_name" : "L. B. Pekin (authorOf) Public Schools Their Failure and Their Reform",
        "Attribute_1_year" : 1932,
        "shared_interaction" : "authorOf",
        "name" : "L. B. Pekin (authorOf) Public Schools Their Failure and Their Reform",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 3730,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1778",
        "source" : "1769",
        "target" : "1776",
        "shared_name" : "L. B. Pekin (authorOf) Darwin",
        "Attribute_1_year" : 1937,
        "shared_interaction" : "authorOf",
        "name" : "L. B. Pekin (authorOf) Darwin",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1778,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1773",
        "source" : "1769",
        "target" : "1771",
        "shared_name" : "L. B. Pekin (authorOf) The Military Training of Youth An enquiry into the aims and effects of the O.T.C.",
        "Attribute_1_year" : 1937,
        "shared_interaction" : "authorOf",
        "name" : "L. B. Pekin (authorOf) The Military Training of Youth An enquiry into the aims and effects of the O.T.C.",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1773,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1766",
        "source" : "1762",
        "target" : "1764",
        "shared_name" : "Adolf Lowe (authorOf) The Price of Liberty A German on Contemporary Britain",
        "Attribute_1_year" : 1937,
        "shared_interaction" : "authorOf",
        "name" : "Adolf Lowe (authorOf) The Price of Liberty A German on Contemporary Britain",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1766,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1759",
        "source" : "1755",
        "target" : "1757",
        "shared_name" : "Christopher Lee (authorOf) Poems_4",
        "Attribute_1_year" : 1937,
        "shared_interaction" : "authorOf",
        "name" : "Christopher Lee (authorOf) Poems_4",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1759,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1742",
        "source" : "1738",
        "target" : "1740",
        "shared_name" : "Irene Cooper Willis (authorOf) The Authorship of Wuthering Heights",
        "Attribute_1_year" : 1936,
        "shared_interaction" : "authorOf",
        "name" : "Irene Cooper Willis (authorOf) The Authorship of Wuthering Heights",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1742,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1730",
        "source" : "1726",
        "target" : "1728",
        "shared_name" : "Adrian Stephen (authorOf) The \"Dreadnought\" Hoax",
        "Attribute_1_year" : 1936,
        "shared_interaction" : "authorOf",
        "name" : "Adrian Stephen (authorOf) The \"Dreadnought\" Hoax",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1730,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1723",
        "source" : "1719",
        "target" : "1721",
        "shared_name" : "Sir Arthur Salter (authorOf) Economic Policies and Peace",
        "Attribute_1_year" : 1936,
        "shared_interaction" : "authorOf",
        "name" : "Sir Arthur Salter (authorOf) Economic Policies and Peace",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1723,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1716",
        "source" : "1712",
        "target" : "1714",
        "shared_name" : "A. Douglas Millard (authorOf) The Co-operative Movement To-Day and To-Morrow",
        "Attribute_1_year" : 1936,
        "shared_interaction" : "authorOf",
        "name" : "A. Douglas Millard (authorOf) The Co-operative Movement To-Day and To-Morrow",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1716,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1704",
        "source" : "1700",
        "target" : "1702",
        "shared_name" : "F. C. R. Douglas (authorOf) Land-Value Rating Theory and Practice",
        "Attribute_1_year" : 1936,
        "shared_interaction" : "authorOf",
        "name" : "F. C. R. Douglas (authorOf) Land-Value Rating Theory and Practice",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1704,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4535",
        "source" : "1688",
        "target" : "4533",
        "shared_name" : "Julian Bell (authorOf) Julian Bell Essays, Poems and Letters",
        "Attribute_1_year" : 1938,
        "shared_interaction" : "authorOf",
        "name" : "Julian Bell (authorOf) Julian Bell Essays, Poems and Letters",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4535,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4531",
        "source" : "1688",
        "target" : "189",
        "shared_name" : "Julian Bell (sonOf) Vanessa Bell",
        "shared_interaction" : "sonOf",
        "name" : "Julian Bell (sonOf) Vanessa Bell",
        "interaction" : "sonOf",
        "SUID" : 4531,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3771",
        "source" : "1688",
        "target" : "3761",
        "shared_name" : "Julian Bell (contributedTo) New Signatures Poems by Several Hands",
        "Attribute_1_year" : 1932,
        "shared_interaction" : "contributedTo",
        "name" : "Julian Bell (contributedTo) New Signatures Poems by Several Hands",
        "interaction" : "contributedTo",
        "certainty" : "definite",
        "SUID" : 3771,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1692",
        "source" : "1688",
        "target" : "1690",
        "shared_name" : "Julian Bell (authorOf) Work for the Winter and other poems",
        "Attribute_1_year" : 1936,
        "shared_interaction" : "authorOf",
        "name" : "Julian Bell (authorOf) Work for the Winter and other poems",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1692,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3652",
        "source" : "1681",
        "target" : "3650",
        "shared_name" : "Leonard Barnes (authorOf) The New Boer War",
        "Attribute_1_year" : 1932,
        "shared_interaction" : "authorOf",
        "name" : "Leonard Barnes (authorOf) The New Boer War",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 3652,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1685",
        "source" : "1681",
        "target" : "1683",
        "shared_name" : "Leonard Barnes (authorOf) The Future of Colonies",
        "Attribute_1_year" : 1936,
        "shared_interaction" : "authorOf",
        "name" : "Leonard Barnes (authorOf) The Future of Colonies",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1685,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1678",
        "source" : "1674",
        "target" : "1676",
        "shared_name" : "Frederick Verinder (authorOf) Land and Freedom",
        "Attribute_1_year" : 1935,
        "shared_interaction" : "authorOf",
        "name" : "Frederick Verinder (authorOf) Land and Freedom",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1678,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1845",
        "source" : "1657",
        "target" : "1843",
        "shared_name" : "Iris Origo (authorOf) Tribune of Rome A Biography of Cola di Rienzo",
        "Attribute_1_year" : 1938,
        "shared_interaction" : "authorOf",
        "name" : "Iris Origo (authorOf) Tribune of Rome A Biography of Cola di Rienzo",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1845,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1661",
        "source" : "1657",
        "target" : "1659",
        "shared_name" : "Iris Origo (authorOf) Allegra",
        "Attribute_1_year" : 1935,
        "shared_interaction" : "authorOf",
        "name" : "Iris Origo (authorOf) Allegra",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1661,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1654",
        "source" : "1650",
        "target" : "1652",
        "shared_name" : "W. R. Lester (authorOf) Poverty and Plenty: The True National Dividend",
        "Attribute_1_year" : 1935,
        "shared_interaction" : "authorOf",
        "name" : "W. R. Lester (authorOf) Poverty and Plenty: The True National Dividend",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1654,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1642",
        "source" : "1638",
        "target" : "1640",
        "shared_name" : "G. P. Gooch (authorOf) Politics and Morals",
        "Attribute_1_year" : 1935,
        "shared_interaction" : "authorOf",
        "name" : "G. P. Gooch (authorOf) Politics and Morals",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1642,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1752",
        "source" : "1631",
        "target" : "1750",
        "shared_name" : "E. M. Delafield (authorOf) Ladies and Gentlemen in Victorian Fiction",
        "Attribute_1_year" : 1937,
        "shared_interaction" : "authorOf",
        "name" : "E. M. Delafield (authorOf) Ladies and Gentlemen in Victorian Fiction",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1752,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1635",
        "source" : "1631",
        "target" : "1633",
        "shared_name" : "E. M. Delafield (editorOf) The Brontes Their Lives Recorded by their Contemporaries",
        "Attribute_1_year" : 1935,
        "shared_interaction" : "editorOf",
        "name" : "E. M. Delafield (editorOf) The Brontes Their Lives Recorded by their Contemporaries",
        "interaction" : "editorOf",
        "certainty" : "definite",
        "SUID" : 1635,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1613",
        "source" : "1609",
        "target" : "1611",
        "shared_name" : "Arthur Calder-Marshall (authorOf) Challenge to Schools A pamphlet on Public School Education",
        "Attribute_1_year" : 1935,
        "shared_interaction" : "authorOf",
        "name" : "Arthur Calder-Marshall (authorOf) Challenge to Schools A pamphlet on Public School Education",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1613,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1606",
        "source" : "1602",
        "target" : "1604",
        "shared_name" : "Mary Birkinshaw (authorOf) The Successful Teacher An Occupational Analysis based on an enquiry conducted among women teachers in secondary schools",
        "Attribute_1_year" : 1935,
        "shared_interaction" : "authorOf",
        "name" : "Mary Birkinshaw (authorOf) The Successful Teacher An Occupational Analysis based on an enquiry conducted among women teachers in secondary schools",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1606,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1599",
        "source" : "1595",
        "target" : "1597",
        "shared_name" : "S. H. Bailey (authorOf) Mr. Roosevelt's Experiments",
        "Attribute_1_year" : 1935,
        "shared_interaction" : "authorOf",
        "name" : "S. H. Bailey (authorOf) Mr. Roosevelt's Experiments",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1599,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1592",
        "source" : "1588",
        "target" : "1590",
        "shared_name" : "Y. Z. (authorOf) From Moscow to Samarkand",
        "Attribute_1_year" : 1934,
        "shared_interaction" : "authorOf",
        "name" : "Y. Z. (authorOf) From Moscow to Samarkand",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1592,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1585",
        "source" : "1581",
        "target" : "1583",
        "shared_name" : "W. F. Watson (authorOf) The Worker and Wage Incentives: The Bedaux and Other Systems",
        "Attribute_1_year" : 1934,
        "shared_interaction" : "authorOf",
        "name" : "W. F. Watson (authorOf) The Worker and Wage Incentives: The Bedaux and Other Systems",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1585,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1578",
        "source" : "1574",
        "target" : "1576",
        "shared_name" : "James Sutherland (authorOf) The Medium of Poetry",
        "Attribute_1_year" : 1934,
        "shared_interaction" : "authorOf",
        "name" : "James Sutherland (authorOf) The Medium of Poetry",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1578,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1571",
        "source" : "1567",
        "target" : "1569",
        "shared_name" : "A. L. Rowse (authorOf) The Question of the House of Lords",
        "Attribute_1_year" : 1934,
        "shared_interaction" : "authorOf",
        "name" : "A. L. Rowse (authorOf) The Question of the House of Lords",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1571,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1564",
        "source" : "1560",
        "target" : "1562",
        "shared_name" : "S. K. Ratcliffe (authorOf) The Roots of Violence",
        "Attribute_1_year" : 1934,
        "shared_interaction" : "authorOf",
        "name" : "S. K. Ratcliffe (authorOf) The Roots of Violence",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1564,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1666",
        "source" : "1553",
        "target" : "1664",
        "shared_name" : "Raymond Postgate (authorOf) What to do with the B.B.C.",
        "Attribute_1_year" : 1935,
        "shared_interaction" : "authorOf",
        "name" : "Raymond Postgate (authorOf) What to do with the B.B.C.",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1666,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1557",
        "source" : "1553",
        "target" : "1555",
        "shared_name" : "Raymond Postgate (authorOf) How to Make a Revolution",
        "Attribute_1_year" : 1934,
        "shared_interaction" : "authorOf",
        "name" : "Raymond Postgate (authorOf) How to Make a Revolution",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1557,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1540",
        "source" : "1536",
        "target" : "1538",
        "shared_name" : "W. G. Ballinger (authorOf) Race and Economics in South Africa",
        "Attribute_1_year" : 1934,
        "shared_interaction" : "authorOf",
        "name" : "W. G. Ballinger (authorOf) Race and Economics in South Africa",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1540,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1533",
        "source" : "1529",
        "target" : "1531",
        "shared_name" : "Rebecca West (authorOf) A Letter to a Grandfather",
        "Attribute_1_year" : 1933,
        "shared_interaction" : "authorOf",
        "name" : "Rebecca West (authorOf) A Letter to a Grandfather",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1533,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1526",
        "source" : "1522",
        "target" : "1524",
        "shared_name" : "Hebe Spaull (authorOf) How the World is Governed A Study in World Civics",
        "Attribute_1_year" : 1933,
        "shared_interaction" : "authorOf",
        "name" : "Hebe Spaull (authorOf) How the World is Governed A Study in World Civics",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1526,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1514",
        "source" : "1510",
        "target" : "1512",
        "shared_name" : "K. M. Panikkar (authorOf) Caste and Democracy",
        "Attribute_1_year" : 1933,
        "shared_interaction" : "authorOf",
        "name" : "K. M. Panikkar (authorOf) Caste and Democracy",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1514,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1507",
        "source" : "1503",
        "target" : "1505",
        "shared_name" : "C. L. R. James (authorOf) The Case for West-Indian Self Government",
        "Attribute_1_year" : 1933,
        "shared_interaction" : "authorOf",
        "name" : "C. L. R. James (authorOf) The Case for West-Indian Self Government",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1507,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1500",
        "source" : "1496",
        "target" : "1498",
        "shared_name" : "H. R. G. Greaves (authorOf) The Spanish Constitution",
        "Attribute_1_year" : 1933,
        "shared_interaction" : "authorOf",
        "name" : "H. R. G. Greaves (authorOf) The Spanish Constitution",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1500,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2440",
        "source" : "1484",
        "target" : "2438",
        "shared_name" : "Theodora Bosanquet (authorOf) Henry James at Work",
        "Attribute_1_year" : 1924,
        "shared_interaction" : "authorOf",
        "name" : "Theodora Bosanquet (authorOf) Henry James at Work",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 2440,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1488",
        "source" : "1484",
        "target" : "1486",
        "shared_name" : "Theodora Bosanquet (authorOf) Paul Valéry",
        "Attribute_1_year" : 1933,
        "shared_interaction" : "authorOf",
        "name" : "Theodora Bosanquet (authorOf) Paul Valéry",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1488,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1476",
        "source" : "1472",
        "target" : "1474",
        "shared_name" : "Hugh Walpole (authorOf) A Letter to a Modern Novelist",
        "Attribute_1_year" : 1932,
        "shared_interaction" : "authorOf",
        "name" : "Hugh Walpole (authorOf) A Letter to a Modern Novelist",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1476,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1464",
        "source" : "1460",
        "target" : "1462",
        "shared_name" : "L. A. G. Strong (authorOf) A Letter to W. B. Yeats",
        "Attribute_1_year" : 1932,
        "shared_interaction" : "authorOf",
        "name" : "L. A. G. Strong (authorOf) A Letter to W. B. Yeats",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1464,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1457",
        "source" : "1453",
        "target" : "1455",
        "shared_name" : "Sir Michael Sadler (authorOf) Modern Art and Revolution",
        "Attribute_1_year" : 1932,
        "shared_interaction" : "authorOf",
        "name" : "Sir Michael Sadler (authorOf) Modern Art and Revolution",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1457,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1450",
        "source" : "1446",
        "target" : "1448",
        "shared_name" : "Peter Quennell (authorOf) A Letter to Mrs. Virginia Woolf",
        "Attribute_1_year" : 1932,
        "shared_interaction" : "authorOf",
        "name" : "Peter Quennell (authorOf) A Letter to Mrs. Virginia Woolf",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1450,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1443",
        "source" : "1439",
        "target" : "1441",
        "shared_name" : "Arthur Ponsonby (authorOf) Disarmament A Discussion",
        "Attribute_1_year" : 1932,
        "shared_interaction" : "authorOf",
        "name" : "Arthur Ponsonby (authorOf) Disarmament A Discussion",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1443,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4848",
        "source" : "1427",
        "target" : "4846",
        "shared_name" : "Raymond Mortimer (authorOf) Channel Packet",
        "Attribute_1_year" : 1942,
        "shared_interaction" : "authorOf",
        "name" : "Raymond Mortimer (authorOf) Channel Packet",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4848,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1431",
        "source" : "1427",
        "target" : "1429",
        "shared_name" : "Raymond Mortimer (authorOf) The French Pictures A Letter to Harriet",
        "Attribute_1_year" : 1932,
        "shared_interaction" : "authorOf",
        "name" : "Raymond Mortimer (authorOf) The French Pictures A Letter to Harriet",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1431,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1424",
        "source" : "1420",
        "target" : "1422",
        "shared_name" : "C. M. Lloyd (authorOf) Russian Notes",
        "Attribute_1_year" : 1932,
        "shared_interaction" : "authorOf",
        "name" : "C. M. Lloyd (authorOf) Russian Notes",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1424,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1647",
        "source" : "1413",
        "target" : "1645",
        "shared_name" : "Harold J. Laski (authorOf) Law and Justice in Soviet Russia",
        "Attribute_1_year" : 1935,
        "shared_interaction" : "authorOf",
        "name" : "Harold J. Laski (authorOf) Law and Justice in Soviet Russia",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1647,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1417",
        "source" : "1413",
        "target" : "1415",
        "shared_name" : "Harold J. Laski (authorOf) The Crisis and the Constitution: 1931 and After",
        "Attribute_1_year" : 1932,
        "shared_interaction" : "authorOf",
        "name" : "Harold J. Laski (authorOf) The Crisis and the Constitution: 1931 and After",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1417,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4483",
        "source" : "1406",
        "target" : "4478",
        "shared_name" : "Melanie Klein (authorOf) Love, Hate and Reparation Two Lectures",
        "Attribute_1_year" : 1937,
        "shared_interaction" : "authorOf",
        "name" : "Melanie Klein (authorOf) Love, Hate and Reparation Two Lectures",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4483,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1410",
        "source" : "1406",
        "target" : "1408",
        "shared_name" : "Melanie Klein (authorOf) The Psycho-Analysis of Children",
        "Attribute_1_year" : 1932,
        "shared_interaction" : "authorOf",
        "name" : "Melanie Klein (authorOf) The Psycho-Analysis of Children",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1410,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1398",
        "source" : "1394",
        "target" : "1396",
        "shared_name" : "J. C. Hardwick (authorOf) A Letter to an Archbishop",
        "Attribute_1_year" : 1932,
        "shared_interaction" : "authorOf",
        "name" : "J. C. Hardwick (authorOf) A Letter to an Archbishop",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1398,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1391",
        "source" : "1387",
        "target" : "1389",
        "shared_name" : "Louis Golding (authorOf) A Letter to Adolf Hitler",
        "Attribute_1_year" : 1932,
        "shared_interaction" : "authorOf",
        "name" : "Louis Golding (authorOf) A Letter to Adolf Hitler",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1391,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1374",
        "source" : "1370",
        "target" : "1372",
        "shared_name" : "R. D. Charques (authorOf) Societ Education Some Aspects of Cultural Revolution",
        "Attribute_1_year" : 1932,
        "shared_interaction" : "authorOf",
        "name" : "R. D. Charques (authorOf) Societ Education Some Aspects of Cultural Revolution",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1374,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1367",
        "source" : "1363",
        "target" : "1365",
        "shared_name" : "Henry Noel Brailsford (authorOf) If We Want Peace",
        "Attribute_1_year" : 1932,
        "shared_interaction" : "authorOf",
        "name" : "Henry Noel Brailsford (authorOf) If We Want Peace",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1367,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3136",
        "source" : "1356",
        "target" : "3131",
        "shared_name" : "Francis Birrell (editorOf) The Art of Dying An Anthology",
        "Attribute_1_year" : 1930,
        "shared_interaction" : "editorOf",
        "name" : "Francis Birrell (editorOf) The Art of Dying An Anthology",
        "interaction" : "editorOf",
        "certainty" : "definite",
        "SUID" : 3136,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1360",
        "source" : "1356",
        "target" : "1358",
        "shared_name" : "Francis Birrell (authorOf) A Letter from a Black Sheep",
        "Attribute_1_year" : 1932,
        "shared_interaction" : "authorOf",
        "name" : "Francis Birrell (authorOf) A Letter from a Black Sheep",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1360,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1333",
        "source" : "1329",
        "target" : "1331",
        "shared_name" : "Jean Stewart (authorOf) Poetry in France and England",
        "Attribute_1_year" : 1931,
        "shared_interaction" : "authorOf",
        "name" : "Jean Stewart (authorOf) Poetry in France and England",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1333,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2563",
        "source" : "1322",
        "target" : "2561",
        "shared_name" : "George Rylands (authorOf) Russet and Taffeta",
        "Attribute_1_year" : 1925,
        "shared_interaction" : "authorOf",
        "name" : "George Rylands (authorOf) Russet and Taffeta",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 2563,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1326",
        "source" : "1322",
        "target" : "1324",
        "shared_name" : "George Rylands (authorOf) Poems_3",
        "Attribute_1_year" : 1931,
        "shared_interaction" : "authorOf",
        "name" : "George Rylands (authorOf) Poems_3",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1326,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2469",
        "source" : "1310",
        "target" : "2467",
        "shared_name" : "Norman Leys (authorOf) Kenya",
        "Attribute_1_year" : 1924,
        "shared_interaction" : "authorOf",
        "name" : "Norman Leys (authorOf) Kenya",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 2469,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1927",
        "source" : "1310",
        "target" : "1925",
        "shared_name" : "Norman Leys (authorOf) The Colour Bar in East Africa",
        "Attribute_1_year" : 1941,
        "shared_interaction" : "authorOf",
        "name" : "Norman Leys (authorOf) The Colour Bar in East Africa",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1927,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1314",
        "source" : "1310",
        "target" : "1312",
        "shared_name" : "Norman Leys (authorOf) A Last Chance in Kenya",
        "Attribute_1_year" : 1931,
        "shared_interaction" : "authorOf",
        "name" : "Norman Leys (authorOf) A Last Chance in Kenya",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1314,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1307",
        "source" : "1303",
        "target" : "1305",
        "shared_name" : "Rosamond Lehmann (authorOf) A Letter to a Sister",
        "Attribute_1_year" : 1931,
        "shared_interaction" : "authorOf",
        "name" : "Rosamond Lehmann (authorOf) A Letter to a Sister",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1307,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4959",
        "source" : "1296",
        "target" : "4957",
        "shared_name" : "John Lehmann (authorOf) The Sphere of Glass and other poems",
        "Attribute_1_year" : 1944,
        "shared_interaction" : "authorOf",
        "name" : "John Lehmann (authorOf) The Sphere of Glass and other poems",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4959,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4701",
        "source" : "1296",
        "target" : "4699",
        "shared_name" : "John Lehmann (editorOf) Poets of Tomorrow",
        "Attribute_1_year" : 1939,
        "shared_interaction" : "editorOf",
        "name" : "John Lehmann (editorOf) Poets of Tomorrow",
        "interaction" : "editorOf",
        "certainty" : "definite",
        "SUID" : 4701,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3975",
        "source" : "1296",
        "target" : "3940",
        "shared_name" : "John Lehmann (contributedTo) New Country Prose and Poetry by the authors of New Signatures",
        "Attribute_1_year" : 1933,
        "shared_interaction" : "contributedTo",
        "name" : "John Lehmann (contributedTo) New Country Prose and Poetry by the authors of New Signatures",
        "interaction" : "contributedTo",
        "certainty" : "definite",
        "SUID" : 3975,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3787",
        "source" : "1296",
        "target" : "3761",
        "shared_name" : "John Lehmann (contributedTo) New Signatures Poems by Several Hands",
        "Attribute_1_year" : 1932,
        "shared_interaction" : "contributedTo",
        "name" : "John Lehmann (contributedTo) New Signatures Poems by Several Hands",
        "interaction" : "contributedTo",
        "certainty" : "definite",
        "SUID" : 3787,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1975",
        "source" : "1296",
        "target" : "1973",
        "shared_name" : "John Lehmann (authorOf) Forty Poems",
        "Attribute_1_year" : 1942,
        "shared_interaction" : "authorOf",
        "name" : "John Lehmann (authorOf) Forty Poems",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1975,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1550",
        "source" : "1296",
        "target" : "1548",
        "shared_name" : "John Lehmann (authorOf) The Noise of History",
        "Attribute_1_year" : 1934,
        "shared_interaction" : "authorOf",
        "name" : "John Lehmann (authorOf) The Noise of History",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1550,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1300",
        "source" : "1296",
        "target" : "1298",
        "shared_name" : "John Lehmann (authorOf) A Garden Revisited and Other Poems",
        "Attribute_1_year" : 1931,
        "shared_interaction" : "authorOf",
        "name" : "John Lehmann (authorOf) A Garden Revisited and Other Poems",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1300,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1288",
        "source" : "1284",
        "target" : "1286",
        "shared_name" : "C. E. M. Joad (authorOf) The Horrors of the Countryside",
        "Attribute_1_year" : 1931,
        "shared_interaction" : "authorOf",
        "name" : "C. E. M. Joad (authorOf) The Horrors of the Countryside",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1288,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1281",
        "source" : "1277",
        "target" : "1279",
        "shared_name" : "Denis Ireland (authorOf) Ulster To-Day and To-Morrow Her Part in a Gaelic Civilization A Study in Political Re-Evolution",
        "Attribute_1_year" : 1931,
        "shared_interaction" : "authorOf",
        "name" : "Denis Ireland (authorOf) Ulster To-Day and To-Morrow Her Part in a Gaelic Civilization A Study in Political Re-Evolution",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1281,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1274",
        "source" : "1270",
        "target" : "1272",
        "shared_name" : "L. M. Fraser (authorOf) Protection and Free Trade",
        "Attribute_1_year" : 1931,
        "shared_interaction" : "authorOf",
        "name" : "L. M. Fraser (authorOf) Protection and Free Trade",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1274,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4634",
        "source" : "1258",
        "target" : "4632",
        "shared_name" : "Joan Adeney Easdale (authorOf) Amber Innocent",
        "Attribute_1_year" : 1939,
        "shared_interaction" : "authorOf",
        "name" : "Joan Adeney Easdale (authorOf) Amber Innocent",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4634,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1384",
        "source" : "1258",
        "target" : "1382",
        "shared_name" : "Joan Adeney Easdale (authorOf) Clemence and Clare",
        "Attribute_1_year" : 1932,
        "shared_interaction" : "authorOf",
        "name" : "Joan Adeney Easdale (authorOf) Clemence and Clare",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1384,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1262",
        "source" : "1258",
        "target" : "1260",
        "shared_name" : "Joan Adeney Easdale (authorOf) A Collection of Poems (Written between the ages of 14 and 17)",
        "Attribute_1_year" : 1931,
        "shared_interaction" : "authorOf",
        "name" : "Joan Adeney Easdale (authorOf) A Collection of Poems (Written between the ages of 14 and 17)",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1262,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1255",
        "source" : "1251",
        "target" : "1253",
        "shared_name" : "Lord Derwent (authorOf) Fifty Poems",
        "Attribute_1_year" : 1931,
        "shared_interaction" : "authorOf",
        "name" : "Lord Derwent (authorOf) Fifty Poems",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1255,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1243",
        "source" : "1239",
        "target" : "1241",
        "shared_name" : "Viscount Cecil (authorOf) A Letter to an M. P. on Disarmament",
        "Attribute_1_year" : 1931,
        "shared_interaction" : "authorOf",
        "name" : "Viscount Cecil (authorOf) A Letter to an M. P. on Disarmament",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1243,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1236",
        "source" : "1232",
        "target" : "1234",
        "shared_name" : "Charles Roden Buxton, MP (authorOf) The Race Problem in Africa",
        "Attribute_1_year" : 1931,
        "shared_interaction" : "authorOf",
        "name" : "Charles Roden Buxton, MP (authorOf) The Race Problem in Africa",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1236,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1214",
        "source" : "1210",
        "target" : "1212",
        "shared_name" : "Sherard Vines (authorOf) The Course of English Classicism from the Tudor to the Victorian Age",
        "Attribute_1_year" : 1930,
        "shared_interaction" : "authorOf",
        "name" : "Sherard Vines (authorOf) The Course of English Classicism from the Tudor to the Victorian Age",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1214,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3614",
        "source" : "1203",
        "target" : "3612",
        "shared_name" : "Hugh J. Schonfield (authorOf) The Search A Quarterly Review",
        "Attribute_1_year" : 1931,
        "shared_interaction" : "authorOf",
        "name" : "Hugh J. Schonfield (authorOf) The Search A Quarterly Review",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 3614,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1207",
        "source" : "1203",
        "target" : "1205",
        "shared_name" : "Hugh J. Schonfield (editorOf) Letters to Frederick Tennyson",
        "Attribute_1_year" : 1930,
        "shared_interaction" : "editorOf",
        "name" : "Hugh J. Schonfield (editorOf) Letters to Frederick Tennyson",
        "interaction" : "editorOf",
        "certainty" : "definite",
        "SUID" : 1207,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1200",
        "source" : "1191",
        "target" : "1198",
        "shared_name" : "Horace B. Samuel (authorOf) Beneath the Whitewash A critical analysis of the report of the Commission on the Palestine Disturbances of August, 1929",
        "Attribute_1_year" : 1930,
        "shared_interaction" : "authorOf",
        "name" : "Horace B. Samuel (authorOf) Beneath the Whitewash A critical analysis of the report of the Commission on the Palestine Disturbances of August, 1929",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1200,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1195",
        "source" : "1191",
        "target" : "1193",
        "shared_name" : "Horace B. Samuel (authorOf) Unholy Memories of the Holy Land",
        "Attribute_1_year" : 1930,
        "shared_interaction" : "authorOf",
        "name" : "Horace B. Samuel (authorOf) Unholy Memories of the Holy Land",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1195,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1183",
        "source" : "1179",
        "target" : "1181",
        "shared_name" : "Edwin Arlington Robinson (authorOf) Cavender's House",
        "Attribute_1_year" : 1930,
        "shared_interaction" : "authorOf",
        "name" : "Edwin Arlington Robinson (authorOf) Cavender's House",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1183,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4109",
        "source" : "1167",
        "target" : "4104",
        "shared_name" : "Roger Money-Kyrle (translatedFor) The Riddle of the Sphinx or Human Origins",
        "Attribute_1_year" : 1934,
        "shared_interaction" : "translatedFor",
        "name" : "Roger Money-Kyrle (translatedFor) The Riddle of the Sphinx or Human Origins",
        "interaction" : "translatedFor",
        "certainty" : "definite",
        "SUID" : 4109,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1874",
        "source" : "1167",
        "target" : "1872",
        "shared_name" : "Roger Money-Kyrle (authorOf) Supersition and Society",
        "Attribute_1_year" : 1939,
        "shared_interaction" : "authorOf",
        "name" : "Roger Money-Kyrle (authorOf) Supersition and Society",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1874,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1171",
        "source" : "1167",
        "target" : "1169",
        "shared_name" : "Roger Money-Kyrle (authorOf) The Meaning of Sacrifice",
        "Attribute_1_year" : 1930,
        "shared_interaction" : "authorOf",
        "name" : "Roger Money-Kyrle (authorOf) The Meaning of Sacrifice",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1171,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1159",
        "source" : "1155",
        "target" : "1157",
        "shared_name" : "Norman Macleod (authorOf) German Lyric Poetry",
        "Attribute_1_year" : 1930,
        "shared_interaction" : "authorOf",
        "name" : "Norman Macleod (authorOf) German Lyric Poetry",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1159,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1152",
        "source" : "1148",
        "target" : "1150",
        "shared_name" : "John W. Graham (authorOf) Britain & America",
        "Attribute_1_year" : 1930,
        "shared_interaction" : "authorOf",
        "name" : "John W. Graham (authorOf) Britain & America",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1152,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1145",
        "source" : "1141",
        "target" : "1143",
        "shared_name" : "J. C. Flugel (authorOf) The Psychology of Clothes",
        "Attribute_1_year" : 1930,
        "shared_interaction" : "authorOf",
        "name" : "J. C. Flugel (authorOf) The Psychology of Clothes",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1145,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1379",
        "source" : "1134",
        "target" : "1377",
        "shared_name" : "Maurice Dobb (authorOf) On Marxism To-Day",
        "Attribute_1_year" : 1932,
        "shared_interaction" : "authorOf",
        "name" : "Maurice Dobb (authorOf) On Marxism To-Day",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1379,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1138",
        "source" : "1134",
        "target" : "1136",
        "shared_name" : "Maurice Dobb (authorOf) Russia To-Day and To-Morrow",
        "Attribute_1_year" : 1930,
        "shared_interaction" : "authorOf",
        "name" : "Maurice Dobb (authorOf) Russia To-Day and To-Morrow",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1138,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1121",
        "source" : "1117",
        "target" : "1119",
        "shared_name" : "Humbert Wolfe (authorOf) Notes on English Verse Satire",
        "Attribute_1_year" : 1929,
        "shared_interaction" : "authorOf",
        "name" : "Humbert Wolfe (authorOf) Notes on English Verse Satire",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1121,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1109",
        "source" : "1105",
        "target" : "1107",
        "shared_name" : "John S. Stephens (authorOf) Danger Zones of Europe A Study of National Minorities",
        "Attribute_1_year" : 1929,
        "shared_interaction" : "authorOf",
        "name" : "John S. Stephens (authorOf) Danger Zones of Europe A Study of National Minorities",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1109,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1102",
        "source" : "1098",
        "target" : "1100",
        "shared_name" : "Mark Starr (authorOf) Lies and Hate in Education",
        "Attribute_1_year" : 1929,
        "shared_interaction" : "authorOf",
        "name" : "Mark Starr (authorOf) Lies and Hate in Education",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1102,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1080",
        "source" : "1076",
        "target" : "1078",
        "shared_name" : "Sylvia Norman (authorOf) Nature Has No Time",
        "Attribute_1_year" : 1929,
        "shared_interaction" : "authorOf",
        "name" : "Sylvia Norman (authorOf) Nature Has No Time",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1080,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3319",
        "source" : "1069",
        "target" : "3244",
        "shared_name" : "Huw Menai (contributedTo) A Broadcast Anthology of Modern Poetry",
        "Attribute_1_year" : 1930,
        "shared_interaction" : "contributedTo",
        "name" : "Huw Menai (contributedTo) A Broadcast Anthology of Modern Poetry",
        "interaction" : "contributedTo",
        "certainty" : "definite",
        "SUID" : 3319,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1073",
        "source" : "1069",
        "target" : "1071",
        "shared_name" : "Huw Menai (authorOf) The Passing of Gato and Other Poems",
        "Attribute_1_year" : 1929,
        "shared_interaction" : "authorOf",
        "name" : "Huw Menai (authorOf) The Passing of Gato and Other Poems",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1073,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1061",
        "source" : "1052",
        "target" : "1059",
        "shared_name" : "E. E. Kellett (authorOf) The Northern Saga",
        "Attribute_1_year" : 1929,
        "shared_interaction" : "authorOf",
        "name" : "E. E. Kellett (authorOf) The Northern Saga",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1061,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1056",
        "source" : "1052",
        "target" : "1054",
        "shared_name" : "E. E. Kellett (authorOf) The Whirling of Taste",
        "Attribute_1_year" : 1929,
        "shared_interaction" : "authorOf",
        "name" : "E. E. Kellett (authorOf) The Whirling of Taste",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1056,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1039",
        "source" : "1035",
        "target" : "1037",
        "shared_name" : "Ida Graves (authorOf) The China Cupboard and Other Poems",
        "Attribute_1_year" : 1929,
        "shared_interaction" : "authorOf",
        "name" : "Ida Graves (authorOf) The China Cupboard and Other Poems",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1039,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4552",
        "source" : "1028",
        "target" : "4533",
        "shared_name" : "C. Day Lewis (contributedTo) Julian Bell Essays, Poems and Letters",
        "Attribute_1_year" : 1938,
        "shared_interaction" : "contributedTo",
        "name" : "C. Day Lewis (contributedTo) Julian Bell Essays, Poems and Letters",
        "interaction" : "contributedTo",
        "certainty" : "definite",
        "SUID" : 4552,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3961",
        "source" : "1028",
        "target" : "3940",
        "shared_name" : "C. Day Lewis (contributedTo) New Country Prose and Poetry by the authors of New Signatures",
        "Attribute_1_year" : 1933,
        "shared_interaction" : "contributedTo",
        "name" : "C. Day Lewis (contributedTo) New Country Prose and Poetry by the authors of New Signatures",
        "interaction" : "contributedTo",
        "certainty" : "definite",
        "SUID" : 3961,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3774",
        "source" : "1028",
        "target" : "3761",
        "shared_name" : "C. Day Lewis (contributedTo) New Signatures Poems by Several Hands",
        "Attribute_1_year" : 1932,
        "shared_interaction" : "contributedTo",
        "name" : "C. Day Lewis (contributedTo) New Signatures Poems by Several Hands",
        "interaction" : "contributedTo",
        "certainty" : "definite",
        "SUID" : 3774,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1898",
        "source" : "1028",
        "target" : "1896",
        "shared_name" : "C. Day Lewis (authorOf) Selected Poems_1",
        "Attribute_1_year" : 1940,
        "shared_interaction" : "authorOf",
        "name" : "C. Day Lewis (authorOf) Selected Poems_1",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1898,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1697",
        "source" : "1028",
        "target" : "1695",
        "shared_name" : "C. Day Lewis (authorOf) Noah and the Waters",
        "Attribute_1_year" : 1936,
        "shared_interaction" : "authorOf",
        "name" : "C. Day Lewis (authorOf) Noah and the Waters",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1697,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1628",
        "source" : "1028",
        "target" : "1626",
        "shared_name" : "C. Day Lewis (authorOf) Revolution in Writing",
        "Attribute_1_year" : 1935,
        "shared_interaction" : "authorOf",
        "name" : "C. Day Lewis (authorOf) Revolution in Writing",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1628,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1623",
        "source" : "1028",
        "target" : "1621",
        "shared_name" : "C. Day Lewis (authorOf) A Time to Dance and Other Poems",
        "Attribute_1_year" : 1935,
        "shared_interaction" : "authorOf",
        "name" : "C. Day Lewis (authorOf) A Time to Dance and Other Poems",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1623,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1618",
        "source" : "1028",
        "target" : "1616",
        "shared_name" : "C. Day Lewis (authorOf) Collected Poems 1929-1933",
        "Attribute_1_year" : 1935,
        "shared_interaction" : "authorOf",
        "name" : "C. Day Lewis (authorOf) Collected Poems 1929-1933",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1618,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1493",
        "source" : "1028",
        "target" : "1491",
        "shared_name" : "C. Day Lewis (authorOf) The Magnetic Mountain",
        "Attribute_1_year" : 1933,
        "shared_interaction" : "authorOf",
        "name" : "C. Day Lewis (authorOf) The Magnetic Mountain",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1493,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1248",
        "source" : "1028",
        "target" : "1246",
        "shared_name" : "C. Day Lewis (authorOf) From Feathers to Iron",
        "Attribute_1_year" : 1931,
        "shared_interaction" : "authorOf",
        "name" : "C. Day Lewis (authorOf) From Feathers to Iron",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1248,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1032",
        "source" : "1028",
        "target" : "1030",
        "shared_name" : "C. Day Lewis (authorOf) Transitional Poem",
        "Attribute_1_year" : 1929,
        "shared_interaction" : "authorOf",
        "name" : "C. Day Lewis (authorOf) Transitional Poem",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1032,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1821",
        "source" : "1021",
        "target" : "1819",
        "shared_name" : "G. D. H. Cole (authorOf) The Machinery of Socialist Planning",
        "Attribute_1_year" : 1938,
        "shared_interaction" : "authorOf",
        "name" : "G. D. H. Cole (authorOf) The Machinery of Socialist Planning",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1821,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1025",
        "source" : "1021",
        "target" : "1023",
        "shared_name" : "G. D. H. Cole (authorOf) Politics and Literature",
        "Attribute_1_year" : 1929,
        "shared_interaction" : "authorOf",
        "name" : "G. D. H. Cole (authorOf) Politics and Literature",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1025,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4015",
        "source" : "1014",
        "target" : "4013",
        "shared_name" : "Edmund Blunden (editorOf) Charles Lamb His Life Recorded by his Contemporaries",
        "Attribute_1_year" : 1934,
        "shared_interaction" : "editorOf",
        "name" : "Edmund Blunden (editorOf) Charles Lamb His Life Recorded by his Contemporaries",
        "interaction" : "editorOf",
        "certainty" : "definite",
        "SUID" : 4015,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3264",
        "source" : "1014",
        "target" : "3244",
        "shared_name" : "Edmund Blunden (contributedTo) A Broadcast Anthology of Modern Poetry",
        "Attribute_1_year" : 1930,
        "shared_interaction" : "contributedTo",
        "name" : "Edmund Blunden (contributedTo) A Broadcast Anthology of Modern Poetry",
        "interaction" : "contributedTo",
        "certainty" : "definite",
        "SUID" : 3264,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1018",
        "source" : "1014",
        "target" : "1016",
        "shared_name" : "Edmund Blunden (authorOf) Nature in English Literature",
        "Attribute_1_year" : 1929,
        "shared_interaction" : "authorOf",
        "name" : "Edmund Blunden (authorOf) Nature in English Literature",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1018,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3125",
        "source" : "1007",
        "target" : "3123",
        "shared_name" : "Wilfrid Benson (authorOf) Dawn on Mont Blanc Being Incidentally the tragedy of an aggravating young man",
        "Attribute_1_year" : 1930,
        "shared_interaction" : "authorOf",
        "name" : "Wilfrid Benson (authorOf) Dawn on Mont Blanc Being Incidentally the tragedy of an aggravating young man",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 3125,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1131",
        "source" : "1007",
        "target" : "1129",
        "shared_name" : "Wilfrid Benson (authorOf) As You Were",
        "Attribute_1_year" : 1930,
        "shared_interaction" : "authorOf",
        "name" : "Wilfrid Benson (authorOf) As You Were",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1131,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1011",
        "source" : "1007",
        "target" : "1009",
        "shared_name" : "Wilfrid Benson (authorOf) The Foreigner in the Family",
        "Attribute_1_year" : 1929,
        "shared_interaction" : "authorOf",
        "name" : "Wilfrid Benson (authorOf) The Foreigner in the Family",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1011,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2969",
        "source" : "995",
        "target" : "2967",
        "shared_name" : "Florence Wilson (authorOf) The Origins of the League Covenant Documentary History of Its Drafting",
        "Attribute_1_year" : 1928,
        "shared_interaction" : "authorOf",
        "name" : "Florence Wilson (authorOf) The Origins of the League Covenant Documentary History of Its Drafting",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 2969,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "999",
        "source" : "995",
        "target" : "997",
        "shared_name" : "Florence Wilson (authorOf) Near East Eductional Survey Report of a survey made during the months of April, May and June 1927",
        "Attribute_1_year" : 1928,
        "shared_interaction" : "authorOf",
        "name" : "Florence Wilson (authorOf) Near East Eductional Survey Report of a survey made during the months of April, May and June 1927",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 999,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1343",
        "source" : "988",
        "target" : "1341",
        "shared_name" : "Eric Walter White (authorOf) Walking Shadows An Essay on Lotte Reiniger's Silhouette Films",
        "Attribute_1_year" : 1931,
        "shared_interaction" : "authorOf",
        "name" : "Eric Walter White (authorOf) Walking Shadows An Essay on Lotte Reiniger's Silhouette Films",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1343,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1229",
        "source" : "988",
        "target" : "1227",
        "shared_name" : "Eric Walter White (authorOf) Stravinsky's Sacrifice to Apollo",
        "Attribute_1_year" : 1930,
        "shared_interaction" : "authorOf",
        "name" : "Eric Walter White (authorOf) Stravinsky's Sacrifice to Apollo",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1229,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "992",
        "source" : "988",
        "target" : "990",
        "shared_name" : "Eric Walter White (authorOf) Parnassus to Let An Essay about Rhythm in the Films",
        "Attribute_1_year" : 1928,
        "shared_interaction" : "authorOf",
        "name" : "Eric Walter White (authorOf) Parnassus to Let An Essay about Rhythm in the Films",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 992,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3823",
        "source" : "981",
        "target" : "3821",
        "shared_name" : "Dorothy Wellesley (authorOf) Jupiter and the Nun",
        "Attribute_1_year" : 1932,
        "shared_interaction" : "authorOf",
        "name" : "Dorothy Wellesley (authorOf) Jupiter and the Nun",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 3823,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3356",
        "source" : "981",
        "target" : "3244",
        "shared_name" : "Dorothy Wellesley (contributedTo) A Broadcast Anthology of Modern Poetry",
        "Attribute_1_year" : 1930,
        "shared_interaction" : "contributedTo",
        "name" : "Dorothy Wellesley (contributedTo) A Broadcast Anthology of Modern Poetry",
        "interaction" : "contributedTo",
        "certainty" : "definite",
        "SUID" : 3356,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3246",
        "source" : "981",
        "target" : "3244",
        "shared_name" : "Dorothy Wellesley (editorOf) A Broadcast Anthology of Modern Poetry",
        "Attribute_1_year" : 1930,
        "shared_interaction" : "editorOf",
        "name" : "Dorothy Wellesley (editorOf) A Broadcast Anthology of Modern Poetry",
        "interaction" : "editorOf",
        "certainty" : "definite",
        "SUID" : 3246,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1987",
        "source" : "981",
        "target" : "1985",
        "shared_name" : "Dorothy Wellesley (authorOf) Lost Planet and Other Poems",
        "Attribute_1_year" : 1942,
        "shared_interaction" : "authorOf",
        "name" : "Dorothy Wellesley (authorOf) Lost Planet and Other Poems",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1987,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1219",
        "source" : "981",
        "target" : "1217",
        "shared_name" : "Dorothy Wellesley (authorOf) Deserted House A Poem-Sequence",
        "Attribute_1_year" : 1930,
        "shared_interaction" : "authorOf",
        "name" : "Dorothy Wellesley (authorOf) Deserted House A Poem-Sequence",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1219,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "985",
        "source" : "981",
        "target" : "983",
        "shared_name" : "Dorothy Wellesley (authorOf) Matrix",
        "Attribute_1_year" : 1928,
        "shared_interaction" : "authorOf",
        "name" : "Dorothy Wellesley (authorOf) Matrix",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 985,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "973",
        "source" : "969",
        "target" : "971",
        "shared_name" : "Basil De Selincourt (authorOf) The Enjoyment of Music",
        "Attribute_1_year" : 1928,
        "shared_interaction" : "authorOf",
        "name" : "Basil De Selincourt (authorOf) The Enjoyment of Music",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 973,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1939",
        "source" : "957",
        "target" : "1937",
        "shared_name" : "Elizabeth Robins (authorOf) Portrait of a Lady or The English Spirit Old and New",
        "Attribute_1_year" : 1941,
        "shared_interaction" : "authorOf",
        "name" : "Elizabeth Robins (authorOf) Portrait of a Lady or The English Spirit Old and New",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1939,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "961",
        "source" : "957",
        "target" : "959",
        "shared_name" : "Elizabeth Robins (authorOf) Ibsen and the Actress",
        "Attribute_1_year" : 1928,
        "shared_interaction" : "authorOf",
        "name" : "Elizabeth Robins (authorOf) Ibsen and the Actress",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 961,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3221",
        "source" : "950",
        "target" : "3219",
        "shared_name" : "Alice Ritchie (authorOf) Occupied Territory",
        "Attribute_1_year" : 1930,
        "shared_interaction" : "authorOf",
        "name" : "Alice Ritchie (authorOf) Occupied Territory",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 3221,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "954",
        "source" : "950",
        "target" : "952",
        "shared_name" : "Alice Ritchie (authorOf) The Peacemakers",
        "Attribute_1_year" : 1928,
        "shared_interaction" : "authorOf",
        "name" : "Alice Ritchie (authorOf) The Peacemakers",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 954,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4645",
        "source" : "943",
        "target" : "4640",
        "shared_name" : "John Rickman (editorOf) Civilization, War and Death Selections from Three Works",
        "Attribute_1_year" : 1939,
        "shared_interaction" : "editorOf",
        "name" : "John Rickman (editorOf) Civilization, War and Death Selections from Three Works",
        "interaction" : "editorOf",
        "certainty" : "definite",
        "SUID" : 4645,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4459",
        "source" : "943",
        "target" : "4454",
        "shared_name" : "John Rickman (editorOf) A General Selection from the Works of Sigmund Freud",
        "Attribute_1_year" : 1937,
        "shared_interaction" : "editorOf",
        "name" : "John Rickman (editorOf) A General Selection from the Works of Sigmund Freud",
        "interaction" : "editorOf",
        "certainty" : "definite",
        "SUID" : 4459,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2661",
        "source" : "943",
        "target" : "2651",
        "shared_name" : "John Rickman (compilerOf) Further Contributions to the Theory and Technique of Psycho-Analysis",
        "Attribute_1_year" : 1926,
        "shared_interaction" : "compilerOf",
        "name" : "John Rickman (compilerOf) Further Contributions to the Theory and Technique of Psycho-Analysis",
        "interaction" : "compilerOf",
        "certainty" : "definite",
        "SUID" : 2661,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "947",
        "source" : "943",
        "target" : "945",
        "shared_name" : "John Rickman (authorOf) Index Psychoanalysis 1893-1926 Being an Authors' Index of Papers on Psycho-Analysis",
        "Attribute_1_year" : 1928,
        "shared_interaction" : "authorOf",
        "name" : "John Rickman (authorOf) Index Psychoanalysis 1893-1926 Being an Authors' Index of Papers on Psycho-Analysis",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 947,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "940",
        "source" : "936",
        "target" : "938",
        "shared_name" : "Viscountess Rhondda (authorOf) Leisured Women",
        "Attribute_1_year" : 1928,
        "shared_interaction" : "authorOf",
        "name" : "Viscountess Rhondda (authorOf) Leisured Women",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 940,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "928",
        "source" : "924",
        "target" : "926",
        "shared_name" : "Francis E. Pollard (authorOf) War and Human Values",
        "Attribute_1_year" : 1928,
        "shared_interaction" : "authorOf",
        "name" : "Francis E. Pollard (authorOf) War and Human Values",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 928,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3184",
        "source" : "912",
        "target" : "3182",
        "shared_name" : "Robinson Jeffers (authorOf) Dear Judas and Other Poems",
        "Attribute_1_year" : 1930,
        "shared_interaction" : "authorOf",
        "name" : "Robinson Jeffers (authorOf) Dear Judas and Other Poems",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 3184,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1049",
        "source" : "912",
        "target" : "1047",
        "shared_name" : "Robinson Jeffers (authorOf) Cawdor",
        "Attribute_1_year" : 1929,
        "shared_interaction" : "authorOf",
        "name" : "Robinson Jeffers (authorOf) Cawdor",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1049,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "916",
        "source" : "912",
        "target" : "914",
        "shared_name" : "Robinson Jeffers (authorOf) Roan Stallion Tamar and Other POems",
        "Attribute_1_year" : 1928,
        "shared_interaction" : "authorOf",
        "name" : "Robinson Jeffers (authorOf) Roan Stallion Tamar and Other POems",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 916,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "904",
        "source" : "900",
        "target" : "902",
        "shared_name" : "H. Wilson Harris (authorOf) Arms or Arbitration?",
        "Attribute_1_year" : 1928,
        "shared_interaction" : "authorOf",
        "name" : "H. Wilson Harris (authorOf) Arms or Arbitration?",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 904,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "897",
        "source" : "893",
        "target" : "895",
        "shared_name" : "H. J. C. Grierson (authorOf) Lyrical Poetry from Blake to Hardy",
        "Attribute_1_year" : 1928,
        "shared_interaction" : "authorOf",
        "name" : "H. J. C. Grierson (authorOf) Lyrical Poetry from Blake to Hardy",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 897,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "890",
        "source" : "886",
        "target" : "888",
        "shared_name" : "R. Fitzsure (authorOf) It Was Not Jones",
        "Attribute_1_year" : 1928,
        "shared_interaction" : "authorOf",
        "name" : "R. Fitzsure (authorOf) It Was Not Jones",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 890,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3282",
        "source" : "879",
        "target" : "3244",
        "shared_name" : "Frances Cornford (contributedTo) A Broadcast Anthology of Modern Poetry",
        "Attribute_1_year" : 1930,
        "shared_interaction" : "contributedTo",
        "name" : "Frances Cornford (contributedTo) A Broadcast Anthology of Modern Poetry",
        "interaction" : "contributedTo",
        "certainty" : "definite",
        "SUID" : 3282,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "883",
        "source" : "879",
        "target" : "881",
        "shared_name" : "Frances Cornford (authorOf) Different Days",
        "Attribute_1_year" : 1928,
        "shared_interaction" : "authorOf",
        "name" : "Frances Cornford (authorOf) Different Days",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 883,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "876",
        "source" : "872",
        "target" : "874",
        "shared_name" : "Edgar H. Brookes (authorOf) What is Wrong with the League of Nations? A constructive Criticism of the League of Nations in working, with certain practical suggestions",
        "Attribute_1_year" : 1928,
        "shared_interaction" : "authorOf",
        "name" : "Edgar H. Brookes (authorOf) What is Wrong with the League of Nations? A constructive Criticism of the League of Nations in working, with certain practical suggestions",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 876,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "869",
        "source" : "865",
        "target" : "867",
        "shared_name" : "B. Bowker (authorOf) Lancashire Under the Hammer",
        "Attribute_1_year" : 1928,
        "shared_interaction" : "authorOf",
        "name" : "B. Bowker (authorOf) Lancashire Under the Hammer",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 869,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2260",
        "source" : "858",
        "target" : "2258",
        "shared_name" : "Clive Bell (authorOf) The Legend of Monte Della Sibilla or Le Paradis de la Reine Sibille",
        "Attribute_1_year" : 1923,
        "shared_interaction" : "authorOf",
        "name" : "Clive Bell (authorOf) The Legend of Monte Della Sibilla or Le Paradis de la Reine Sibille",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 2260,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2041",
        "source" : "858",
        "target" : "2039",
        "shared_name" : "Clive Bell (authorOf) Poems_7",
        "Attribute_1_year" : 1921,
        "shared_interaction" : "authorOf",
        "name" : "Clive Bell (authorOf) Poems_7",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 2041,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "862",
        "source" : "858",
        "target" : "860",
        "shared_name" : "Clive Bell (authorOf) Proust",
        "Attribute_1_year" : 1928,
        "shared_interaction" : "authorOf",
        "name" : "Clive Bell (authorOf) Proust",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 862,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1735",
        "source" : "841",
        "target" : "1733",
        "shared_name" : "H. G. Wells (authorOf) The Idea of a World Encyclopaedia A Lecture Delivered at the Royal Institution, November 20th, 1936",
        "Attribute_1_year" : 1936,
        "shared_interaction" : "authorOf",
        "name" : "H. G. Wells (authorOf) The Idea of a World Encyclopaedia A Lecture Delivered at the Royal Institution, November 20th, 1936",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1735,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1224",
        "source" : "841",
        "target" : "1222",
        "shared_name" : "H. G. Wells (authorOf) The Open Conspiracy Blue Prints for a World Revolution A Second Version of this faith of a modern man made more explicit and plain",
        "Attribute_1_year" : 1930,
        "shared_interaction" : "authorOf",
        "name" : "H. G. Wells (authorOf) The Open Conspiracy Blue Prints for a World Revolution A Second Version of this faith of a modern man made more explicit and plain",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1224,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1114",
        "source" : "841",
        "target" : "1112",
        "shared_name" : "H. G. Wells (authorOf) The Common Sense of World Peace",
        "Attribute_1_year" : 1929,
        "shared_interaction" : "authorOf",
        "name" : "H. G. Wells (authorOf) The Common Sense of World Peace",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1114,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "845",
        "source" : "841",
        "target" : "843",
        "shared_name" : "H. G. Wells (authorOf) Democracy Under Revision",
        "Attribute_1_year" : 1927,
        "shared_interaction" : "authorOf",
        "name" : "H. G. Wells (authorOf) Democracy Under Revision",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 845,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2030",
        "source" : "824",
        "target" : "2028",
        "shared_name" : "Logan Pearsall Smith (authorOf) Stories from the Old Testament Retold by Logan Pearsall Smith",
        "Attribute_1_year" : 1920,
        "shared_interaction" : "authorOf",
        "name" : "Logan Pearsall Smith (authorOf) Stories from the Old Testament Retold by Logan Pearsall Smith",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 2030,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "828",
        "source" : "824",
        "target" : "826",
        "shared_name" : "Logan Pearsall Smith (authorOf) The Prospects of Literature",
        "Attribute_1_year" : 1927,
        "shared_interaction" : "authorOf",
        "name" : "Logan Pearsall Smith (authorOf) The Prospects of Literature",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 828,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "821",
        "source" : "817",
        "target" : "819",
        "shared_name" : "Wm. Stephen Sanders (authorOf) Early Socialist Days",
        "Attribute_1_year" : 1927,
        "shared_interaction" : "authorOf",
        "name" : "Wm. Stephen Sanders (authorOf) Early Socialist Days",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 821,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3540",
        "source" : "810",
        "target" : "3532",
        "shared_name" : "Edward Sackville-West (translatedFor) Duineser Elegien Elegies from the Castle of Duino",
        "Attribute_1_year" : 1931,
        "shared_interaction" : "translatedFor",
        "name" : "Edward Sackville-West (translatedFor) Duineser Elegien Elegies from the Castle of Duino",
        "interaction" : "translatedFor",
        "certainty" : "definite",
        "SUID" : 3540,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "814",
        "source" : "810",
        "target" : "812",
        "shared_name" : "Edward Sackville-West (authorOf) The Apology of Arthur Rimbaud",
        "Attribute_1_year" : 1927,
        "shared_interaction" : "authorOf",
        "name" : "Edward Sackville-West (authorOf) The Apology of Arthur Rimbaud",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 814,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "807",
        "source" : "803",
        "target" : "805",
        "shared_name" : "Sir Arthur Quiller-Couch (authorOf) A Lecture on Lectures",
        "Attribute_1_year" : 1927,
        "shared_interaction" : "authorOf",
        "name" : "Sir Arthur Quiller-Couch (authorOf) A Lecture on Lectures",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 807,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "790",
        "source" : "786",
        "target" : "788",
        "shared_name" : "Geoffrey Phibbs (authorOf) Withering of the Fig Leaf",
        "Attribute_1_year" : 1927,
        "shared_interaction" : "authorOf",
        "name" : "Geoffrey Phibbs (authorOf) Withering of the Fig Leaf",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 790,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2552",
        "source" : "779",
        "target" : "2550",
        "shared_name" : "Herbert E. Palmer (authorOf) Songs of Salvation Sin & Satire",
        "Attribute_1_year" : 1925,
        "shared_interaction" : "authorOf",
        "name" : "Herbert E. Palmer (authorOf) Songs of Salvation Sin & Satire",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 2552,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1176",
        "source" : "779",
        "target" : "1174",
        "shared_name" : "Herbert E. Palmer (authorOf) The Armed Muse Poems",
        "Attribute_1_year" : 1930,
        "shared_interaction" : "authorOf",
        "name" : "Herbert E. Palmer (authorOf) The Armed Muse Poems",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1176,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "783",
        "source" : "779",
        "target" : "781",
        "shared_name" : "Herbert E. Palmer (authorOf) The Judgement of Francois Villon A Pageant-Episode Play in Five Acts",
        "Attribute_1_year" : 1927,
        "shared_interaction" : "authorOf",
        "name" : "Herbert E. Palmer (authorOf) The Judgement of Francois Villon A Pageant-Episode Play in Five Acts",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 783,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3924",
        "source" : "767",
        "target" : "3922",
        "shared_name" : "Lord Olivier (authorOf) The Myth of Governor Eyre",
        "Attribute_1_year" : 1933,
        "shared_interaction" : "authorOf",
        "name" : "Lord Olivier (authorOf) The Myth of Governor Eyre",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 3924,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1085",
        "source" : "767",
        "target" : "1083",
        "shared_name" : "Lord Olivier (authorOf) White Capital & Coloured Labor",
        "Attribute_1_year" : 1929,
        "shared_interaction" : "authorOf",
        "name" : "Lord Olivier (authorOf) White Capital & Coloured Labor",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1085,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "776",
        "source" : "767",
        "target" : "774",
        "shared_name" : "Lord Olivier (authorOf) The Empire Builder",
        "Attribute_1_year" : 1927,
        "shared_interaction" : "authorOf",
        "name" : "Lord Olivier (authorOf) The Empire Builder",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 776,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "771",
        "source" : "767",
        "target" : "769",
        "shared_name" : "Lord Olivier (authorOf) The Anatomy of African Misery",
        "Attribute_1_year" : 1927,
        "shared_interaction" : "authorOf",
        "name" : "Lord Olivier (authorOf) The Anatomy of African Misery",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 771,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "754",
        "source" : "750",
        "target" : "752",
        "shared_name" : "Allardyce Nicoll (authorOf) Studies in Shakespeare",
        "Attribute_1_year" : 1927,
        "shared_interaction" : "authorOf",
        "name" : "Allardyce Nicoll (authorOf) Studies in Shakespeare",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 754,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "747",
        "source" : "743",
        "target" : "745",
        "shared_name" : "Fridtjof Nansen (authorOf) Adventure and Other Papers",
        "Attribute_1_year" : 1927,
        "shared_interaction" : "authorOf",
        "name" : "Fridtjof Nansen (authorOf) Adventure and Other Papers",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 747,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1164",
        "source" : "731",
        "target" : "1162",
        "shared_name" : "F. O. Mann (authorOf) St. James's Park and other poems",
        "Attribute_1_year" : 1930,
        "shared_interaction" : "authorOf",
        "name" : "F. O. Mann (authorOf) St. James's Park and other poems",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1164,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "735",
        "source" : "731",
        "target" : "733",
        "shared_name" : "F. O. Mann (authorOf) The SIsters and Other Tales in Verse",
        "Attribute_1_year" : 1927,
        "shared_interaction" : "authorOf",
        "name" : "F. O. Mann (authorOf) The SIsters and Other Tales in Verse",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 735,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "718",
        "source" : "709",
        "target" : "716",
        "shared_name" : "Stephen King-Hall (authorOf) Posterity",
        "Attribute_1_year" : 1927,
        "shared_interaction" : "authorOf",
        "name" : "Stephen King-Hall (authorOf) Posterity",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 718,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "713",
        "source" : "709",
        "target" : "711",
        "shared_name" : "Stephen King-Hall (authorOf) The China of To-Day",
        "Attribute_1_year" : 1927,
        "shared_interaction" : "authorOf",
        "name" : "Stephen King-Hall (authorOf) The China of To-Day",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 713,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "696",
        "source" : "692",
        "target" : "694",
        "shared_name" : "Mary Hutchinson (authorOf) Fugitive Pieces",
        "Attribute_1_year" : 1927,
        "shared_interaction" : "authorOf",
        "name" : "Mary Hutchinson (authorOf) Fugitive Pieces",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 696,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "909",
        "source" : "685",
        "target" : "907",
        "shared_name" : "Robert H. Hull (authorOf) Delius",
        "Attribute_1_year" : 1928,
        "shared_interaction" : "authorOf",
        "name" : "Robert H. Hull (authorOf) Delius",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 909,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "689",
        "source" : "685",
        "target" : "687",
        "shared_name" : "Robert H. Hull (authorOf) Contemporary Music",
        "Attribute_1_year" : 1927,
        "shared_interaction" : "authorOf",
        "name" : "Robert H. Hull (authorOf) Contemporary Music",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 689,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "682",
        "source" : "678",
        "target" : "680",
        "shared_name" : "Charles Davies (authorOf) Welshman's Way",
        "Attribute_1_year" : 1927,
        "shared_interaction" : "authorOf",
        "name" : "Charles Davies (authorOf) Welshman's Way",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 682,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "675",
        "source" : "671",
        "target" : "673",
        "shared_name" : "R. B. Braithwaite (authorOf) The State of Religious Belief An Inquiry Based on \"The Nation and Athenaeum\" Questionnaire",
        "Attribute_1_year" : 1927,
        "shared_interaction" : "authorOf",
        "name" : "R. B. Braithwaite (authorOf) The State of Religious Belief An Inquiry Based on \"The Nation and Athenaeum\" Questionnaire",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 675,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "668",
        "source" : "664",
        "target" : "666",
        "shared_name" : "Horace G. Alexander (authorOf) Justice Among Nations",
        "Attribute_1_year" : 1927,
        "shared_interaction" : "authorOf",
        "name" : "Horace G. Alexander (authorOf) Justice Among Nations",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 668,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "661",
        "source" : "657",
        "target" : "659",
        "shared_name" : "Hubert Waley (authorOf) The Revival of Aesthetics",
        "Attribute_1_year" : 1926,
        "shared_interaction" : "authorOf",
        "name" : "Hubert Waley (authorOf) The Revival of Aesthetics",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 661,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2574",
        "source" : "650",
        "target" : "2572",
        "shared_name" : "R. C. Trevelyan (authorOf) Poems and Fables",
        "Attribute_1_year" : 1925,
        "shared_interaction" : "authorOf",
        "name" : "R. C. Trevelyan (authorOf) Poems and Fables",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 2574,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1956",
        "source" : "650",
        "target" : "1954",
        "shared_name" : "R. C. Trevelyan (authorOf) Aftermath",
        "Attribute_1_year" : 1941,
        "shared_interaction" : "authorOf",
        "name" : "R. C. Trevelyan (authorOf) Aftermath",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1956,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1671",
        "source" : "650",
        "target" : "1669",
        "shared_name" : "R. C. Trevelyan (authorOf) Beelzebub and Other Poems",
        "Attribute_1_year" : 1935,
        "shared_interaction" : "authorOf",
        "name" : "R. C. Trevelyan (authorOf) Beelzebub and Other Poems",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1671,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1469",
        "source" : "650",
        "target" : "1467",
        "shared_name" : "R. C. Trevelyan (authorOf) Rimeless Numbers",
        "Attribute_1_year" : 1932,
        "shared_interaction" : "authorOf",
        "name" : "R. C. Trevelyan (authorOf) Rimeless Numbers",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1469,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1338",
        "source" : "650",
        "target" : "1336",
        "shared_name" : "R. C. Trevelyan (authorOf) Three Plays Sulla, Fand, The Pearl Tree",
        "Attribute_1_year" : 1931,
        "shared_interaction" : "authorOf",
        "name" : "R. C. Trevelyan (authorOf) Three Plays Sulla, Fand, The Pearl Tree",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1338,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "838",
        "source" : "650",
        "target" : "836",
        "shared_name" : "R. C. Trevelyan (authorOf) Cheiron",
        "Attribute_1_year" : 1927,
        "shared_interaction" : "authorOf",
        "name" : "R. C. Trevelyan (authorOf) Cheiron",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 838,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "833",
        "source" : "650",
        "target" : "831",
        "shared_name" : "R. C. Trevelyan (authorOf) Meleager",
        "Attribute_1_year" : 1927,
        "shared_interaction" : "authorOf",
        "name" : "R. C. Trevelyan (authorOf) Meleager",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 833,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "654",
        "source" : "650",
        "target" : "652",
        "shared_name" : "R. C. Trevelyan (authorOf) The Deluge and Other Poems",
        "Attribute_1_year" : 1926,
        "shared_interaction" : "authorOf",
        "name" : "R. C. Trevelyan (authorOf) The Deluge and Other Poems",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 654,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4500",
        "source" : "643",
        "target" : "4498",
        "shared_name" : "Viola Tree (authorOf) Can I Help You? Your Manners--Menus--Amusements--Friends--Charades--Make-ups--Travel--Calling--Children--Love Affairs",
        "Attribute_1_year" : 1937,
        "shared_interaction" : "authorOf",
        "name" : "Viola Tree (authorOf) Can I Help You? Your Manners--Menus--Amusements--Friends--Charades--Make-ups--Travel--Calling--Children--Love Affairs",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4500,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "647",
        "source" : "643",
        "target" : "645",
        "shared_name" : "Viola Tree (authorOf) Castles in the Air The Story of My Singing Days",
        "Attribute_1_year" : 1926,
        "shared_interaction" : "authorOf",
        "name" : "Viola Tree (authorOf) Castles in the Air The Story of My Singing Days",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 647,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "640",
        "source" : "636",
        "target" : "638",
        "shared_name" : "Gertrude Stein (authorOf) Composition as Explanation",
        "Attribute_1_year" : 1926,
        "shared_interaction" : "authorOf",
        "name" : "Gertrude Stein (authorOf) Composition as Explanation",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 640,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3892",
        "source" : "629",
        "target" : "3887",
        "shared_name" : "C. P. Sanger (translatedFor) The Tragedy of Man",
        "Attribute_1_year" : 1933,
        "shared_interaction" : "translatedFor",
        "name" : "C. P. Sanger (translatedFor) The Tragedy of Man",
        "interaction" : "translatedFor",
        "certainty" : "definite",
        "SUID" : 3892,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "633",
        "source" : "629",
        "target" : "631",
        "shared_name" : "C. P. Sanger (authorOf) The Structure of Wuthering Heights by C. P. S.",
        "Attribute_1_year" : 1926,
        "shared_interaction" : "authorOf",
        "name" : "C. P. Sanger (authorOf) The Structure of Wuthering Heights by C. P. S.",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 633,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2972",
        "source" : "617",
        "target" : "2967",
        "shared_name" : "P. J. Noel Baker (wroteIntroductionFor) The Origins of the League Covenant Documentary History of Its Drafting",
        "Attribute_1_year" : 1928,
        "shared_interaction" : "wroteIntroductionFor",
        "name" : "P. J. Noel Baker (wroteIntroductionFor) The Origins of the League Covenant Documentary History of Its Drafting",
        "interaction" : "wroteIntroductionFor",
        "certainty" : "definite",
        "SUID" : 2972,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "764",
        "source" : "617",
        "target" : "762",
        "shared_name" : "P. J. Noel Baker (authorOf) Disarmament and the Coolidge Conference",
        "Attribute_1_year" : 1927,
        "shared_interaction" : "authorOf",
        "name" : "P. J. Noel Baker (authorOf) Disarmament and the Coolidge Conference",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 764,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "621",
        "source" : "617",
        "target" : "619",
        "shared_name" : "P. J. Noel Baker (authorOf) Disarmament",
        "Attribute_1_year" : 1926,
        "shared_interaction" : "authorOf",
        "name" : "P. J. Noel Baker (authorOf) Disarmament",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 621,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "609",
        "source" : "605",
        "target" : "607",
        "shared_name" : "Kinglsey Martin (authorOf) The British Public and the General Strike",
        "Attribute_1_year" : 1926,
        "shared_interaction" : "authorOf",
        "name" : "Kinglsey Martin (authorOf) The British Public and the General Strike",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 609,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1840",
        "source" : "598",
        "target" : "1838",
        "shared_name" : "Rose Macaulay (authorOf) The Writings of E. M. Forster",
        "Attribute_1_year" : 1938,
        "shared_interaction" : "authorOf",
        "name" : "Rose Macaulay (authorOf) The Writings of E. M. Forster",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1840,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1319",
        "source" : "598",
        "target" : "1317",
        "shared_name" : "Rose Macaulay (authorOf) Some Religious Elements in English Literature",
        "Attribute_1_year" : 1931,
        "shared_interaction" : "authorOf",
        "name" : "Rose Macaulay (authorOf) Some Religious Elements in English Literature",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1319,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "602",
        "source" : "598",
        "target" : "600",
        "shared_name" : "Rose Macaulay (authorOf) Catchwords and Claptrap",
        "Attribute_1_year" : 1926,
        "shared_interaction" : "authorOf",
        "name" : "Rose Macaulay (authorOf) Catchwords and Claptrap",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 602,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "595",
        "source" : "591",
        "target" : "593",
        "shared_name" : "Marius Lyle (authorOf) The Education of a Young Man in Twelve Lessons",
        "Attribute_1_year" : 1926,
        "shared_interaction" : "authorOf",
        "name" : "Marius Lyle (authorOf) The Education of a Young Man in Twelve Lessons",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 595,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3133",
        "source" : "584",
        "target" : "3131",
        "shared_name" : "F. L. Lucas (editorOf) The Art of Dying An Anthology",
        "Attribute_1_year" : 1930,
        "shared_interaction" : "editorOf",
        "name" : "F. L. Lucas (editorOf) The Art of Dying An Anthology",
        "interaction" : "editorOf",
        "certainty" : "definite",
        "SUID" : 3133,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2500",
        "source" : "584",
        "target" : "2495",
        "shared_name" : "F. L. Lucas (wrotePrefaceFor) Adriatica and Other Poems",
        "Attribute_1_year" : 1925,
        "shared_interaction" : "wrotePrefaceFor",
        "name" : "F. L. Lucas (wrotePrefaceFor) Adriatica and Other Poems",
        "interaction" : "wrotePrefaceFor",
        "certainty" : "definite",
        "SUID" : 2500,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1066",
        "source" : "584",
        "target" : "1064",
        "shared_name" : "F. L. Lucas (authorOf) Time and Memory",
        "Attribute_1_year" : 1929,
        "shared_interaction" : "authorOf",
        "name" : "F. L. Lucas (authorOf) Time and Memory",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1066,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "728",
        "source" : "584",
        "target" : "726",
        "shared_name" : "F. L. Lucas (authorOf) Tragedy in relation to Aristotle's POETICS",
        "Attribute_1_year" : 1927,
        "shared_interaction" : "authorOf",
        "name" : "F. L. Lucas (authorOf) Tragedy in relation to Aristotle's POETICS",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 728,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "588",
        "source" : "584",
        "target" : "586",
        "shared_name" : "F. L. Lucas (authorOf) The River Flows",
        "Attribute_1_year" : 1926,
        "shared_interaction" : "authorOf",
        "name" : "F. L. Lucas (authorOf) The River Flows",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 588,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "581",
        "source" : "577",
        "target" : "579",
        "shared_name" : "Vernon Lee (authorOf) The Poet's Eye",
        "Attribute_1_year" : 1926,
        "shared_interaction" : "authorOf",
        "name" : "Vernon Lee (authorOf) The Poet's Eye",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 581,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "706",
        "source" : "565",
        "target" : "704",
        "shared_name" : "M. Jaeger (authorOf) The Man with Six Senses",
        "Attribute_1_year" : 1927,
        "shared_interaction" : "authorOf",
        "name" : "M. Jaeger (authorOf) The Man with Six Senses",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 706,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "569",
        "source" : "565",
        "target" : "567",
        "shared_name" : "M. Jaeger (authorOf) The Question Mark",
        "Attribute_1_year" : 1926,
        "shared_interaction" : "authorOf",
        "name" : "M. Jaeger (authorOf) The Question Mark",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 569,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1403",
        "source" : "553",
        "target" : "1401",
        "shared_name" : "J. A. Hobson (authorOf) From Capitalism to Socialism",
        "Attribute_1_year" : 1932,
        "shared_interaction" : "authorOf",
        "name" : "J. A. Hobson (authorOf) From Capitalism to Socialism",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1403,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "557",
        "source" : "553",
        "target" : "555",
        "shared_name" : "J. A. Hobson (authorOf) Notes on Law and Order",
        "Attribute_1_year" : 1926,
        "shared_interaction" : "authorOf",
        "name" : "J. A. Hobson (authorOf) Notes on Law and Order",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 557,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "540",
        "source" : "536",
        "target" : "538",
        "shared_name" : "Laura Riding Gottschalk (authorOf) The Close Chaplet",
        "Attribute_1_year" : 1926,
        "shared_interaction" : "authorOf",
        "name" : "Laura Riding Gottschalk (authorOf) The Close Chaplet",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 540,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "523",
        "source" : "519",
        "target" : "521",
        "shared_name" : "W. Arnold-Forster (authorOf) The Victory of Reason A Pamphlet on Arbitration",
        "Attribute_1_year" : 1926,
        "shared_interaction" : "authorOf",
        "name" : "W. Arnold-Forster (authorOf) The Victory of Reason A Pamphlet on Arbitration",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 523,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "978",
        "source" : "502",
        "target" : "976",
        "shared_name" : "Edward Thompson (authorOf) Cock Robin's Decease",
        "Attribute_1_year" : 1928,
        "shared_interaction" : "authorOf",
        "name" : "Edward Thompson (authorOf) Cock Robin's Decease",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 978,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "506",
        "source" : "502",
        "target" : "504",
        "shared_name" : "Edward Thompson (authorOf) The Other Side of the Medal",
        "Attribute_1_year" : 1925,
        "shared_interaction" : "authorOf",
        "name" : "Edward Thompson (authorOf) The Other Side of the Medal",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 506,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3338",
        "source" : "495",
        "target" : "3244",
        "shared_name" : "Edith Sitwell (contributedTo) A Broadcast Anthology of Modern Poetry",
        "Attribute_1_year" : 1930,
        "shared_interaction" : "contributedTo",
        "name" : "Edith Sitwell (contributedTo) A Broadcast Anthology of Modern Poetry",
        "interaction" : "contributedTo",
        "certainty" : "definite",
        "SUID" : 3338,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "499",
        "source" : "495",
        "target" : "497",
        "shared_name" : "Edith Sitwell (authorOf) Poetry & Criticism",
        "Attribute_1_year" : 1925,
        "shared_interaction" : "authorOf",
        "name" : "Edith Sitwell (authorOf) Poetry & Criticism",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 499,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2380",
        "source" : "488",
        "target" : "2378",
        "shared_name" : "Herbert Read (authorOf) Mutations of the Phoenix",
        "Attribute_1_year" : 1923,
        "shared_interaction" : "authorOf",
        "name" : "Herbert Read (authorOf) Mutations of the Phoenix",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 2380,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "933",
        "source" : "488",
        "target" : "931",
        "shared_name" : "Herbert Read (authorOf) Phases of English Poetry",
        "Attribute_1_year" : 1928,
        "shared_interaction" : "authorOf",
        "name" : "Herbert Read (authorOf) Phases of English Poetry",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 933,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "492",
        "source" : "488",
        "target" : "490",
        "shared_name" : "Herbert Read (authorOf) In Retreat",
        "Attribute_1_year" : 1925,
        "shared_interaction" : "authorOf",
        "name" : "Herbert Read (authorOf) In Retreat",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 492,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4802",
        "source" : "481",
        "target" : "4797",
        "shared_name" : "William Plomer (editorOf) Selected Poems_4",
        "Attribute_1_year" : 1941,
        "shared_interaction" : "editorOf",
        "name" : "William Plomer (editorOf) Selected Poems_4",
        "interaction" : "editorOf",
        "certainty" : "definite",
        "SUID" : 4802,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3983",
        "source" : "481",
        "target" : "3940",
        "shared_name" : "William Plomer (contributedTo) New Country Prose and Poetry by the authors of New Signatures",
        "Attribute_1_year" : 1933,
        "shared_interaction" : "contributedTo",
        "name" : "William Plomer (contributedTo) New Country Prose and Poetry by the authors of New Signatures",
        "interaction" : "contributedTo",
        "certainty" : "definite",
        "SUID" : 3983,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3790",
        "source" : "481",
        "target" : "3761",
        "shared_name" : "William Plomer (contributedTo) New Signatures Poems by Several Hands",
        "Attribute_1_year" : 1932,
        "shared_interaction" : "contributedTo",
        "name" : "William Plomer (contributedTo) New Signatures Poems by Several Hands",
        "interaction" : "contributedTo",
        "certainty" : "definite",
        "SUID" : 3790,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3738",
        "source" : "481",
        "target" : "3736",
        "shared_name" : "William Plomer (authorOf) The Case is Altered",
        "Attribute_1_year" : 1932,
        "shared_interaction" : "authorOf",
        "name" : "William Plomer (authorOf) The Case is Altered",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 3738,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3513",
        "source" : "481",
        "target" : "3511",
        "shared_name" : "William Plomer (authorOf) Sado",
        "Attribute_1_year" : 1931,
        "shared_interaction" : "authorOf",
        "name" : "William Plomer (authorOf) Sado",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 3513,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3078",
        "source" : "481",
        "target" : "3076",
        "shared_name" : "William Plomer (authorOf) Paper Houses",
        "Attribute_1_year" : 1929,
        "shared_interaction" : "authorOf",
        "name" : "William Plomer (authorOf) Paper Houses",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 3078,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1917",
        "source" : "481",
        "target" : "1915",
        "shared_name" : "William Plomer (authorOf) Selected Poems_2",
        "Attribute_1_year" : 1940,
        "shared_interaction" : "authorOf",
        "name" : "William Plomer (authorOf) Selected Poems_2",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1917,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1436",
        "source" : "481",
        "target" : "1434",
        "shared_name" : "William Plomer (authorOf) The Fivefold Screen",
        "Attribute_1_year" : 1932,
        "shared_interaction" : "authorOf",
        "name" : "William Plomer (authorOf) The Fivefold Screen",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1436,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1090",
        "source" : "481",
        "target" : "1088",
        "shared_name" : "William Plomer (authorOf) The Family Tree",
        "Attribute_1_year" : 1929,
        "shared_interaction" : "authorOf",
        "name" : "William Plomer (authorOf) The Family Tree",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1090,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "800",
        "source" : "481",
        "target" : "798",
        "shared_name" : "William Plomer (authorOf) Notes for Poems",
        "Attribute_1_year" : 1927,
        "shared_interaction" : "authorOf",
        "name" : "William Plomer (authorOf) Notes for Poems",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 800,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "795",
        "source" : "481",
        "target" : "793",
        "shared_name" : "William Plomer (authorOf) I Speak of Africa",
        "Attribute_1_year" : 1927,
        "shared_interaction" : "authorOf",
        "name" : "William Plomer (authorOf) I Speak of Africa",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 795,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "485",
        "source" : "481",
        "target" : "483",
        "shared_name" : "William Plomer (authorOf) Turbott Wolfe",
        "Attribute_1_year" : 1925,
        "shared_interaction" : "authorOf",
        "name" : "William Plomer (authorOf) Turbott Wolfe",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 485,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "478",
        "source" : "474",
        "target" : "476",
        "shared_name" : "Willa Muir (authorOf) Women: An Inquiry",
        "Attribute_1_year" : 1925,
        "shared_interaction" : "authorOf",
        "name" : "Willa Muir (authorOf) Women: An Inquiry",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 478,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2680",
        "source" : "467",
        "target" : "2678",
        "shared_name" : "Edwin Muir (authorOf) Chorus of the Newly Dead",
        "Attribute_1_year" : 1926,
        "shared_interaction" : "authorOf",
        "name" : "Edwin Muir (authorOf) Chorus of the Newly Dead",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 2680,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "921",
        "source" : "467",
        "target" : "919",
        "shared_name" : "Edwin Muir (authorOf) The Structure of the Novel",
        "Attribute_1_year" : 1928,
        "shared_interaction" : "authorOf",
        "name" : "Edwin Muir (authorOf) The Structure of the Novel",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 921,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "740",
        "source" : "467",
        "target" : "738",
        "shared_name" : "Edwin Muir (authorOf) The Marionette",
        "Attribute_1_year" : 1927,
        "shared_interaction" : "authorOf",
        "name" : "Edwin Muir (authorOf) The Marionette",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 740,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "614",
        "source" : "467",
        "target" : "612",
        "shared_name" : "Edwin Muir (authorOf) Transition  Essays on Contemporary Literature",
        "Attribute_1_year" : 1926,
        "shared_interaction" : "authorOf",
        "name" : "Edwin Muir (authorOf) Transition  Essays on Contemporary Literature",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 614,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "471",
        "source" : "467",
        "target" : "469",
        "shared_name" : "Edwin Muir (authorOf) First Poems",
        "Attribute_1_year" : 1925,
        "shared_interaction" : "authorOf",
        "name" : "Edwin Muir (authorOf) First Poems",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 471,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "464",
        "source" : "460",
        "target" : "462",
        "shared_name" : "Alan Lubbock (authorOf) The Character of John Dryden",
        "Attribute_1_year" : 1925,
        "shared_interaction" : "authorOf",
        "name" : "Alan Lubbock (authorOf) The Character of John Dryden",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 464,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3505",
        "source" : "453",
        "target" : "3503",
        "shared_name" : "C. H. B. Kitchin (authorOf) The Sensitive One",
        "Attribute_1_year" : 1931,
        "shared_interaction" : "authorOf",
        "name" : "C. H. B. Kitchin (authorOf) The Sensitive One",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 3505,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3053",
        "source" : "453",
        "target" : "3051",
        "shared_name" : "C. H. B. Kitchin (authorOf) Death of My Aunt",
        "Attribute_1_year" : 1929,
        "shared_interaction" : "authorOf",
        "name" : "C. H. B. Kitchin (authorOf) Death of My Aunt",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 3053,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1545",
        "source" : "453",
        "target" : "1543",
        "shared_name" : "C. H. B. Kitchin (authorOf) Crime at Christmas",
        "Attribute_1_year" : 1934,
        "shared_interaction" : "authorOf",
        "name" : "C. H. B. Kitchin (authorOf) Crime at Christmas",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1545,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "723",
        "source" : "453",
        "target" : "721",
        "shared_name" : "C. H. B. Kitchin (authorOf) Mr. Balcony",
        "Attribute_1_year" : 1927,
        "shared_interaction" : "authorOf",
        "name" : "C. H. B. Kitchin (authorOf) Mr. Balcony",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 723,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "457",
        "source" : "453",
        "target" : "455",
        "shared_name" : "C. H. B. Kitchin (authorOf) Streamers Waving",
        "Attribute_1_year" : 1925,
        "shared_interaction" : "authorOf",
        "name" : "C. H. B. Kitchin (authorOf) Streamers Waving",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 457,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4541",
        "source" : "441",
        "target" : "4533",
        "shared_name" : "John Maynard Keynes (contributedTo) Julian Bell Essays, Poems and Letters",
        "Attribute_1_year" : 1938,
        "shared_interaction" : "contributedTo",
        "name" : "John Maynard Keynes (contributedTo) Julian Bell Essays, Poems and Letters",
        "interaction" : "contributedTo",
        "certainty" : "definite",
        "SUID" : 4541,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3629",
        "source" : "441",
        "target" : "3624",
        "shared_name" : "John Maynard Keynes (wroteForewordFor) Unemployment Its Causes and Their Remedies",
        "Attribute_1_year" : 1931,
        "shared_interaction" : "wroteForewordFor",
        "name" : "John Maynard Keynes (wroteForewordFor) Unemployment Its Causes and Their Remedies",
        "interaction" : "wroteForewordFor",
        "certainty" : "definite",
        "SUID" : 3629,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2839",
        "source" : "441",
        "target" : "2834",
        "shared_name" : "John Maynard Keynes (coauthorWith) Books and the Public",
        "Attribute_1_year" : 1927,
        "shared_interaction" : "coauthorWith",
        "name" : "John Maynard Keynes (coauthorWith) Books and the Public",
        "interaction" : "coauthorWith",
        "certainty" : "definite",
        "SUID" : 2839,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2375",
        "source" : "441",
        "target" : "2365",
        "shared_name" : "John Maynard Keynes (dedicateeOf) Poems_9",
        "Attribute_1_year" : 1923,
        "shared_interaction" : "dedicateeOf",
        "name" : "John Maynard Keynes (dedicateeOf) Poems_9",
        "interaction" : "dedicateeOf",
        "certainty" : "definite",
        "SUID" : 2375,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "574",
        "source" : "441",
        "target" : "572",
        "shared_name" : "John Maynard Keynes (authorOf) The End of Laissez-Faire",
        "Attribute_1_year" : 1926,
        "shared_interaction" : "authorOf",
        "name" : "John Maynard Keynes (authorOf) The End of Laissez-Faire",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 574,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "450",
        "source" : "441",
        "target" : "448",
        "shared_name" : "John Maynard Keynes (authorOf) A Short View of Russia",
        "Attribute_1_year" : 1925,
        "shared_interaction" : "authorOf",
        "name" : "John Maynard Keynes (authorOf) A Short View of Russia",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 450,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "445",
        "source" : "441",
        "target" : "443",
        "shared_name" : "John Maynard Keynes (authorOf) The Economic Consequences of Mr. Churchill",
        "Attribute_1_year" : 1925,
        "shared_interaction" : "authorOf",
        "name" : "John Maynard Keynes (authorOf) The Economic Consequences of Mr. Churchill",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 445,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1709",
        "source" : "434",
        "target" : "1707",
        "shared_name" : "Kathleen E. Innes (authorOf) The League of Nations The complete story told for young people",
        "Attribute_1_year" : 1936,
        "shared_interaction" : "authorOf",
        "name" : "Kathleen E. Innes (authorOf) The League of Nations The complete story told for young people",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1709,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1044",
        "source" : "434",
        "target" : "1042",
        "shared_name" : "Kathleen E. Innes (authorOf) The Reign of Law A Short and Simple Introduction to the Work of the Permanent Court of International Justice",
        "Attribute_1_year" : 1929,
        "shared_interaction" : "authorOf",
        "name" : "Kathleen E. Innes (authorOf) The Reign of Law A Short and Simple Introduction to the Work of the Permanent Court of International Justice",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1044,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "701",
        "source" : "434",
        "target" : "699",
        "shared_name" : "Kathleen E. Innes (authorOf) The League of Nations and the World's Workers An Introduction to the WOrk of the International Labour Organisation",
        "Attribute_1_year" : 1927,
        "shared_interaction" : "authorOf",
        "name" : "Kathleen E. Innes (authorOf) The League of Nations and the World's Workers An Introduction to the WOrk of the International Labour Organisation",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 701,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "562",
        "source" : "434",
        "target" : "560",
        "shared_name" : "Kathleen E. Innes (authorOf) How the League of Nations Works Told for Young People",
        "Attribute_1_year" : 1926,
        "shared_interaction" : "authorOf",
        "name" : "Kathleen E. Innes (authorOf) How the League of Nations Works Told for Young People",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 562,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "438",
        "source" : "434",
        "target" : "436",
        "shared_name" : "Kathleen E. Innes (authorOf) The Story of The League of Nations Told for Young People",
        "Attribute_1_year" : 1925,
        "shared_interaction" : "authorOf",
        "name" : "Kathleen E. Innes (authorOf) The Story of The League of Nations Told for Young People",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 438,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "431",
        "source" : "427",
        "target" : "429",
        "shared_name" : "Jane Ellen Harrison (authorOf) Reminiscences of a Student's Life",
        "Attribute_1_year" : 1925,
        "shared_interaction" : "authorOf",
        "name" : "Jane Ellen Harrison (authorOf) Reminiscences of a Student's Life",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 431,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "419",
        "source" : "415",
        "target" : "417",
        "shared_name" : "Barrington Gates (authorOf) Poems_2",
        "Attribute_1_year" : 1925,
        "shared_interaction" : "authorOf",
        "name" : "Barrington Gates (authorOf) Poems_2",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 419,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4843",
        "source" : "408",
        "target" : "4833",
        "shared_name" : "Robert Graves (authorOf) Work in Hand",
        "Attribute_1_year" : 1942,
        "shared_interaction" : "authorOf",
        "name" : "Robert Graves (authorOf) Work in Hand",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4843,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3303",
        "source" : "408",
        "target" : "3244",
        "shared_name" : "Robert Graves (contributedTo) A Broadcast Anthology of Modern Poetry",
        "Attribute_1_year" : 1930,
        "shared_interaction" : "contributedTo",
        "name" : "Robert Graves (contributedTo) A Broadcast Anthology of Modern Poetry",
        "interaction" : "contributedTo",
        "certainty" : "definite",
        "SUID" : 3303,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2484",
        "source" : "408",
        "target" : "2479",
        "shared_name" : "Robert Graves (wroteIntroductionFor) Grace After Meat",
        "Attribute_1_year" : 1924,
        "shared_interaction" : "wroteIntroductionFor",
        "name" : "Robert Graves (wroteIntroductionFor) Grace After Meat",
        "interaction" : "wroteIntroductionFor",
        "certainty" : "definite",
        "SUID" : 2484,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2461",
        "source" : "408",
        "target" : "2459",
        "shared_name" : "Robert Graves (authorOf) Mock Beggar Hill",
        "Attribute_1_year" : 1924,
        "shared_interaction" : "authorOf",
        "name" : "Robert Graves (authorOf) Mock Beggar Hill",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 2461,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2336",
        "source" : "408",
        "target" : "2334",
        "shared_name" : "Robert Graves (authorOf) The Feather Bed",
        "Attribute_1_year" : 1923,
        "shared_interaction" : "authorOf",
        "name" : "Robert Graves (authorOf) The Feather Bed",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 2336,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "550",
        "source" : "408",
        "target" : "548",
        "shared_name" : "Robert Graves (authorOf) Impenetrability of the Proper Habit of English",
        "Attribute_1_year" : 1926,
        "shared_interaction" : "authorOf",
        "name" : "Robert Graves (authorOf) Impenetrability of the Proper Habit of English",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 550,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "545",
        "source" : "408",
        "target" : "543",
        "shared_name" : "Robert Graves (authorOf) Another Future of Poetry",
        "Attribute_1_year" : 1926,
        "shared_interaction" : "authorOf",
        "name" : "Robert Graves (authorOf) Another Future of Poetry",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 545,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "424",
        "source" : "408",
        "target" : "422",
        "shared_name" : "Robert Graves (authorOf) Contemporary Techniques of Poetry",
        "Attribute_1_year" : 1925,
        "shared_interaction" : "authorOf",
        "name" : "Robert Graves (authorOf) Contemporary Techniques of Poetry",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 424,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "412",
        "source" : "408",
        "target" : "410",
        "shared_name" : "Robert Graves (authorOf) The Marmosite's Miscellany",
        "Attribute_1_year" : 1925,
        "shared_interaction" : "authorOf",
        "name" : "Robert Graves (authorOf) The Marmosite's Miscellany",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 412,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3670",
        "source" : "401",
        "target" : "3668",
        "shared_name" : "Bonamy Dobree (authorOf) St. Martin's Summer",
        "Attribute_1_year" : 1932,
        "shared_interaction" : "authorOf",
        "name" : "Bonamy Dobree (authorOf) St. Martin's Summer",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 3670,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "528",
        "source" : "401",
        "target" : "526",
        "shared_name" : "Bonamy Dobree (authorOf) Rochester A Conversation between Sir George Etherege and Mr. Fitzjames",
        "Attribute_1_year" : 1926,
        "shared_interaction" : "authorOf",
        "name" : "Bonamy Dobree (authorOf) Rochester A Conversation between Sir George Etherege and Mr. Fitzjames",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 528,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "405",
        "source" : "401",
        "target" : "403",
        "shared_name" : "Bonamy Dobree (authorOf) Histriophane: A Dialogue on Dramatic Diction",
        "Attribute_1_year" : 1925,
        "shared_interaction" : "authorOf",
        "name" : "Bonamy Dobree (authorOf) Histriophane: A Dialogue on Dramatic Diction",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 405,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "398",
        "source" : "394",
        "target" : "396",
        "shared_name" : "Conrad Aiken (authorOf) Senlin: A Biogrpahy",
        "Attribute_1_year" : 1925,
        "shared_interaction" : "authorOf",
        "name" : "Conrad Aiken (authorOf) Senlin: A Biogrpahy",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 398,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "386",
        "source" : "382",
        "target" : "384",
        "shared_name" : "Leslie Stephen (authorOf) Some Early Impressions",
        "Attribute_1_year" : 1924,
        "shared_interaction" : "authorOf",
        "name" : "Leslie Stephen (authorOf) Some Early Impressions",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 386,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4117",
        "source" : "375",
        "target" : "4115",
        "shared_name" : "Vita Sackville-West (authorOf) The dark island",
        "Attribute_1_year" : 1934,
        "shared_interaction" : "authorOf",
        "name" : "Vita Sackville-West (authorOf) The dark island",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4117,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3803",
        "source" : "375",
        "target" : "3801",
        "shared_name" : "Vita Sackville-West (authorOf) Family History",
        "Attribute_1_year" : 1932,
        "shared_interaction" : "authorOf",
        "name" : "Vita Sackville-West (authorOf) Family History",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 3803,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3603",
        "source" : "375",
        "target" : "3601",
        "shared_name" : "Vita Sackville-West (authorOf) Sissinghurst",
        "Attribute_1_year" : 1931,
        "shared_interaction" : "authorOf",
        "name" : "Vita Sackville-West (authorOf) Sissinghurst",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 3603,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3595",
        "source" : "375",
        "target" : "3593",
        "shared_name" : "Vita Sackville-West (authorOf) All Passion Spent",
        "Attribute_1_year" : 1931,
        "shared_interaction" : "authorOf",
        "name" : "Vita Sackville-West (authorOf) All Passion Spent",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 3595,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3537",
        "source" : "375",
        "target" : "3532",
        "shared_name" : "Vita Sackville-West (translatedFor) Duineser Elegien Elegies from the Castle of Duino",
        "Attribute_1_year" : 1931,
        "shared_interaction" : "translatedFor",
        "name" : "Vita Sackville-West (translatedFor) Duineser Elegien Elegies from the Castle of Duino",
        "interaction" : "translatedFor",
        "certainty" : "definite",
        "SUID" : 3537,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3332",
        "source" : "375",
        "target" : "3244",
        "shared_name" : "Vita Sackville-West (contributedTo) A Broadcast Anthology of Modern Poetry",
        "Attribute_1_year" : 1930,
        "shared_interaction" : "contributedTo",
        "name" : "Vita Sackville-West (contributedTo) A Broadcast Anthology of Modern Poetry",
        "interaction" : "contributedTo",
        "certainty" : "definite",
        "SUID" : 3332,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1944",
        "source" : "375",
        "target" : "1942",
        "shared_name" : "Vita Sackville-West (authorOf) Selected Poems_3",
        "Attribute_1_year" : 1941,
        "shared_interaction" : "authorOf",
        "name" : "Vita Sackville-West (authorOf) Selected Poems_3",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1944,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1922",
        "source" : "375",
        "target" : "1920",
        "shared_name" : "Vita Sackville-West (authorOf) Country Notes in Wartime",
        "Attribute_1_year" : 1940,
        "shared_interaction" : "authorOf",
        "name" : "Vita Sackville-West (authorOf) Country Notes in Wartime",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1922,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1850",
        "source" : "375",
        "target" : "1848",
        "shared_name" : "Vita Sackville-West (authorOf) Solitude A Poem",
        "Attribute_1_year" : 1938,
        "shared_interaction" : "authorOf",
        "name" : "Vita Sackville-West (authorOf) Solitude A Poem",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1850,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1788",
        "source" : "375",
        "target" : "1786",
        "shared_name" : "Vita Sackville-West (authorOf) Pepita",
        "Attribute_1_year" : 1937,
        "shared_interaction" : "authorOf",
        "name" : "Vita Sackville-West (authorOf) Pepita",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1788,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1783",
        "source" : "375",
        "target" : "1781",
        "shared_name" : "Vita Sackville-West (authorOf) Joan of Arc",
        "Attribute_1_year" : 1937,
        "shared_interaction" : "authorOf",
        "name" : "Vita Sackville-West (authorOf) Joan of Arc",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1783,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1519",
        "source" : "375",
        "target" : "1517",
        "shared_name" : "Vita Sackville-West (authorOf) Collected Poems Volume One",
        "Attribute_1_year" : 1933,
        "shared_interaction" : "authorOf",
        "name" : "Vita Sackville-West (authorOf) Collected Poems Volume One",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1519,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1188",
        "source" : "375",
        "target" : "1186",
        "shared_name" : "Vita Sackville-West (authorOf) The Edwardians",
        "Attribute_1_year" : 1930,
        "shared_interaction" : "authorOf",
        "name" : "Vita Sackville-West (authorOf) The Edwardians",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1188,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1095",
        "source" : "375",
        "target" : "1093",
        "shared_name" : "Vita Sackville-West (authorOf) King's Daughter",
        "Attribute_1_year" : 1929,
        "shared_interaction" : "authorOf",
        "name" : "Vita Sackville-West (authorOf) King's Daughter",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1095,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "966",
        "source" : "375",
        "target" : "964",
        "shared_name" : "Vita Sackville-West (authorOf) Twelve Days An account of a journey across the Bakhtiari Mountains in South-western Persia",
        "Attribute_1_year" : 1928,
        "shared_interaction" : "authorOf",
        "name" : "Vita Sackville-West (authorOf) Twelve Days An account of a journey across the Bakhtiari Mountains in South-western Persia",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 966,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "626",
        "source" : "375",
        "target" : "624",
        "shared_name" : "Vita Sackville-West (authorOf) Passenger to Tehran",
        "Attribute_1_year" : 1926,
        "shared_interaction" : "authorOf",
        "name" : "Vita Sackville-West (authorOf) Passenger to Tehran",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 626,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "379",
        "source" : "375",
        "target" : "377",
        "shared_name" : "Vita Sackville-West (authorOf) Seducers in Ecuador",
        "Attribute_1_year" : 1924,
        "shared_interaction" : "authorOf",
        "name" : "Vita Sackville-West (authorOf) Seducers in Ecuador",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 379,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "759",
        "source" : "368",
        "target" : "757",
        "shared_name" : "Harold Nicolson (authorOf) The Development of English Biography",
        "Attribute_1_year" : 1927,
        "shared_interaction" : "authorOf",
        "name" : "Harold Nicolson (authorOf) The Development of English Biography",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 759,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "372",
        "source" : "368",
        "target" : "370",
        "shared_name" : "Harold Nicolson (authorOf) Jeanne de Hènaut",
        "Attribute_1_year" : 1924,
        "shared_interaction" : "authorOf",
        "name" : "Harold Nicolson (authorOf) Jeanne de Hènaut",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 372,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "365",
        "source" : "361",
        "target" : "363",
        "shared_name" : "F. M. Mayor (authorOf) The Rector's Daughter",
        "Attribute_1_year" : 1924,
        "shared_interaction" : "authorOf",
        "name" : "F. M. Mayor (authorOf) The Rector's Daughter",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 365,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "358",
        "source" : "354",
        "target" : "356",
        "shared_name" : "Coralie Hobson (authorOf) In Our Town",
        "Attribute_1_year" : 1924,
        "shared_interaction" : "authorOf",
        "name" : "Coralie Hobson (authorOf) In Our Town",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 358,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4201",
        "source" : "347",
        "target" : "4196",
        "shared_name" : "Roger Fry (translatedFor) Aesthetics and Psychology",
        "Attribute_1_year" : 1935,
        "shared_interaction" : "translatedFor",
        "name" : "Roger Fry (translatedFor) Aesthetics and Psychology",
        "interaction" : "translatedFor",
        "certainty" : "definite",
        "SUID" : 4201,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3081",
        "source" : "347",
        "target" : "3076",
        "shared_name" : "Roger Fry (designedJacketFor) Paper Houses",
        "Attribute_1_year" : 1929,
        "shared_interaction" : "designedJacketFor",
        "name" : "Roger Fry (designedJacketFor) Paper Houses",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 3081,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2829",
        "source" : "347",
        "target" : "2821",
        "shared_name" : "Roger Fry (wrotePrefaceFor) The Nature of Beauty in Art and Literature",
        "Attribute_1_year" : 1927,
        "shared_interaction" : "wrotePrefaceFor",
        "name" : "Roger Fry (wrotePrefaceFor) The Nature of Beauty in Art and Literature",
        "interaction" : "wrotePrefaceFor",
        "certainty" : "definite",
        "SUID" : 2829,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2826",
        "source" : "347",
        "target" : "2821",
        "shared_name" : "Roger Fry (translatedFor) The Nature of Beauty in Art and Literature",
        "Attribute_1_year" : 1927,
        "shared_interaction" : "translatedFor",
        "name" : "Roger Fry (translatedFor) The Nature of Beauty in Art and Literature",
        "interaction" : "translatedFor",
        "certainty" : "definite",
        "SUID" : 2826,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2784",
        "source" : "347",
        "target" : "2779",
        "shared_name" : "Roger Fry (illustratedFor) Cezanne A Study of His Development",
        "Attribute_1_year" : 1927,
        "shared_interaction" : "illustratedFor",
        "name" : "Roger Fry (illustratedFor) Cezanne A Study of His Development",
        "interaction" : "illustratedFor",
        "certainty" : "definite",
        "SUID" : 2784,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2781",
        "source" : "347",
        "target" : "2779",
        "shared_name" : "Roger Fry (authorOf) Cezanne A Study of His Development",
        "Attribute_1_year" : 1927,
        "shared_interaction" : "authorOf",
        "name" : "Roger Fry (authorOf) Cezanne A Study of His Development",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 2781,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2636",
        "source" : "347",
        "target" : "2628",
        "shared_name" : "Roger Fry (wroteIntroductionFor) Victorian Photographs of Famous Men & Fair Women",
        "Attribute_1_year" : 1926,
        "shared_interaction" : "wroteIntroductionFor",
        "name" : "Roger Fry (wroteIntroductionFor) Victorian Photographs of Famous Men & Fair Women",
        "interaction" : "wroteIntroductionFor",
        "certainty" : "definite",
        "SUID" : 2636,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2315",
        "source" : "347",
        "target" : "2269",
        "shared_name" : "Roger Fry (authorOf) Duncan Grant",
        "Attribute_1_year" : 1923,
        "shared_interaction" : "authorOf",
        "name" : "Roger Fry (authorOf) Duncan Grant",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 2315,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2312",
        "source" : "347",
        "target" : "2307",
        "shared_name" : "Roger Fry (designedJacketFor) A Sampler of Castile",
        "Attribute_1_year" : 1923,
        "shared_interaction" : "designedJacketFor",
        "name" : "Roger Fry (designedJacketFor) A Sampler of Castile",
        "interaction" : "designedJacketFor",
        "certainty" : "likely",
        "SUID" : 2312,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2309",
        "source" : "347",
        "target" : "2307",
        "shared_name" : "Roger Fry (authorOf) A Sampler of Castile",
        "Attribute_1_year" : 1923,
        "shared_interaction" : "authorOf",
        "name" : "Roger Fry (authorOf) A Sampler of Castile",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 2309,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2052",
        "source" : "347",
        "target" : "2050",
        "shared_name" : "Roger Fry (illustratedFor) Twelve Original Woodcuts",
        "Attribute_1_year" : 1921,
        "shared_interaction" : "illustratedFor",
        "name" : "Roger Fry (illustratedFor) Twelve Original Woodcuts",
        "interaction" : "illustratedFor",
        "certainty" : "definite",
        "SUID" : 2052,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "533",
        "source" : "347",
        "target" : "531",
        "shared_name" : "Roger Fry (authorOf) Art and Commerce",
        "Attribute_1_year" : 1926,
        "shared_interaction" : "authorOf",
        "name" : "Roger Fry (authorOf) Art and Commerce",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 533,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "351",
        "source" : "347",
        "target" : "349",
        "shared_name" : "Roger Fry (authorOf) The Artist and Psycho-Analysis",
        "Attribute_1_year" : 1924,
        "shared_interaction" : "authorOf",
        "name" : "Roger Fry (authorOf) The Artist and Psycho-Analysis",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 351,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "339",
        "source" : "335",
        "target" : "337",
        "shared_name" : "Alice Lowther (authorOf) When It was June",
        "Attribute_1_year" : 1923,
        "shared_interaction" : "authorOf",
        "name" : "Alice Lowther (authorOf) When It was June",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 339,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4112",
        "source" : "328",
        "target" : "4104",
        "shared_name" : "Ernest Jones (wrotePrefaceFor) The Riddle of the Sphinx or Human Origins",
        "Attribute_1_year" : 1934,
        "shared_interaction" : "wrotePrefaceFor",
        "name" : "Ernest Jones (wrotePrefaceFor) The Riddle of the Sphinx or Human Origins",
        "interaction" : "wrotePrefaceFor",
        "certainty" : "definite",
        "SUID" : 4112,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3865",
        "source" : "328",
        "target" : "3860",
        "shared_name" : "Ernest Jones (editorOf) New Introductory Lectures on Psycho-Analysis",
        "Attribute_1_year" : 1933,
        "shared_interaction" : "editorOf",
        "name" : "Ernest Jones (editorOf) New Introductory Lectures on Psycho-Analysis",
        "interaction" : "editorOf",
        "certainty" : "definite",
        "SUID" : 3865,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2721",
        "source" : "328",
        "target" : "2716",
        "shared_name" : "Ernest Jones (wroteIntroductionFor) Selected Papers of Karl Abraham",
        "Attribute_1_year" : 1927,
        "shared_interaction" : "wroteIntroductionFor",
        "name" : "Ernest Jones (wroteIntroductionFor) Selected Papers of Karl Abraham",
        "interaction" : "wroteIntroductionFor",
        "certainty" : "definite",
        "SUID" : 2721,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1293",
        "source" : "328",
        "target" : "1291",
        "shared_name" : "Ernest Jones (authorOf) On the Nightmare",
        "Attribute_1_year" : 1931,
        "shared_interaction" : "authorOf",
        "name" : "Ernest Jones (authorOf) On the Nightmare",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1293,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "332",
        "source" : "328",
        "target" : "330",
        "shared_name" : "Ernest Jones (authorOf) Essays in Applied Psycho-Analysis",
        "Attribute_1_year" : 1923,
        "shared_interaction" : "authorOf",
        "name" : "Ernest Jones (authorOf) Essays in Applied Psycho-Analysis",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 332,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4771",
        "source" : "318",
        "target" : "4769",
        "shared_name" : "E. M. Forster (authorOf) England's Pleasant Land A Pageant Play",
        "Attribute_1_year" : 1940,
        "shared_interaction" : "authorOf",
        "name" : "E. M. Forster (authorOf) England's Pleasant Land A Pageant Play",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4771,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4766",
        "source" : "318",
        "target" : "4761",
        "shared_name" : "E. M. Forster (quotedIn) Twilight in Delhi",
        "Attribute_1_year" : 1940,
        "shared_interaction" : "quotedIn",
        "name" : "E. M. Forster (quotedIn) Twilight in Delhi",
        "interaction" : "quotedIn",
        "certainty" : "definite",
        "SUID" : 4766,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4555",
        "source" : "318",
        "target" : "4533",
        "shared_name" : "E. M. Forster (contributedTo) Julian Bell Essays, Poems and Letters",
        "Attribute_1_year" : 1938,
        "shared_interaction" : "contributedTo",
        "name" : "E. M. Forster (contributedTo) Julian Bell Essays, Poems and Letters",
        "interaction" : "contributedTo",
        "certainty" : "definite",
        "SUID" : 4555,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2544",
        "source" : "318",
        "target" : "2542",
        "shared_name" : "E. M. Forster (authorOf) Anonymity An Enquiry",
        "Attribute_1_year" : 1925,
        "shared_interaction" : "authorOf",
        "name" : "E. M. Forster (authorOf) Anonymity An Enquiry",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 2544,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2534",
        "source" : "318",
        "target" : "2529",
        "shared_name" : "E. M. Forster (wroteIntroductionFor) Original Letters from India (1779-1815)",
        "Attribute_1_year" : 1925,
        "shared_interaction" : "wroteIntroductionFor",
        "name" : "E. M. Forster (wroteIntroductionFor) Original Letters from India (1779-1815)",
        "interaction" : "wroteIntroductionFor",
        "certainty" : "definite",
        "SUID" : 2534,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2293",
        "source" : "318",
        "target" : "2291",
        "shared_name" : "E. M. Forster (authorOf) Pharos and Pharillon",
        "Attribute_1_year" : 1923,
        "shared_interaction" : "authorOf",
        "name" : "E. M. Forster (authorOf) Pharos and Pharillon",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 2293,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1869",
        "source" : "318",
        "target" : "1867",
        "shared_name" : "E. M. Forster (authorOf) What I Believe",
        "Attribute_1_year" : 1939,
        "shared_interaction" : "authorOf",
        "name" : "E. M. Forster (authorOf) What I Believe",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1869,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1267",
        "source" : "318",
        "target" : "1265",
        "shared_name" : "E. M. Forster (authorOf) A Letter to Madan Blanchard",
        "Attribute_1_year" : 1931,
        "shared_interaction" : "authorOf",
        "name" : "E. M. Forster (authorOf) A Letter to Madan Blanchard",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1267,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "322",
        "source" : "318",
        "target" : "320",
        "shared_name" : "E. M. Forster (authorOf) The Story of the Siren",
        "Attribute_1_year" : 1920,
        "shared_interaction" : "authorOf",
        "name" : "E. M. Forster (authorOf) The Story of the Siren",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 322,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "310",
        "source" : "308",
        "target" : "294",
        "shared_name" : "Omega Workshops (providedEndpapersFor) Kew Gardens",
        "Attribute_1_year" : 1919,
        "shared_interaction" : "providedEndpapersFor",
        "name" : "Omega Workshops (providedEndpapersFor) Kew Gardens",
        "interaction" : "providedEndpapersFor",
        "certainty" : "likely",
        "SUID" : 310,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "282",
        "source" : "278",
        "target" : "280",
        "shared_name" : "J. Middleton Murray (authorOf) The Critic in Judgment or Belshazzar of Baronscourt",
        "Attribute_1_year" : 1919,
        "shared_interaction" : "authorOf",
        "name" : "J. Middleton Murray (authorOf) The Critic in Judgment or Belshazzar of Baronscourt",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 282,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2430",
        "source" : "268",
        "target" : "2416",
        "shared_name" : "Hope Mirrlees (translatedFor) The Life of the Archpriest Avvakum by Himself",
        "Attribute_1_year" : 1924,
        "shared_interaction" : "translatedFor",
        "name" : "Hope Mirrlees (translatedFor) The Life of the Archpriest Avvakum by Himself",
        "interaction" : "translatedFor",
        "certainty" : "definite",
        "SUID" : 2430,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "272",
        "source" : "268",
        "target" : "270",
        "shared_name" : "Hope Mirrlees (authorOf) Paris A Poem",
        "Attribute_1_year" : 1919,
        "shared_interaction" : "authorOf",
        "name" : "Hope Mirrlees (authorOf) Paris A Poem",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 272,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3290",
        "source" : "255",
        "target" : "3244",
        "shared_name" : "T. S. Eliot (contributedTo) A Broadcast Anthology of Modern Poetry",
        "Attribute_1_year" : 1930,
        "shared_interaction" : "contributedTo",
        "name" : "T. S. Eliot (contributedTo) A Broadcast Anthology of Modern Poetry",
        "interaction" : "contributedTo",
        "certainty" : "definite",
        "SUID" : 3290,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2279",
        "source" : "255",
        "target" : "2277",
        "shared_name" : "T. S. Eliot (authorOf) The Waste Land",
        "Attribute_1_year" : 1923,
        "shared_interaction" : "authorOf",
        "name" : "T. S. Eliot (authorOf) The Waste Land",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 2279,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "344",
        "source" : "255",
        "target" : "342",
        "shared_name" : "T. S. Eliot (authorOf) Homage to John Dryden: Three Essays on the Poetry of the Seventeenth Century",
        "Attribute_1_year" : 1924,
        "shared_interaction" : "authorOf",
        "name" : "T. S. Eliot (authorOf) Homage to John Dryden: Three Essays on the Poetry of the Seventeenth Century",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 344,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "259",
        "source" : "255",
        "target" : "257",
        "shared_name" : "T. S. Eliot (authorOf) Poems_1",
        "Attribute_1_year" : 1919,
        "shared_interaction" : "authorOf",
        "name" : "T. S. Eliot (authorOf) Poems_1",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 259,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2123",
        "source" : "245",
        "target" : "2108",
        "shared_name" : "The Prompt Press (outsourcePrinterOf) Monday or Tuesday",
        "Attribute_1_year" : 1921,
        "shared_interaction" : "outsourcePrinterOf",
        "name" : "The Prompt Press (outsourcePrinterOf) Monday or Tuesday",
        "interaction" : "outsourcePrinterOf",
        "certainty" : "definite",
        "SUID" : 2123,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2120",
        "source" : "245",
        "target" : "2108",
        "shared_name" : "The Prompt Press (typesetFor) Monday or Tuesday",
        "Attribute_1_year" : 1921,
        "shared_interaction" : "typesetFor",
        "name" : "The Prompt Press (typesetFor) Monday or Tuesday",
        "interaction" : "typesetFor",
        "certainty" : "definite",
        "SUID" : 2120,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "285",
        "source" : "245",
        "target" : "280",
        "shared_name" : "The Prompt Press (outsourcePrinterOf) The Critic in Judgment or Belshazzar of Baronscourt",
        "Attribute_1_year" : 1919,
        "shared_interaction" : "outsourcePrinterOf",
        "name" : "The Prompt Press (outsourcePrinterOf) The Critic in Judgment or Belshazzar of Baronscourt",
        "interaction" : "outsourcePrinterOf",
        "certainty" : "definite",
        "SUID" : 285,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "247",
        "source" : "245",
        "target" : "221",
        "shared_name" : "The Prompt Press (outsourcePrinterOf) Prelude",
        "Attribute_1_year" : 1918,
        "shared_interaction" : "outsourcePrinterOf",
        "name" : "The Prompt Press (outsourcePrinterOf) Prelude",
        "interaction" : "outsourcePrinterOf",
        "certainty" : "definite",
        "SUID" : 247,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "239",
        "source" : "237",
        "target" : "221",
        "shared_name" : "Barbara Hiles (Bagenal) (typesetFor) Prelude",
        "Attribute_1_year" : 1918,
        "shared_interaction" : "typesetFor",
        "name" : "Barbara Hiles (Bagenal) (typesetFor) Prelude",
        "interaction" : "typesetFor",
        "certainty" : "speculative",
        "SUID" : 239,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "234",
        "source" : "232",
        "target" : "221",
        "shared_name" : "J. D. Fergusson (illustratedFor) Prelude",
        "Attribute_1_year" : 1918,
        "shared_interaction" : "illustratedFor",
        "name" : "J. D. Fergusson (illustratedFor) Prelude",
        "interaction" : "illustratedFor",
        "certainty" : "definite",
        "SUID" : 234,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4036",
        "source" : "219",
        "target" : "4031",
        "shared_name" : "Katherine Mansfield (translatedFor) Reminiscences of Tolstoy, Chekhov and Andrew",
        "Attribute_1_year" : 1934,
        "shared_interaction" : "translatedFor",
        "name" : "Katherine Mansfield (translatedFor) Reminiscences of Tolstoy, Chekhov and Andrew",
        "interaction" : "translatedFor",
        "certainty" : "definite",
        "SUID" : 4036,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "223",
        "source" : "219",
        "target" : "221",
        "shared_name" : "Katherine Mansfield (authorOf) Prelude",
        "Attribute_1_year" : 1918,
        "shared_interaction" : "authorOf",
        "name" : "Katherine Mansfield (authorOf) Prelude",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 223,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "216",
        "source" : "214",
        "target" : "197",
        "shared_name" : "Dora Carrington (illustratedFor) Two Stories",
        "Attribute_1_year" : 1917,
        "shared_interaction" : "illustratedFor",
        "name" : "Dora Carrington (illustratedFor) Two Stories",
        "interaction" : "illustratedFor",
        "certainty" : "definite",
        "SUID" : 216,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "252",
        "source" : "193",
        "target" : "250",
        "shared_name" : "C. N. Sidney Woolf (authorOf) Poems by C.N. Sidney Woolf",
        "Attribute_1_year" : 1918,
        "shared_interaction" : "authorOf",
        "name" : "C. N. Sidney Woolf (authorOf) Poems by C.N. Sidney Woolf",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 252,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "5034",
        "source" : "189",
        "target" : "5029",
        "shared_name" : "Vanessa Bell (designedJacketFor) Back",
        "Attribute_1_year" : 1946,
        "shared_interaction" : "designedJacketFor",
        "name" : "Vanessa Bell (designedJacketFor) Back",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 5034,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4928",
        "source" : "189",
        "target" : "4923",
        "shared_name" : "Vanessa Bell (designedJacketFor) A Haunted House and Other Short Stories",
        "Attribute_1_year" : 1943,
        "shared_interaction" : "designedJacketFor",
        "name" : "Vanessa Bell (designedJacketFor) A Haunted House and Other Short Stories",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 4928,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4871",
        "source" : "189",
        "target" : "4866",
        "shared_name" : "Vanessa Bell (designedJacketFor) The Death of the Moth and Other Essays",
        "Attribute_1_year" : 1942,
        "shared_interaction" : "designedJacketFor",
        "name" : "Vanessa Bell (designedJacketFor) The Death of the Moth and Other Essays",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 4871,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4816",
        "source" : "189",
        "target" : "4811",
        "shared_name" : "Vanessa Bell (designedJacketFor) Between the Acts",
        "Attribute_1_year" : 1941,
        "shared_interaction" : "designedJacketFor",
        "name" : "Vanessa Bell (designedJacketFor) Between the Acts",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 4816,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4792",
        "source" : "189",
        "target" : "4787",
        "shared_name" : "Vanessa Bell (illustratedJacketFor) Roger Fry A Biography",
        "Attribute_1_year" : 1940,
        "shared_interaction" : "illustratedJacketFor",
        "name" : "Vanessa Bell (illustratedJacketFor) Roger Fry A Biography",
        "interaction" : "illustratedJacketFor",
        "certainty" : "definite",
        "SUID" : 4792,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4637",
        "source" : "189",
        "target" : "4632",
        "shared_name" : "Vanessa Bell (designedJacketFor) Amber Innocent",
        "Attribute_1_year" : 1939,
        "shared_interaction" : "designedJacketFor",
        "name" : "Vanessa Bell (designedJacketFor) Amber Innocent",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 4637,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4619",
        "source" : "189",
        "target" : "4614",
        "shared_name" : "Vanessa Bell (designedJacketFor) Three Guineas",
        "Attribute_1_year" : 1938,
        "shared_interaction" : "designedJacketFor",
        "name" : "Vanessa Bell (designedJacketFor) Three Guineas",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 4619,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4611",
        "source" : "189",
        "target" : "4606",
        "shared_name" : "Vanessa Bell (designedJacketFor) Journey to the Border",
        "Attribute_1_year" : 1938,
        "shared_interaction" : "designedJacketFor",
        "name" : "Vanessa Bell (designedJacketFor) Journey to the Border",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 4611,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4518",
        "source" : "189",
        "target" : "4513",
        "shared_name" : "Vanessa Bell (designedJacketFor) The Years",
        "Attribute_1_year" : 1937,
        "shared_interaction" : "designedJacketFor",
        "name" : "Vanessa Bell (designedJacketFor) The Years",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 4518,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4389",
        "source" : "189",
        "target" : "4384",
        "shared_name" : "Vanessa Bell (designedJacketFor) Lights Are Bright",
        "Attribute_1_year" : 1936,
        "shared_interaction" : "designedJacketFor",
        "name" : "Vanessa Bell (designedJacketFor) Lights Are Bright",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 4389,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4285",
        "source" : "189",
        "target" : "4280",
        "shared_name" : "Vanessa Bell (designedJacketFor) Chase of the Wild Goose The story of Lady Eleanor Butler and Miss Sarah Ponsonby, known as the Ladies of Llangollen",
        "Attribute_1_year" : 1936,
        "shared_interaction" : "designedJacketFor",
        "name" : "Vanessa Bell (designedJacketFor) Chase of the Wild Goose The story of Lady Eleanor Butler and Miss Sarah Ponsonby, known as the Ladies of Llangollen",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 4285,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4237",
        "source" : "189",
        "target" : "4232",
        "shared_name" : "Vanessa Bell (designedJacketFor) Change Your Sky",
        "Attribute_1_year" : 1935,
        "shared_interaction" : "designedJacketFor",
        "name" : "Vanessa Bell (designedJacketFor) Change Your Sky",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 4237,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4164",
        "source" : "189",
        "target" : "4159",
        "shared_name" : "Vanessa Bell (designedJacketFor) Funeral March of a Marionette Charlotte of Albany",
        "Attribute_1_year" : 1935,
        "shared_interaction" : "designedJacketFor",
        "name" : "Vanessa Bell (designedJacketFor) Funeral March of a Marionette Charlotte of Albany",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 4164,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4142",
        "source" : "189",
        "target" : "4137",
        "shared_name" : "Vanessa Bell (designedCoverFor) Walter Sickert A Conversation",
        "Attribute_1_year" : 1934,
        "shared_interaction" : "designedCoverFor",
        "name" : "Vanessa Bell (designedCoverFor) Walter Sickert A Conversation",
        "interaction" : "designedCoverFor",
        "certainty" : "definite",
        "SUID" : 4142,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4018",
        "source" : "189",
        "target" : "4013",
        "shared_name" : "Vanessa Bell (designedJacketFor) Charles Lamb His Life Recorded by his Contemporaries",
        "Attribute_1_year" : 1934,
        "shared_interaction" : "designedJacketFor",
        "name" : "Vanessa Bell (designedJacketFor) Charles Lamb His Life Recorded by his Contemporaries",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 4018,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4010",
        "source" : "189",
        "target" : "4005",
        "shared_name" : "Vanessa Bell (illustratedFor) Flush A Biography",
        "Attribute_1_year" : 1933,
        "shared_interaction" : "illustratedFor",
        "name" : "Vanessa Bell (illustratedFor) Flush A Biography",
        "interaction" : "illustratedFor",
        "certainty" : "definite",
        "SUID" : 4010,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3837",
        "source" : "189",
        "target" : "3832",
        "shared_name" : "Vanessa Bell (designedJacketFor) The Common Reader Second Series",
        "Attribute_1_year" : 1932,
        "shared_interaction" : "designedJacketFor",
        "name" : "Vanessa Bell (designedJacketFor) The Common Reader Second Series",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 3837,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3647",
        "source" : "189",
        "target" : "3642",
        "shared_name" : "Vanessa Bell (designedJacketFor) The Waves",
        "Attribute_1_year" : 1931,
        "shared_interaction" : "designedJacketFor",
        "name" : "Vanessa Bell (designedJacketFor) The Waves",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 3647,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3378",
        "source" : "189",
        "target" : "3364",
        "shared_name" : "Vanessa Bell (designedJacketFor) On Being Ill",
        "Attribute_1_year" : 1930,
        "shared_interaction" : "designedJacketFor",
        "name" : "Vanessa Bell (designedJacketFor) On Being Ill",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 3378,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3120",
        "source" : "189",
        "target" : "1124",
        "shared_name" : "Vanessa Bell (designedJacketFor) A Room of One's Own",
        "Attribute_1_year" : 1929,
        "shared_interaction" : "designedJacketFor",
        "name" : "Vanessa Bell (designedJacketFor) A Room of One's Own",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 3120,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3019",
        "source" : "189",
        "target" : "3004",
        "shared_name" : "Vanessa Bell (designedCoverFor) Cambridge Poetry 1929",
        "Attribute_1_year" : 1929,
        "shared_interaction" : "designedCoverFor",
        "Column2" : "This book also has a long list of contributors but that might not be worth listing.",
        "name" : "Vanessa Bell (designedCoverFor) Cambridge Poetry 1929",
        "interaction" : "designedCoverFor",
        "certainty" : "definite",
        "SUID" : 3019,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2902",
        "source" : "189",
        "target" : "294",
        "shared_name" : "Vanessa Bell (illustratedFor) Kew Gardens",
        "Attribute_1_year" : 1927,
        "shared_interaction" : "illustratedFor",
        "name" : "Vanessa Bell (illustratedFor) Kew Gardens",
        "interaction" : "illustratedFor",
        "certainty" : "definite",
        "SUID" : 2902,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2896",
        "source" : "189",
        "target" : "2891",
        "shared_name" : "Vanessa Bell (designedJacketFor) To the Lighthouse",
        "Attribute_1_year" : 1927,
        "shared_interaction" : "designedJacketFor",
        "name" : "Vanessa Bell (designedJacketFor) To the Lighthouse",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 2896,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2599",
        "source" : "189",
        "target" : "2594",
        "shared_name" : "Vanessa Bell (designedJacketFor) Mrs. Dalloway",
        "Attribute_1_year" : 1925,
        "shared_interaction" : "designedJacketFor",
        "name" : "Vanessa Bell (designedJacketFor) Mrs. Dalloway",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 2599,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2591",
        "source" : "189",
        "target" : "2583",
        "shared_name" : "Vanessa Bell (designedCoverFor) The Common Reader",
        "Attribute_1_year" : 1925,
        "shared_interaction" : "designedCoverFor",
        "name" : "Vanessa Bell (designedCoverFor) The Common Reader",
        "interaction" : "designedCoverFor",
        "certainty" : "definite",
        "SUID" : 2591,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2588",
        "source" : "189",
        "target" : "2583",
        "shared_name" : "Vanessa Bell (designedJacketFor) The Common Reader",
        "Attribute_1_year" : 1925,
        "shared_interaction" : "designedJacketFor",
        "name" : "Vanessa Bell (designedJacketFor) The Common Reader",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 2588,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2547",
        "source" : "189",
        "target" : "2542",
        "shared_name" : "Vanessa Bell (illustratedFor) Anonymity An Enquiry",
        "Attribute_1_year" : 1925,
        "shared_interaction" : "illustratedFor",
        "name" : "Vanessa Bell (illustratedFor) Anonymity An Enquiry",
        "interaction" : "illustratedFor",
        "certainty" : "definite",
        "SUID" : 2547,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2274",
        "source" : "189",
        "target" : "2258",
        "shared_name" : "Vanessa Bell (illustratedFor) The Legend of Monte Della Sibilla or Le Paradis de la Reine Sibille",
        "Attribute_1_year" : 1923,
        "shared_interaction" : "illustratedFor",
        "name" : "Vanessa Bell (illustratedFor) The Legend of Monte Della Sibilla or Le Paradis de la Reine Sibille",
        "interaction" : "illustratedFor",
        "certainty" : "definite",
        "SUID" : 2274,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2255",
        "source" : "189",
        "target" : "2250",
        "shared_name" : "Vanessa Bell (designedJacketFor) Jacob's Room",
        "Attribute_1_year" : 1922,
        "shared_interaction" : "designedJacketFor",
        "name" : "Vanessa Bell (designedJacketFor) Jacob's Room",
        "interaction" : "designedJacketFor",
        "certainty" : "definite",
        "SUID" : 2255,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2126",
        "source" : "189",
        "target" : "2108",
        "shared_name" : "Vanessa Bell (designedPaperBoardsFor) Monday or Tuesday",
        "Attribute_1_year" : 1921,
        "shared_interaction" : "designedPaperBoardsFor",
        "name" : "Vanessa Bell (designedPaperBoardsFor) Monday or Tuesday",
        "interaction" : "designedPaperBoardsFor",
        "certainty" : "definite",
        "SUID" : 2126,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2113",
        "source" : "189",
        "target" : "2108",
        "shared_name" : "Vanessa Bell (illustratedFor) Monday or Tuesday",
        "Attribute_1_year" : 1921,
        "shared_interaction" : "illustratedFor",
        "Column" : "woodcuts",
        "name" : "Vanessa Bell (illustratedFor) Monday or Tuesday",
        "interaction" : "illustratedFor",
        "certainty" : "definite",
        "SUID" : 2113,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "305",
        "source" : "189",
        "target" : "294",
        "shared_name" : "Vanessa Bell (illustratedFor) Kew Gardens",
        "Attribute_1_year" : 1919,
        "shared_interaction" : "illustratedFor",
        "name" : "Vanessa Bell (illustratedFor) Kew Gardens",
        "interaction" : "illustratedFor",
        "certainty" : "definite",
        "SUID" : 305,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4756",
        "source" : "185",
        "target" : "4751",
        "shared_name" : "Leonard Woolf (wroteNoteFor) Reviewing",
        "Attribute_1_year" : 1939,
        "shared_interaction" : "wroteNoteFor",
        "name" : "Leonard Woolf (wroteNoteFor) Reviewing",
        "interaction" : "wroteNoteFor",
        "certainty" : "definite",
        "SUID" : 4756,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4745",
        "source" : "185",
        "target" : "4743",
        "shared_name" : "Leonard Woolf (authorOf) After the Deluge A Study of Communal Psychology Vol. II 1830 & 1832",
        "Attribute_1_year" : 1939,
        "shared_interaction" : "authorOf",
        "name" : "Leonard Woolf (authorOf) After the Deluge A Study of Communal Psychology Vol. II 1830 & 1832",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4745,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4242",
        "source" : "185",
        "target" : "4240",
        "shared_name" : "Leonard Woolf (authorOf) Quack, Quack!",
        "Attribute_1_year" : 1935,
        "shared_interaction" : "authorOf",
        "name" : "Leonard Woolf (authorOf) Quack, Quack!",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4242,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4042",
        "source" : "185",
        "target" : "4031",
        "shared_name" : "Leonard Woolf (translatedFor) Reminiscences of Tolstoy, Chekhov and Andrew",
        "Attribute_1_year" : 1934,
        "shared_interaction" : "translatedFor",
        "name" : "Leonard Woolf (translatedFor) Reminiscences of Tolstoy, Chekhov and Andrew",
        "interaction" : "translatedFor",
        "certainty" : "definite",
        "SUID" : 4042,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3826",
        "source" : "185",
        "target" : "3821",
        "shared_name" : "Leonard Woolf (printedFor) Jupiter and the Nun",
        "Attribute_1_year" : 1932,
        "shared_interaction" : "printedFor",
        "Column2" : "The Last book hand-printed by the Woolfs",
        "name" : "Leonard Woolf (printedFor) Jupiter and the Nun",
        "interaction" : "printedFor",
        "certainty" : "definite",
        "SUID" : 3826,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3606",
        "source" : "185",
        "target" : "3601",
        "shared_name" : "Leonard Woolf (printedFor) Sissinghurst",
        "Attribute_1_year" : 1931,
        "shared_interaction" : "printedFor",
        "name" : "Leonard Woolf (printedFor) Sissinghurst",
        "interaction" : "printedFor",
        "certainty" : "definite",
        "SUID" : 3606,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3369",
        "source" : "185",
        "target" : "3364",
        "shared_name" : "Leonard Woolf (printedFor) On Being Ill",
        "Attribute_1_year" : 1930,
        "shared_interaction" : "printedFor",
        "name" : "Leonard Woolf (printedFor) On Being Ill",
        "interaction" : "printedFor",
        "certainty" : "definite",
        "SUID" : 3369,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2961",
        "source" : "185",
        "target" : "2956",
        "shared_name" : "Leonard Woolf (printedFor) A Flying Scroll",
        "Attribute_1_year" : 1928,
        "shared_interaction" : "printedFor",
        "name" : "Leonard Woolf (printedFor) A Flying Scroll",
        "interaction" : "printedFor",
        "certainty" : "definite",
        "SUID" : 2961,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2885",
        "source" : "185",
        "target" : "2880",
        "shared_name" : "Leonard Woolf (printedFor) Voltaire A Biographical Fantasy",
        "Attribute_1_year" : 1927,
        "shared_interaction" : "printedFor",
        "name" : "Leonard Woolf (printedFor) Voltaire A Biographical Fantasy",
        "interaction" : "printedFor",
        "certainty" : "definite",
        "SUID" : 2885,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2857",
        "source" : "185",
        "target" : "2834",
        "shared_name" : "Leonard Woolf (coauthorWith) Books and the Public",
        "Attribute_1_year" : 1927,
        "shared_interaction" : "coauthorWith",
        "name" : "Leonard Woolf (coauthorWith) Books and the Public",
        "interaction" : "coauthorWith",
        "certainty" : "definite",
        "SUID" : 2857,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2696",
        "source" : "185",
        "target" : "2691",
        "shared_name" : "Leonard Woolf (printedFor) April Morning",
        "Attribute_1_year" : 1926,
        "shared_interaction" : "printedFor",
        "name" : "Leonard Woolf (printedFor) April Morning",
        "interaction" : "printedFor",
        "certainty" : "definite",
        "SUID" : 2696,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2683",
        "source" : "185",
        "target" : "2678",
        "shared_name" : "Leonard Woolf (printedFor) Chorus of the Newly Dead",
        "Attribute_1_year" : 1926,
        "shared_interaction" : "printedFor",
        "name" : "Leonard Woolf (printedFor) Chorus of the Newly Dead",
        "interaction" : "printedFor",
        "certainty" : "definite",
        "SUID" : 2683,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2669",
        "source" : "185",
        "target" : "2664",
        "shared_name" : "Leonard Woolf (printedFor) Martha Wish-You-Ill",
        "Attribute_1_year" : 1926,
        "shared_interaction" : "printedFor",
        "name" : "Leonard Woolf (printedFor) Martha Wish-You-Ill",
        "interaction" : "printedFor",
        "certainty" : "definite",
        "SUID" : 2669,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2577",
        "source" : "185",
        "target" : "2572",
        "shared_name" : "Leonard Woolf (printedFor) Poems and Fables",
        "Attribute_1_year" : 1925,
        "shared_interaction" : "printedFor",
        "name" : "Leonard Woolf (printedFor) Poems and Fables",
        "interaction" : "printedFor",
        "certainty" : "definite",
        "SUID" : 2577,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2566",
        "source" : "185",
        "target" : "2561",
        "shared_name" : "Leonard Woolf (printedFor) Russet and Taffeta",
        "Attribute_1_year" : 1925,
        "shared_interaction" : "printedFor",
        "name" : "Leonard Woolf (printedFor) Russet and Taffeta",
        "interaction" : "printedFor",
        "certainty" : "definite",
        "SUID" : 2566,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2555",
        "source" : "185",
        "target" : "2550",
        "shared_name" : "Leonard Woolf (printedFor) Songs of Salvation Sin & Satire",
        "Attribute_1_year" : 1925,
        "shared_interaction" : "printedFor",
        "name" : "Leonard Woolf (printedFor) Songs of Salvation Sin & Satire",
        "interaction" : "printedFor",
        "certainty" : "definite",
        "SUID" : 2555,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2510",
        "source" : "185",
        "target" : "2505",
        "shared_name" : "Leonard Woolf (printedFor) Parallax",
        "Attribute_1_year" : 1925,
        "shared_interaction" : "printedFor",
        "name" : "Leonard Woolf (printedFor) Parallax",
        "interaction" : "printedFor",
        "certainty" : "definite",
        "SUID" : 2510,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2487",
        "source" : "185",
        "target" : "2479",
        "shared_name" : "Leonard Woolf (printedFor) Grace After Meat",
        "Attribute_1_year" : 1924,
        "shared_interaction" : "printedFor",
        "name" : "Leonard Woolf (printedFor) Grace After Meat",
        "interaction" : "printedFor",
        "certainty" : "definite",
        "SUID" : 2487,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2443",
        "source" : "185",
        "target" : "2438",
        "shared_name" : "Leonard Woolf (printedFor) Henry James at Work",
        "Attribute_1_year" : 1924,
        "shared_interaction" : "printedFor",
        "name" : "Leonard Woolf (printedFor) Henry James at Work",
        "interaction" : "printedFor",
        "certainty" : "definite",
        "SUID" : 2443,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2383",
        "source" : "185",
        "target" : "2378",
        "shared_name" : "Leonard Woolf (printedFor) Mutations of the Phoenix",
        "Attribute_1_year" : 1923,
        "shared_interaction" : "printedFor",
        "name" : "Leonard Woolf (printedFor) Mutations of the Phoenix",
        "interaction" : "printedFor",
        "certainty" : "definite",
        "SUID" : 2383,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2357",
        "source" : "185",
        "target" : "2352",
        "shared_name" : "Leonard Woolf (printedFor) To a Proud Phantom",
        "Attribute_1_year" : 1923,
        "shared_interaction" : "printedFor",
        "name" : "Leonard Woolf (printedFor) To a Proud Phantom",
        "interaction" : "printedFor",
        "certainty" : "definite",
        "SUID" : 2357,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2344",
        "source" : "185",
        "target" : "2334",
        "shared_name" : "Leonard Woolf (printedFor) The Feather Bed",
        "Attribute_1_year" : 1923,
        "shared_interaction" : "printedFor",
        "name" : "Leonard Woolf (printedFor) The Feather Bed",
        "interaction" : "printedFor",
        "certainty" : "definite",
        "SUID" : 2344,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2296",
        "source" : "185",
        "target" : "2291",
        "shared_name" : "Leonard Woolf (printedFor) Pharos and Pharillon",
        "Attribute_1_year" : 1923,
        "shared_interaction" : "printedFor",
        "name" : "Leonard Woolf (printedFor) Pharos and Pharillon",
        "interaction" : "printedFor",
        "certainty" : "definite",
        "SUID" : 2296,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2282",
        "source" : "185",
        "target" : "2277",
        "shared_name" : "Leonard Woolf (printedFor) The Waste Land",
        "Attribute_1_year" : 1923,
        "shared_interaction" : "printedFor",
        "name" : "Leonard Woolf (printedFor) The Waste Land",
        "interaction" : "printedFor",
        "certainty" : "definite",
        "SUID" : 2282,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2263",
        "source" : "185",
        "target" : "2258",
        "shared_name" : "Leonard Woolf (printedFor) The Legend of Monte Della Sibilla or Le Paradis de la Reine Sibille",
        "Attribute_1_year" : 1923,
        "shared_interaction" : "printedFor",
        "name" : "Leonard Woolf (printedFor) The Legend of Monte Della Sibilla or Le Paradis de la Reine Sibille",
        "interaction" : "printedFor",
        "certainty" : "definite",
        "SUID" : 2263,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2247",
        "source" : "185",
        "target" : "2234",
        "shared_name" : "Leonard Woolf (translatedFor) The Autobiography of Countess Sophie Tolstoi",
        "Attribute_1_year" : 1922,
        "shared_interaction" : "translatedFor",
        "name" : "Leonard Woolf (translatedFor) The Autobiography of Countess Sophie Tolstoi",
        "interaction" : "translatedFor",
        "certainty" : "definite",
        "SUID" : 2247,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2224",
        "source" : "185",
        "target" : "2219",
        "shared_name" : "Leonard Woolf (printedFor) Daybreak",
        "Attribute_1_year" : 1922,
        "shared_interaction" : "printedFor",
        "name" : "Leonard Woolf (printedFor) Daybreak",
        "interaction" : "printedFor",
        "certainty" : "definite",
        "SUID" : 2224,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2214",
        "source" : "185",
        "target" : "2206",
        "shared_name" : "Leonard Woolf (printedFor) Karn",
        "Attribute_1_year" : 1922,
        "shared_interaction" : "printedFor",
        "name" : "Leonard Woolf (printedFor) Karn",
        "interaction" : "printedFor",
        "certainty" : "definite",
        "SUID" : 2214,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2156",
        "source" : "185",
        "target" : "2148",
        "shared_name" : "Leonard Woolf (translatedFor) The Gentleman from San Francisco and other stories",
        "Attribute_1_year" : 1922,
        "shared_interaction" : "translatedFor",
        "name" : "Leonard Woolf (translatedFor) The Gentleman from San Francisco and other stories",
        "interaction" : "translatedFor",
        "certainty" : "definite",
        "SUID" : 2156,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2102",
        "source" : "185",
        "target" : "2097",
        "shared_name" : "Leonard Woolf (printedFor) Stories of the East",
        "Attribute_1_year" : 1921,
        "shared_interaction" : "printedFor",
        "name" : "Leonard Woolf (printedFor) Stories of the East",
        "interaction" : "printedFor",
        "certainty" : "definite",
        "SUID" : 2102,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2099",
        "source" : "185",
        "target" : "2097",
        "shared_name" : "Leonard Woolf (authorOf) Stories of the East",
        "Attribute_1_year" : 1921,
        "shared_interaction" : "authorOf",
        "name" : "Leonard Woolf (authorOf) Stories of the East",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 2099,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2087",
        "source" : "185",
        "target" : "2082",
        "shared_name" : "Leonard Woolf (printedFor) Poems_8",
        "Attribute_1_year" : 1921,
        "shared_interaction" : "printedFor",
        "name" : "Leonard Woolf (printedFor) Poems_8",
        "interaction" : "printedFor",
        "certainty" : "definite",
        "SUID" : 2087,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2077",
        "source" : "185",
        "target" : "2069",
        "shared_name" : "Leonard Woolf (translatedFor) The Note-Books of Anton Tchekhov Together with Reminiscences of Tchekhov",
        "Attribute_1_year" : 1921,
        "shared_interaction" : "translatedFor",
        "name" : "Leonard Woolf (translatedFor) The Note-Books of Anton Tchekhov Together with Reminiscences of Tchekhov",
        "interaction" : "translatedFor",
        "certainty" : "definite",
        "SUID" : 2077,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2055",
        "source" : "185",
        "target" : "2050",
        "shared_name" : "Leonard Woolf (printedFor) Twelve Original Woodcuts",
        "Attribute_1_year" : 1921,
        "shared_interaction" : "printedFor",
        "name" : "Leonard Woolf (printedFor) Twelve Original Woodcuts",
        "interaction" : "printedFor",
        "certainty" : "definite",
        "SUID" : 2055,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2044",
        "source" : "185",
        "target" : "2039",
        "shared_name" : "Leonard Woolf (printedFor) Poems_7",
        "Attribute_1_year" : 1921,
        "shared_interaction" : "printedFor",
        "name" : "Leonard Woolf (printedFor) Poems_7",
        "interaction" : "printedFor",
        "certainty" : "definite",
        "SUID" : 2044,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2033",
        "source" : "185",
        "target" : "2028",
        "shared_name" : "Leonard Woolf (boundFor) Stories from the Old Testament Retold by Logan Pearsall Smith",
        "Attribute_1_year" : 1920,
        "shared_interaction" : "boundFor",
        "name" : "Leonard Woolf (boundFor) Stories from the Old Testament Retold by Logan Pearsall Smith",
        "interaction" : "boundFor",
        "certainty" : "likely",
        "SUID" : 2033,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2025",
        "source" : "185",
        "target" : "2015",
        "shared_name" : "Leonard Woolf (translatedFor) Reminiscences of Leo Nicolayevitch Tolstoi",
        "Attribute_1_year" : 1920,
        "shared_interaction" : "translatedFor",
        "name" : "Leonard Woolf (translatedFor) Reminiscences of Leo Nicolayevitch Tolstoi",
        "interaction" : "translatedFor",
        "certainty" : "definite",
        "SUID" : 2025,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2007",
        "source" : "185",
        "target" : "320",
        "shared_name" : "Leonard Woolf (printedFor) The Story of the Siren",
        "Attribute_1_year" : 1920,
        "shared_interaction" : "printedFor",
        "name" : "Leonard Woolf (printedFor) The Story of the Siren",
        "interaction" : "printedFor",
        "certainty" : "definite",
        "SUID" : 2007,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1893",
        "source" : "185",
        "target" : "1891",
        "shared_name" : "Leonard Woolf (authorOf) The Hotel: A Play in Three Acts",
        "Attribute_1_year" : 1939,
        "shared_interaction" : "authorOf",
        "name" : "Leonard Woolf (authorOf) The Hotel: A Play in Three Acts",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1893,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1747",
        "source" : "185",
        "target" : "1745",
        "shared_name" : "Leonard Woolf (authorOf) The League of Abyssinia",
        "Attribute_1_year" : 1936,
        "shared_interaction" : "authorOf",
        "name" : "Leonard Woolf (authorOf) The League of Abyssinia",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1747,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1353",
        "source" : "185",
        "target" : "1351",
        "shared_name" : "Leonard Woolf (authorOf) After the Deluge A Study in Communal Psychology Vol. I",
        "Attribute_1_year" : 1931,
        "shared_interaction" : "authorOf",
        "name" : "Leonard Woolf (authorOf) After the Deluge A Study in Communal Psychology Vol. I",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1353,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1348",
        "source" : "185",
        "target" : "1346",
        "shared_name" : "Leonard Woolf (authorOf) The Village in the Jungle",
        "Attribute_1_year" : 1931,
        "shared_interaction" : "authorOf",
        "name" : "Leonard Woolf (authorOf) The Village in the Jungle",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1348,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1004",
        "source" : "185",
        "target" : "1002",
        "shared_name" : "Leonard Woolf (authorOf) Imperialism and Civilization",
        "Attribute_1_year" : 1928,
        "shared_interaction" : "authorOf",
        "name" : "Leonard Woolf (authorOf) Imperialism and Civilization",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1004,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "855",
        "source" : "185",
        "target" : "853",
        "shared_name" : "Leonard Woolf (authorOf) Essays on Literature, History, Politics, etc.",
        "Attribute_1_year" : 1927,
        "shared_interaction" : "authorOf",
        "name" : "Leonard Woolf (authorOf) Essays on Literature, History, Politics, etc.",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 855,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "850",
        "source" : "185",
        "target" : "848",
        "shared_name" : "Leonard Woolf (authorOf) Hunting the Highbrow",
        "Attribute_1_year" : 1927,
        "shared_interaction" : "authorOf",
        "name" : "Leonard Woolf (authorOf) Hunting the Highbrow",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 850,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "516",
        "source" : "185",
        "target" : "514",
        "shared_name" : "Leonard Woolf (authorOf) Empire and Commerce in Africa A Study in Economic Imperialism",
        "Attribute_1_year" : 1925,
        "shared_interaction" : "authorOf",
        "name" : "Leonard Woolf (authorOf) Empire and Commerce in Africa A Study in Economic Imperialism",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 516,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "511",
        "source" : "185",
        "target" : "509",
        "shared_name" : "Leonard Woolf (authorOf) Fear and Politics / A Debate at the Zoo",
        "Attribute_1_year" : 1925,
        "shared_interaction" : "authorOf",
        "name" : "Leonard Woolf (authorOf) Fear and Politics / A Debate at the Zoo",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 511,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "299",
        "source" : "185",
        "target" : "294",
        "shared_name" : "Leonard Woolf (printedFor) Kew Gardens",
        "Attribute_1_year" : 1919,
        "shared_interaction" : "printedFor",
        "name" : "Leonard Woolf (printedFor) Kew Gardens",
        "interaction" : "printedFor",
        "certainty" : "definite",
        "SUID" : 299,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "288",
        "source" : "185",
        "target" : "280",
        "shared_name" : "Leonard Woolf (boundFor) The Critic in Judgment or Belshazzar of Baronscourt",
        "Attribute_1_year" : 1919,
        "shared_interaction" : "boundFor",
        "name" : "Leonard Woolf (boundFor) The Critic in Judgment or Belshazzar of Baronscourt",
        "interaction" : "boundFor",
        "certainty" : "definite",
        "SUID" : 288,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "262",
        "source" : "185",
        "target" : "257",
        "shared_name" : "Leonard Woolf (printedFor) Poems_1",
        "Attribute_1_year" : 1919,
        "shared_interaction" : "printedFor",
        "name" : "Leonard Woolf (printedFor) Poems_1",
        "interaction" : "printedFor",
        "certainty" : "definite",
        "SUID" : 262,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "226",
        "source" : "185",
        "target" : "221",
        "shared_name" : "Leonard Woolf (printedFor) Prelude",
        "Attribute_1_year" : 1918,
        "shared_interaction" : "printedFor",
        "name" : "Leonard Woolf (printedFor) Prelude",
        "interaction" : "printedFor",
        "certainty" : "definite",
        "SUID" : 226,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "199",
        "source" : "185",
        "target" : "197",
        "shared_name" : "Leonard Woolf (authorOf) Two Stories",
        "Attribute_1_year" : 1917,
        "shared_interaction" : "authorOf",
        "name" : "Leonard Woolf (authorOf) Two Stories",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 199,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "195",
        "source" : "185",
        "target" : "193",
        "shared_name" : "Leonard Woolf (brotherOf) C. N. Sidney Woolf",
        "shared_interaction" : "brotherOf",
        "name" : "Leonard Woolf (brotherOf) C. N. Sidney Woolf",
        "interaction" : "brotherOf",
        "SUID" : 195,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4925",
        "source" : "183",
        "target" : "4923",
        "shared_name" : "Virginia Woolf (authorOf) A Haunted House and Other Short Stories",
        "Attribute_1_year" : 1943,
        "shared_interaction" : "authorOf",
        "name" : "Virginia Woolf (authorOf) A Haunted House and Other Short Stories",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4925,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4868",
        "source" : "183",
        "target" : "4866",
        "shared_name" : "Virginia Woolf (authorOf) The Death of the Moth and Other Essays",
        "Attribute_1_year" : 1942,
        "shared_interaction" : "authorOf",
        "name" : "Virginia Woolf (authorOf) The Death of the Moth and Other Essays",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4868,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4813",
        "source" : "183",
        "target" : "4811",
        "shared_name" : "Virginia Woolf (authorOf) Between the Acts",
        "Attribute_1_year" : 1941,
        "shared_interaction" : "authorOf",
        "name" : "Virginia Woolf (authorOf) Between the Acts",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4813,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4789",
        "source" : "183",
        "target" : "4787",
        "shared_name" : "Virginia Woolf (authorOf) Roger Fry A Biography",
        "Attribute_1_year" : 1940,
        "shared_interaction" : "authorOf",
        "name" : "Virginia Woolf (authorOf) Roger Fry A Biography",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4789,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4753",
        "source" : "183",
        "target" : "4751",
        "shared_name" : "Virginia Woolf (authorOf) Reviewing",
        "Attribute_1_year" : 1939,
        "shared_interaction" : "authorOf",
        "name" : "Virginia Woolf (authorOf) Reviewing",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4753,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4616",
        "source" : "183",
        "target" : "4614",
        "shared_name" : "Virginia Woolf (authorOf) Three Guineas",
        "Attribute_1_year" : 1938,
        "shared_interaction" : "authorOf",
        "name" : "Virginia Woolf (authorOf) Three Guineas",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4616,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4515",
        "source" : "183",
        "target" : "4513",
        "shared_name" : "Virginia Woolf (authorOf) The Years",
        "Attribute_1_year" : 1937,
        "shared_interaction" : "authorOf",
        "name" : "Virginia Woolf (authorOf) The Years",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4515,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4139",
        "source" : "183",
        "target" : "4137",
        "shared_name" : "Virginia Woolf (authorOf) Walter Sickert A Conversation",
        "Attribute_1_year" : 1934,
        "shared_interaction" : "authorOf",
        "name" : "Virginia Woolf (authorOf) Walter Sickert A Conversation",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4139,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4007",
        "source" : "183",
        "target" : "4005",
        "shared_name" : "Virginia Woolf (authorOf) Flush A Biography",
        "Attribute_1_year" : 1933,
        "shared_interaction" : "authorOf",
        "name" : "Virginia Woolf (authorOf) Flush A Biography",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 4007,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3834",
        "source" : "183",
        "target" : "3832",
        "shared_name" : "Virginia Woolf (authorOf) The Common Reader Second Series",
        "Attribute_1_year" : 1932,
        "shared_interaction" : "authorOf",
        "name" : "Virginia Woolf (authorOf) The Common Reader Second Series",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 3834,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3829",
        "source" : "183",
        "target" : "3821",
        "shared_name" : "Virginia Woolf (printedFor) Jupiter and the Nun",
        "Attribute_1_year" : 1932,
        "shared_interaction" : "printedFor",
        "name" : "Virginia Woolf (printedFor) Jupiter and the Nun",
        "interaction" : "printedFor",
        "certainty" : "definite",
        "SUID" : 3829,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3644",
        "source" : "183",
        "target" : "3642",
        "shared_name" : "Virginia Woolf (authorOf) The Waves",
        "Attribute_1_year" : 1931,
        "shared_interaction" : "authorOf",
        "name" : "Virginia Woolf (authorOf) The Waves",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 3644,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3609",
        "source" : "183",
        "target" : "3601",
        "shared_name" : "Virginia Woolf (printedFor) Sissinghurst",
        "Attribute_1_year" : 1931,
        "shared_interaction" : "printedFor",
        "name" : "Virginia Woolf (printedFor) Sissinghurst",
        "interaction" : "printedFor",
        "certainty" : "definite",
        "SUID" : 3609,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3480",
        "source" : "183",
        "target" : "3475",
        "shared_name" : "Virginia Woolf (wroteIntroductionFor) Life as we have known it By Co-Operative working women",
        "Attribute_1_year" : 1931,
        "shared_interaction" : "wroteIntroductionFor",
        "name" : "Virginia Woolf (wroteIntroductionFor) Life as we have known it By Co-Operative working women",
        "interaction" : "wroteIntroductionFor",
        "certainty" : "definite",
        "SUID" : 3480,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3375",
        "source" : "183",
        "target" : "3364",
        "shared_name" : "Virginia Woolf (typesetFor) On Being Ill",
        "Attribute_1_year" : 1930,
        "shared_interaction" : "typesetFor",
        "name" : "Virginia Woolf (typesetFor) On Being Ill",
        "interaction" : "typesetFor",
        "certainty" : "definite",
        "SUID" : 3375,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3372",
        "source" : "183",
        "target" : "3364",
        "shared_name" : "Virginia Woolf (printedFor) On Being Ill",
        "Attribute_1_year" : 1930,
        "shared_interaction" : "printedFor",
        "name" : "Virginia Woolf (printedFor) On Being Ill",
        "interaction" : "printedFor",
        "certainty" : "definite",
        "SUID" : 3372,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3366",
        "source" : "183",
        "target" : "3364",
        "shared_name" : "Virginia Woolf (authorOf) On Being Ill",
        "Attribute_1_year" : 1930,
        "shared_interaction" : "authorOf",
        "name" : "Virginia Woolf (authorOf) On Being Ill",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 3366,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3117",
        "source" : "183",
        "target" : "1124",
        "shared_name" : "Virginia Woolf (authorOf) A Room of One's Own",
        "Attribute_1_year" : 1929,
        "shared_interaction" : "authorOf",
        "name" : "Virginia Woolf (authorOf) A Room of One's Own",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 3117,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3111",
        "source" : "183",
        "target" : "3109",
        "shared_name" : "Virginia Woolf (authorOf) Night and Day",
        "Attribute_1_year" : 1929,
        "shared_interaction" : "authorOf",
        "name" : "Virginia Woolf (authorOf) Night and Day",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 3111,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3101",
        "source" : "183",
        "target" : "3099",
        "shared_name" : "Virginia Woolf (authorOf) The Voyage Out",
        "Attribute_1_year" : 1929,
        "shared_interaction" : "authorOf",
        "name" : "Virginia Woolf (authorOf) The Voyage Out",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 3101,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2977",
        "source" : "183",
        "target" : "2975",
        "shared_name" : "Virginia Woolf (authorOf) Orlando A Biography",
        "Attribute_1_year" : 1928,
        "shared_interaction" : "authorOf",
        "name" : "Virginia Woolf (authorOf) Orlando A Biography",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 2977,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2964",
        "source" : "183",
        "target" : "2956",
        "shared_name" : "Virginia Woolf (printedFor) A Flying Scroll",
        "Attribute_1_year" : 1928,
        "shared_interaction" : "printedFor",
        "name" : "Virginia Woolf (printedFor) A Flying Scroll",
        "interaction" : "printedFor",
        "certainty" : "definite",
        "SUID" : 2964,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2899",
        "source" : "183",
        "target" : "294",
        "shared_name" : "Virginia Woolf (authorOf) Kew Gardens",
        "Attribute_1_year" : 1927,
        "shared_interaction" : "authorOf",
        "name" : "Virginia Woolf (authorOf) Kew Gardens",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 2899,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2893",
        "source" : "183",
        "target" : "2891",
        "shared_name" : "Virginia Woolf (authorOf) To the Lighthouse",
        "Attribute_1_year" : 1927,
        "shared_interaction" : "authorOf",
        "name" : "Virginia Woolf (authorOf) To the Lighthouse",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 2893,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2888",
        "source" : "183",
        "target" : "2880",
        "shared_name" : "Virginia Woolf (printedFor) Voltaire A Biographical Fantasy",
        "Attribute_1_year" : 1927,
        "shared_interaction" : "printedFor",
        "name" : "Virginia Woolf (printedFor) Voltaire A Biographical Fantasy",
        "interaction" : "printedFor",
        "certainty" : "definite",
        "SUID" : 2888,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2699",
        "source" : "183",
        "target" : "2691",
        "shared_name" : "Virginia Woolf (printedFor) April Morning",
        "Attribute_1_year" : 1926,
        "shared_interaction" : "printedFor",
        "name" : "Virginia Woolf (printedFor) April Morning",
        "interaction" : "printedFor",
        "certainty" : "definite",
        "SUID" : 2699,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2686",
        "source" : "183",
        "target" : "2678",
        "shared_name" : "Virginia Woolf (printedFor) Chorus of the Newly Dead",
        "Attribute_1_year" : 1926,
        "shared_interaction" : "printedFor",
        "name" : "Virginia Woolf (printedFor) Chorus of the Newly Dead",
        "interaction" : "printedFor",
        "certainty" : "definite",
        "SUID" : 2686,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2675",
        "source" : "183",
        "target" : "2664",
        "shared_name" : "Virginia Woolf (typesetFor) Martha Wish-You-Ill",
        "Attribute_1_year" : 1926,
        "shared_interaction" : "typesetFor",
        "name" : "Virginia Woolf (typesetFor) Martha Wish-You-Ill",
        "interaction" : "typesetFor",
        "certainty" : "definite",
        "SUID" : 2675,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2672",
        "source" : "183",
        "target" : "2664",
        "shared_name" : "Virginia Woolf (printedFor) Martha Wish-You-Ill",
        "Attribute_1_year" : 1926,
        "shared_interaction" : "printedFor",
        "name" : "Virginia Woolf (printedFor) Martha Wish-You-Ill",
        "interaction" : "printedFor",
        "certainty" : "definite",
        "SUID" : 2672,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2633",
        "source" : "183",
        "target" : "2628",
        "shared_name" : "Virginia Woolf (wroteIntroductionFor) Victorian Photographs of Famous Men & Fair Women",
        "Attribute_1_year" : 1926,
        "shared_interaction" : "wroteIntroductionFor",
        "name" : "Virginia Woolf (wroteIntroductionFor) Victorian Photographs of Famous Men & Fair Women",
        "interaction" : "wroteIntroductionFor",
        "certainty" : "definite",
        "SUID" : 2633,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2596",
        "source" : "183",
        "target" : "2594",
        "shared_name" : "Virginia Woolf (authorOf) Mrs. Dalloway",
        "Attribute_1_year" : 1925,
        "shared_interaction" : "authorOf",
        "name" : "Virginia Woolf (authorOf) Mrs. Dalloway",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 2596,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2585",
        "source" : "183",
        "target" : "2583",
        "shared_name" : "Virginia Woolf (authorOf) The Common Reader",
        "Attribute_1_year" : 1925,
        "shared_interaction" : "authorOf",
        "name" : "Virginia Woolf (authorOf) The Common Reader",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 2585,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2580",
        "source" : "183",
        "target" : "2572",
        "shared_name" : "Virginia Woolf (printedFor) Poems and Fables",
        "Attribute_1_year" : 1925,
        "shared_interaction" : "printedFor",
        "name" : "Virginia Woolf (printedFor) Poems and Fables",
        "interaction" : "printedFor",
        "certainty" : "definite",
        "SUID" : 2580,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2569",
        "source" : "183",
        "target" : "2561",
        "shared_name" : "Virginia Woolf (printedFor) Russet and Taffeta",
        "Attribute_1_year" : 1925,
        "shared_interaction" : "printedFor",
        "name" : "Virginia Woolf (printedFor) Russet and Taffeta",
        "interaction" : "printedFor",
        "certainty" : "definite",
        "SUID" : 2569,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2558",
        "source" : "183",
        "target" : "2550",
        "shared_name" : "Virginia Woolf (printedFor) Songs of Salvation Sin & Satire",
        "Attribute_1_year" : 1925,
        "shared_interaction" : "printedFor",
        "name" : "Virginia Woolf (printedFor) Songs of Salvation Sin & Satire",
        "interaction" : "printedFor",
        "certainty" : "definite",
        "SUID" : 2558,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2524",
        "source" : "183",
        "target" : "2505",
        "shared_name" : "Virginia Woolf (typesetFor) Parallax",
        "Attribute_1_year" : 1925,
        "shared_interaction" : "typesetFor",
        "name" : "Virginia Woolf (typesetFor) Parallax",
        "interaction" : "typesetFor",
        "certainty" : "likely",
        "SUID" : 2524,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2521",
        "source" : "183",
        "target" : "2505",
        "shared_name" : "Virginia Woolf (choseTitleFor) Parallax",
        "Attribute_1_year" : 1925,
        "shared_interaction" : "choseTitleFor",
        "name" : "Virginia Woolf (choseTitleFor) Parallax",
        "interaction" : "choseTitleFor",
        "certainty" : "likely",
        "SUID" : 2521,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2513",
        "source" : "183",
        "target" : "2505",
        "shared_name" : "Virginia Woolf (printedFor) Parallax",
        "Attribute_1_year" : 1925,
        "shared_interaction" : "printedFor",
        "name" : "Virginia Woolf (printedFor) Parallax",
        "interaction" : "printedFor",
        "certainty" : "definite",
        "SUID" : 2513,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2490",
        "source" : "183",
        "target" : "2479",
        "shared_name" : "Virginia Woolf (printedFor) Grace After Meat",
        "Attribute_1_year" : 1924,
        "shared_interaction" : "printedFor",
        "name" : "Virginia Woolf (printedFor) Grace After Meat",
        "interaction" : "printedFor",
        "certainty" : "definite",
        "SUID" : 2490,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2446",
        "source" : "183",
        "target" : "2438",
        "shared_name" : "Virginia Woolf (printedFor) Henry James at Work",
        "Attribute_1_year" : 1924,
        "shared_interaction" : "printedFor",
        "name" : "Virginia Woolf (printedFor) Henry James at Work",
        "interaction" : "printedFor",
        "certainty" : "definite",
        "SUID" : 2446,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2411",
        "source" : "183",
        "target" : "2403",
        "shared_name" : "Virginia Woolf (translatedFor) Tolstoi's Love Letters with a study of the autobiographical elements in Tolstoi's work, by Paul Biryukov",
        "Attribute_1_year" : 1923,
        "shared_interaction" : "translatedFor",
        "name" : "Virginia Woolf (translatedFor) Tolstoi's Love Letters with a study of the autobiographical elements in Tolstoi's work, by Paul Biryukov",
        "interaction" : "translatedFor",
        "certainty" : "definite",
        "SUID" : 2411,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2386",
        "source" : "183",
        "target" : "2378",
        "shared_name" : "Virginia Woolf (printedFor) Mutations of the Phoenix",
        "Attribute_1_year" : 1923,
        "shared_interaction" : "printedFor",
        "name" : "Virginia Woolf (printedFor) Mutations of the Phoenix",
        "interaction" : "printedFor",
        "certainty" : "definite",
        "SUID" : 2386,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2360",
        "source" : "183",
        "target" : "2352",
        "shared_name" : "Virginia Woolf (printedFor) To a Proud Phantom",
        "Attribute_1_year" : 1923,
        "shared_interaction" : "printedFor",
        "name" : "Virginia Woolf (printedFor) To a Proud Phantom",
        "interaction" : "printedFor",
        "certainty" : "definite",
        "SUID" : 2360,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2347",
        "source" : "183",
        "target" : "2334",
        "shared_name" : "Virginia Woolf (printedFor) The Feather Bed",
        "Attribute_1_year" : 1923,
        "shared_interaction" : "printedFor",
        "name" : "Virginia Woolf (printedFor) The Feather Bed",
        "interaction" : "printedFor",
        "certainty" : "definite",
        "SUID" : 2347,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2331",
        "source" : "183",
        "target" : "2323",
        "shared_name" : "Virginia Woolf (translatedFor) Talks with Tolstoi",
        "Attribute_1_year" : 1923,
        "shared_interaction" : "translatedFor",
        "name" : "Virginia Woolf (translatedFor) Talks with Tolstoi",
        "interaction" : "translatedFor",
        "certainty" : "definite",
        "SUID" : 2331,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2299",
        "source" : "183",
        "target" : "2291",
        "shared_name" : "Virginia Woolf (printedFor) Pharos and Pharillon",
        "Attribute_1_year" : 1923,
        "shared_interaction" : "printedFor",
        "name" : "Virginia Woolf (printedFor) Pharos and Pharillon",
        "interaction" : "printedFor",
        "certainty" : "definite",
        "SUID" : 2299,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2288",
        "source" : "183",
        "target" : "2277",
        "shared_name" : "Virginia Woolf (typesetFor) The Waste Land",
        "Attribute_1_year" : 1923,
        "shared_interaction" : "typesetFor",
        "name" : "Virginia Woolf (typesetFor) The Waste Land",
        "interaction" : "typesetFor",
        "certainty" : "likely",
        "SUID" : 2288,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2285",
        "source" : "183",
        "target" : "2277",
        "shared_name" : "Virginia Woolf (printedFor) The Waste Land",
        "Attribute_1_year" : 1923,
        "shared_interaction" : "printedFor",
        "name" : "Virginia Woolf (printedFor) The Waste Land",
        "interaction" : "printedFor",
        "certainty" : "definite",
        "SUID" : 2285,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2266",
        "source" : "183",
        "target" : "2258",
        "shared_name" : "Virginia Woolf (printedFor) The Legend of Monte Della Sibilla or Le Paradis de la Reine Sibille",
        "Attribute_1_year" : 1923,
        "shared_interaction" : "printedFor",
        "name" : "Virginia Woolf (printedFor) The Legend of Monte Della Sibilla or Le Paradis de la Reine Sibille",
        "interaction" : "printedFor",
        "certainty" : "definite",
        "SUID" : 2266,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2252",
        "source" : "183",
        "target" : "2250",
        "shared_name" : "Virginia Woolf (authorOf) Jacob's Room",
        "Attribute_1_year" : 1922,
        "shared_interaction" : "authorOf",
        "name" : "Virginia Woolf (authorOf) Jacob's Room",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 2252,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2227",
        "source" : "183",
        "target" : "2219",
        "shared_name" : "Virginia Woolf (printedFor) Daybreak",
        "Attribute_1_year" : 1922,
        "shared_interaction" : "printedFor",
        "name" : "Virginia Woolf (printedFor) Daybreak",
        "interaction" : "printedFor",
        "certainty" : "definite",
        "SUID" : 2227,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2211",
        "source" : "183",
        "target" : "2206",
        "shared_name" : "Virginia Woolf (printedFor) Karn",
        "Attribute_1_year" : 1922,
        "shared_interaction" : "printedFor",
        "name" : "Virginia Woolf (printedFor) Karn",
        "interaction" : "printedFor",
        "certainty" : "definite",
        "SUID" : 2211,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2179",
        "source" : "183",
        "target" : "2171",
        "shared_name" : "Virginia Woolf (translatedFor) Stavrogin's Confession and The Plan of the Life of a Great Sinner",
        "Attribute_1_year" : 1922,
        "shared_interaction" : "translatedFor",
        "name" : "Virginia Woolf (translatedFor) Stavrogin's Confession and The Plan of the Life of a Great Sinner",
        "interaction" : "translatedFor",
        "certainty" : "definite",
        "SUID" : 2179,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2110",
        "source" : "183",
        "target" : "2108",
        "shared_name" : "Virginia Woolf (authorOf) Monday or Tuesday",
        "Attribute_1_year" : 1921,
        "shared_interaction" : "authorOf",
        "name" : "Virginia Woolf (authorOf) Monday or Tuesday",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 2110,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2105",
        "source" : "183",
        "target" : "2097",
        "shared_name" : "Virginia Woolf (printedFor) Stories of the East",
        "Attribute_1_year" : 1921,
        "shared_interaction" : "printedFor",
        "name" : "Virginia Woolf (printedFor) Stories of the East",
        "interaction" : "printedFor",
        "certainty" : "definite",
        "SUID" : 2105,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2090",
        "source" : "183",
        "target" : "2082",
        "shared_name" : "Virginia Woolf (printedFor) Poems_8",
        "Attribute_1_year" : 1921,
        "shared_interaction" : "printedFor",
        "name" : "Virginia Woolf (printedFor) Poems_8",
        "interaction" : "printedFor",
        "certainty" : "definite",
        "SUID" : 2090,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2061",
        "source" : "183",
        "target" : "2050",
        "shared_name" : "Virginia Woolf (boundFor) Twelve Original Woodcuts",
        "Attribute_1_year" : 1921,
        "shared_interaction" : "boundFor",
        "name" : "Virginia Woolf (boundFor) Twelve Original Woodcuts",
        "interaction" : "boundFor",
        "certainty" : "likely",
        "SUID" : 2061,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2058",
        "source" : "183",
        "target" : "2050",
        "shared_name" : "Virginia Woolf (printedFor) Twelve Original Woodcuts",
        "Attribute_1_year" : 1921,
        "shared_interaction" : "printedFor",
        "name" : "Virginia Woolf (printedFor) Twelve Original Woodcuts",
        "interaction" : "printedFor",
        "certainty" : "definite",
        "SUID" : 2058,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2047",
        "source" : "183",
        "target" : "2039",
        "shared_name" : "Virginia Woolf (printedFor) Poems_7",
        "Attribute_1_year" : 1921,
        "shared_interaction" : "printedFor",
        "name" : "Virginia Woolf (printedFor) Poems_7",
        "interaction" : "printedFor",
        "certainty" : "definite",
        "SUID" : 2047,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2036",
        "source" : "183",
        "target" : "2028",
        "shared_name" : "Virginia Woolf (boundFor) Stories from the Old Testament Retold by Logan Pearsall Smith",
        "Attribute_1_year" : 1920,
        "shared_interaction" : "boundFor",
        "name" : "Virginia Woolf (boundFor) Stories from the Old Testament Retold by Logan Pearsall Smith",
        "interaction" : "boundFor",
        "certainty" : "likely",
        "SUID" : 2036,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2010",
        "source" : "183",
        "target" : "320",
        "shared_name" : "Virginia Woolf (printedFor) The Story of the Siren",
        "Attribute_1_year" : 1920,
        "shared_interaction" : "printedFor",
        "name" : "Virginia Woolf (printedFor) The Story of the Siren",
        "interaction" : "printedFor",
        "certainty" : "definite",
        "SUID" : 2010,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1481",
        "source" : "183",
        "target" : "1479",
        "shared_name" : "Virginia Woolf (authorOf) A Letter to a Young Poet",
        "Attribute_1_year" : 1932,
        "shared_interaction" : "authorOf",
        "name" : "Virginia Woolf (authorOf) A Letter to a Young Poet",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1481,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1126",
        "source" : "183",
        "target" : "1124",
        "shared_name" : "Virginia Woolf (authorOf) A Room of One's Own",
        "Attribute_1_year" : 1929,
        "shared_interaction" : "authorOf",
        "name" : "Virginia Woolf (authorOf) A Room of One's Own",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 1126,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "391",
        "source" : "183",
        "target" : "389",
        "shared_name" : "Virginia Woolf (authorOf) Mr. Bennett and Mrs. Brown",
        "Attribute_1_year" : 1924,
        "shared_interaction" : "authorOf",
        "name" : "Virginia Woolf (authorOf) Mr. Bennett and Mrs. Brown",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 391,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "325",
        "source" : "183",
        "target" : "320",
        "shared_name" : "Virginia Woolf (typesetFor) The Story of the Siren",
        "Attribute_1_year" : 1920,
        "shared_interaction" : "typesetFor",
        "name" : "Virginia Woolf (typesetFor) The Story of the Siren",
        "interaction" : "typesetFor",
        "certainty" : "definite",
        "SUID" : 325,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "315",
        "source" : "183",
        "target" : "313",
        "shared_name" : "Virginia Woolf (authorOf) The Mark on the Wall",
        "Attribute_1_year" : 1919,
        "shared_interaction" : "authorOf",
        "name" : "Virginia Woolf (authorOf) The Mark on the Wall",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 315,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "302",
        "source" : "183",
        "target" : "294",
        "shared_name" : "Virginia Woolf (printedFor) Kew Gardens",
        "Attribute_1_year" : 1919,
        "shared_interaction" : "printedFor",
        "name" : "Virginia Woolf (printedFor) Kew Gardens",
        "interaction" : "printedFor",
        "certainty" : "definite",
        "SUID" : 302,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "296",
        "source" : "183",
        "target" : "294",
        "shared_name" : "Virginia Woolf (authorOf) Kew Gardens",
        "Attribute_1_year" : 1919,
        "shared_interaction" : "authorOf",
        "name" : "Virginia Woolf (authorOf) Kew Gardens",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 296,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "291",
        "source" : "183",
        "target" : "280",
        "shared_name" : "Virginia Woolf (boundFor) The Critic in Judgment or Belshazzar of Baronscourt",
        "Attribute_1_year" : 1919,
        "shared_interaction" : "boundFor",
        "name" : "Virginia Woolf (boundFor) The Critic in Judgment or Belshazzar of Baronscourt",
        "interaction" : "boundFor",
        "certainty" : "definite",
        "SUID" : 291,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "275",
        "source" : "183",
        "target" : "270",
        "shared_name" : "Virginia Woolf (correctedFor) Paris A Poem",
        "Attribute_1_year" : 1919,
        "shared_interaction" : "correctedFor",
        "name" : "Virginia Woolf (correctedFor) Paris A Poem",
        "interaction" : "correctedFor",
        "certainty" : "definite",
        "SUID" : 275,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "265",
        "source" : "183",
        "target" : "257",
        "shared_name" : "Virginia Woolf (printedFor) Poems_1",
        "Attribute_1_year" : 1919,
        "shared_interaction" : "printedFor",
        "name" : "Virginia Woolf (printedFor) Poems_1",
        "interaction" : "printedFor",
        "certainty" : "definite",
        "SUID" : 265,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "242",
        "source" : "183",
        "target" : "221",
        "shared_name" : "Virginia Woolf (typesetFor) Prelude",
        "Attribute_1_year" : 1918,
        "shared_interaction" : "typesetFor",
        "name" : "Virginia Woolf (typesetFor) Prelude",
        "interaction" : "typesetFor",
        "certainty" : "speculative",
        "SUID" : 242,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "229",
        "source" : "183",
        "target" : "221",
        "shared_name" : "Virginia Woolf (printedFor) Prelude",
        "Attribute_1_year" : 1918,
        "shared_interaction" : "printedFor",
        "name" : "Virginia Woolf (printedFor) Prelude",
        "interaction" : "printedFor",
        "certainty" : "definite",
        "SUID" : 229,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "211",
        "source" : "183",
        "target" : "197",
        "shared_name" : "Virginia Woolf (authorOf) Two Stories",
        "Attribute_1_year" : 1917,
        "shared_interaction" : "authorOf",
        "name" : "Virginia Woolf (authorOf) Two Stories",
        "interaction" : "authorOf",
        "certainty" : "definite",
        "SUID" : 211,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "191",
        "source" : "183",
        "target" : "189",
        "shared_name" : "Virginia Woolf (sisterOf) Vanessa Bell",
        "shared_interaction" : "sisterOf",
        "name" : "Virginia Woolf (sisterOf) Vanessa Bell",
        "interaction" : "sisterOf",
        "SUID" : 191,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "187",
        "source" : "183",
        "target" : "185",
        "shared_name" : "Virginia Woolf (spouseOf) Leonard Woolf",
        "shared_interaction" : "spouseOf",
        "name" : "Virginia Woolf (spouseOf) Leonard Woolf",
        "interaction" : "spouseOf",
        "SUID" : 187,
        "selected" : false
      },
      "selected" : false
    } ]
  }
}}